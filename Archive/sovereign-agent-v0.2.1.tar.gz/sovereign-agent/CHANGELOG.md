# Changelog

## v0.2.1 — 2026-04-28

Test harness was broken in v0.2: 14 of 32 tests failed because the conftest
fixture reloaded modules between tests. This created two stale-reference
bugs — production code itself was correct.

### Fixed

- **conftest.py rewrite (root cause fix)**. Replaced module reloading with
  in-place mutation of `SETTINGS.paths` via `object.__setattr__`. Avoids
  the class-identity drift that broke `pytest.raises(AuthorityViolation)`,
  the stale `SETTINGS` references that broke pathguard/events/seal tests,
  and the cumulative tool registry contamination across tests.
- **`reflector.py`** now uses `SETTINGS.reflector_model` instead of
  `SETTINGS.orchestrator_model`. The lightweight Reflector should run on
  the small fast model, not the orchestrator.

### Added

- **`config.py` env-var support** for all model selections —
  `AGENT_ORCHESTRATOR_MODEL`, `AGENT_CODER_MODEL`, `AGENT_EMBED_MODEL`,
  `AGENT_REFLECTOR_MODEL`, `AGENT_FAST_MODEL`. Set in your shell rc to
  override the defaults without editing source.
- **`reflector_model` field** in `Settings` (was missing in v0.2).
- **`sovereign doctor` command** — diagnostic check covering paths,
  permissions, models, Ollama reachability, model availability, bwrap,
  PROTOCOL-ZERO state, and VRAM. Run any time something feels off.
- **`tests/test_mode_controller.py`** (13 tests) — backlog read/write
  round-trip, priority ordering, status-aware task picker, atomic write,
  malformed YAML resilience.
- **`tests/test_retrieval.py`** (9 tests) — RRF fusion math including the
  classic compromise-candidate property, vector serialization roundtrip,
  pinning the standard k=60 constant.
- **`tests/test_vram.py`** (8 tests) — heavy-tool VRAM gating, file-lock
  serialization across threads, lock-timeout behavior.

### Test count

- v0.2:    32 tests defined, 14 failing → effectively no working coverage
- v0.2.1:  76 tests, all passing in ~7 seconds, three runs verified stable
