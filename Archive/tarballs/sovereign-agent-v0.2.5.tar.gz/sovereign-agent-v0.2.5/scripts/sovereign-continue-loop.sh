#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════════════════════════╗
# ║  sovereign-continue-loop.sh — Re-trigger driver                      ║
# ║                                                                      ║
# ║  Repeatedly invokes ``sovereign continue <task_id>`` until the       ║
# ║  continuation is drained, halted, or the operator stops the loop.    ║
# ║                                                                      ║
# ║  Each invocation is a fresh Python process. The model never sees     ║
# ║  more than one step's context per invocation. Memory accumulates     ║
# ║  in events.jsonl and atoms.db across invocations.                    ║
# ╚══════════════════════════════════════════════════════════════════════╝
#
# Usage:
#   sovereign-continue-loop.sh <task_id>             # run until drained
#   sovereign-continue-loop.sh <task_id> --once      # one step then exit
#   sovereign-continue-loop.sh <task_id> --max 50    # at most 50 steps
#
# Environment:
#   SOVEREIGN_BIN     path to the `sovereign` CLI (default: in PATH)
#   COOLDOWN_SECONDS  sleep between successful invocations (default: 2)
#   LOCKED_BACKOFF    sleep when continuation is locked (default: 5)

set -euo pipefail

if [[ $# -lt 1 ]]; then
    echo "usage: $0 <task_id> [--once] [--max N]" >&2
    exit 2
fi

TASK_ID="$1"
shift || true

MAX_STEPS=""
ONCE=0
while [[ $# -gt 0 ]]; do
    case "$1" in
        --once) ONCE=1; shift ;;
        --max) MAX_STEPS="$2"; shift 2 ;;
        *)     echo "unknown arg: $1" >&2; exit 2 ;;
    esac
done

SOVEREIGN_BIN="${SOVEREIGN_BIN:-sovereign}"
COOLDOWN_SECONDS="${COOLDOWN_SECONDS:-2}"
LOCKED_BACKOFF="${LOCKED_BACKOFF:-5}"

steps=0
echo "◈ continue-loop · task=${TASK_ID}"

while true; do
    if [[ -n "$MAX_STEPS" && "$steps" -ge "$MAX_STEPS" ]]; then
        echo "◈ max-steps reached ($MAX_STEPS); stopping"
        exit 0
    fi

    # Run one step. Capture the exit code; don't let `set -e` kill us
    # on any non-zero — we read the code to decide what to do.
    set +e
    "$SOVEREIGN_BIN" continue "$TASK_ID"
    rc=$?
    set -e

    case "$rc" in
        0)
            # complete — step ran cleanly. Sleep cooldown, continue.
            steps=$((steps + 1))
            [[ "$ONCE" -eq 1 ]] && exit 0
            sleep "$COOLDOWN_SECONDS"
            ;;
        8)
            # drained — continuation is done or terminally poisoned.
            echo "◈ continuation drained · steps=${steps}"
            exit 0
            ;;
        9)
            # locked — another runner has it. Back off and retry.
            sleep "$LOCKED_BACKOFF"
            ;;
        3)
            # halted — PROTOCOL-ZERO is armed. Stop cleanly.
            echo "◈ HALT armed · stopping" >&2
            exit 3
            ;;
        *)
            # other failure — log and back off briefly, then retry.
            echo "◈ continue failed (rc=${rc}); retrying in ${COOLDOWN_SECONDS}s" >&2
            sleep "$COOLDOWN_SECONDS"
            ;;
    esac
done
