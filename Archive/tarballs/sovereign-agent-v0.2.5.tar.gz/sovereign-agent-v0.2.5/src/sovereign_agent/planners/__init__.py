"""
╔══════════════════════════════════════════════════════════════════════════╗
║  planners — pure-Python task decomposition                               ║
║  Architecture §13 (new in v0.2.5)                                        ║
╚══════════════════════════════════════════════════════════════════════════╝

A planner takes operator-provided arguments and produces a list of atomic
``Step`` objects. No model is invoked. The plan is deterministic given the
inputs, which is the property that makes the re-trigger architecture
auditable: you can read the continuation file and know exactly what will
happen, without speculating about model behavior.

Planners are registered by name. ``sovereign plan <name> --arg=…`` looks up
the planner, runs ``.plan(**args)``, and creates a continuation with the
returned steps.

Adding a planner:

  1. Create ``planners/<name>.py`` with a class that inherits from
     ``Planner`` and implements ``.plan()`` and ``.render_step()``.
  2. Register it in this file's ``REGISTRY``.
  3. Add a test in ``tests/test_planners.py``.
"""
from __future__ import annotations

from .base import Planner, PlannerError, PlannerNotFound
from .inventory import InventoryPlanner
from .read_files import ReadFilesPlanner

# The registry is keyed by stable, kebab-case identifiers. Renaming a key
# breaks any continuation file that references the old name, so don't.
REGISTRY: dict[str, Planner] = {
    "inventory": InventoryPlanner(),
    "read-files": ReadFilesPlanner(),
}


def get_planner(name: str) -> Planner:
    """Look up a planner by registered name.

    Raises PlannerNotFound with the list of valid names if missing.
    """
    if name not in REGISTRY:
        raise PlannerNotFound(name, available=sorted(REGISTRY.keys()))
    return REGISTRY[name]


def planner_names() -> list[str]:
    """Sorted list of registered planner names."""
    return sorted(REGISTRY.keys())


__all__ = [
    "Planner",
    "PlannerError",
    "PlannerNotFound",
    "REGISTRY",
    "get_planner",
    "planner_names",
]
