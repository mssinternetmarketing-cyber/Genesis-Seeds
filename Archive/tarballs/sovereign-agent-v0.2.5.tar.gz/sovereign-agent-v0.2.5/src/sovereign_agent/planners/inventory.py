"""Inventory planner: for each matching file in a directory tree, generate
one step that asks the agent to read it and write a summary line into an
output file. The classic re-trigger use case — Genesis-Seeds-style corpus
distillation broken into atomic units the model can complete in seconds.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..continuation import Step
from .base import PlanResult, Planner, PlannerError


class InventoryPlanner(Planner):
    name = "inventory"
    description = "Read each file under <root>; append a summary line per file to <output>."

    def required_args(self) -> tuple[str, ...]:
        return ("root", "output")

    def plan(self, **kwargs: Any) -> PlanResult:
        root_arg = kwargs.get("root")
        output_arg = kwargs.get("output")
        patterns = kwargs.get("patterns") or ["*.md", "*.txt", "*.rst", "*.py"]
        max_files = int(kwargs.get("max_files") or 0)  # 0 = unbounded
        recursive = bool(kwargs.get("recursive", True))

        if not root_arg:
            raise PlannerError("inventory: 'root' is required (directory to walk)")
        if not output_arg:
            raise PlannerError("inventory: 'output' is required (file to write into)")

        root = Path(str(root_arg)).expanduser().resolve()
        output = Path(str(output_arg)).expanduser().resolve()

        if not root.exists():
            raise PlannerError(f"inventory: root path does not exist: {root}")
        if not root.is_dir():
            raise PlannerError(f"inventory: root must be a directory: {root}")

        files = self._walk(root, patterns, recursive)
        if max_files > 0:
            files = files[:max_files]

        if not files:
            raise PlannerError(
                f"inventory: no files matched patterns {patterns} under {root}"
            )

        steps = [
            Step(id=i, kind="inventory_file", args={"path": str(p), "output": str(output)})
            for i, p in enumerate(files)
        ]
        return PlanResult(
            goal=f"Inventory {len(files)} files under {root} → {output}",
            steps=steps,
            output_path=str(output),
            notes=f"patterns={patterns} recursive={recursive}",
        )

    def render_step(self, step: Step, planner_args: dict) -> str:
        path = step.args.get("path", "(missing)")
        output = step.args.get("output", "(missing)")
        return (
            f"Read the file at {path}. Produce a single-line summary "
            f"(roughly 20-40 words; one line, no preamble) describing what "
            f"the file contains and its likely purpose. Append exactly one "
            f"line to {output} in the format: '{path}: <your summary>'. "
            f"Use the write_file tool with mode='append'. Do not modify "
            f"any other file. When the line is appended, you are done."
        )

    @staticmethod
    def _walk(root: Path, patterns: list[str], recursive: bool) -> list[Path]:
        """Stable, deterministic file ordering."""
        seen: set[Path] = set()
        for pat in patterns:
            it = root.rglob(pat) if recursive else root.glob(pat)
            for p in it:
                if p.is_file():
                    seen.add(p.resolve())
        return sorted(seen)
