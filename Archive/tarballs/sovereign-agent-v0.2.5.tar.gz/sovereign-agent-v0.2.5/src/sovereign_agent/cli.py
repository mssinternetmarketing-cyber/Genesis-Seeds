"""
╔══════════════════════════════════════════════════════════════════════════╗
║  cli.py — Operator surface (v0.2.5)                                      ║
║  Architecture §5 + §7a + §8a + §11 + §13                                 ║
╚══════════════════════════════════════════════════════════════════════════╝

The CLI is how YOU (the operator) talk to the agent. The agent doesn't
use it. Commands are grouped by purpose:

    Setup:        init       — bootstrap config dirs, secret key, DBs
                  doctor     — diagnose config + ollama reachability + models
                  config     — show resolved configuration
    Run:          run        — single ONESHOT task
                  busy       — drain backlog forever (or once / N times)
                  until      — drain until predicate
    Re-trigger:   plan       — pre-decompose a large task into atomic steps
                  continue   — execute ONE pending step from a continuation
                  continuations — list / show / delete continuation files
    Backlog:      backlog    — list / add / remove / show / requeue / clear
    Approvals:    approvals  — list pending Tier 3 requests
                  approve    — grant a request
                  deny       — refuse a request
    Safety:       halt       — trip PROTOCOL-ZERO
                  disarm     — clear PROTOCOL-ZERO (after review)
    Audit:        tail       — ingest events.jsonl into events.db
                  seal       — compute yesterday's Merkle root
                  verify     — verify a past seal still matches its events
                  events     — show recent events (with --follow)
                  lessons    — show recent distilled lessons

Exit codes are stable and documented:
    0  success
    1  generic runtime error
    2  usage error
    3  PROTOCOL-ZERO armed (refused start)
    4  not initialized (run `sovereign init`)
    5  ollama unreachable
    6  approval not found / already resolved
    7  budget exhausted (when applicable)
    8  continuation drained (used by `continue` and the loop driver)
    9  continuation locked by another process

Top-level flags (apply to every command):
    --version
    --json / -j         emit JSON for read commands
    --quiet / -q        suppress non-essential output
    --verbose / -v      log INFO / DEBUG to stderr
    --no-color          disable Rich color (implied when not a TTY)
    --config-dir PATH   override XDG config dir
    --data-dir PATH     override XDG data dir
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import structlog
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from . import __version__, protocol_zero
from .config import SETTINGS, Paths
from .events import init_events_db, tail_to_sqlite
from .modes import Mode, RunBudget


# ─── Exit codes (single source of truth) ────────────────────────────────────


class ExitCode:
    OK = 0
    ERROR = 1
    USAGE = 2
    HALTED = 3
    NOT_INITIALIZED = 4
    OLLAMA_UNREACHABLE = 5
    APPROVAL_NOT_FOUND = 6
    BUDGET = 7
    DRAINED = 8
    LOCKED = 9


# ─── Global state set by the top-level callback ─────────────────────────────


class _CliState:
    json_out: bool = False
    quiet: bool = False
    verbose: bool = False
    no_color: bool = False


STATE = _CliState()
console = Console()


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(level=level, stream=sys.stderr, format="%(message)s")
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.dev.ConsoleRenderer(colors=not STATE.no_color),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
    )


def _override_paths(*, config_dir: Path | None, data_dir: Path | None) -> None:
    """Mutate SETTINGS.paths in place. Same trick as conftest."""
    if config_dir is None and data_dir is None:
        return
    new_paths = Paths(
        config_dir=config_dir or SETTINGS.paths.config_dir,
        data_dir=data_dir or SETTINGS.paths.data_dir,
    )
    object.__setattr__(SETTINGS, "paths", new_paths)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"sovereign-agent {__version__}")
        raise typer.Exit(ExitCode.OK)


app = typer.Typer(
    no_args_is_help=True,
    add_completion=True,
    rich_markup_mode="rich",
    help="◈ sovereign-agent — your local 24/7 agent",
    pretty_exceptions_show_locals=False,
)


@app.callback()
def _global_options(
    version: bool = typer.Option(
        False, "--version", callback=_version_callback, is_eager=True,
        help="Show version and exit.",
    ),
    json_out: bool = typer.Option(False, "--json", "-j", help="Emit JSON for read commands."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress non-essential output."),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Log INFO/DEBUG to stderr."),
    no_color: bool = typer.Option(False, "--no-color", help="Disable color output."),
    config_dir: Path | None = typer.Option(None, "--config-dir", help="Override XDG config dir."),
    data_dir: Path | None = typer.Option(None, "--data-dir", help="Override XDG data dir."),
) -> None:
    """Global options. Apply to every subcommand."""
    STATE.json_out = json_out
    STATE.quiet = quiet
    STATE.verbose = verbose
    STATE.no_color = no_color or not sys.stdout.isatty()
    if STATE.no_color:
        global console
        console = Console(no_color=True, force_terminal=False)
    _override_paths(config_dir=config_dir, data_dir=data_dir)
    _setup_logging(verbose)


# ─── Output helpers ─────────────────────────────────────────────────────────


def _print(*args: Any, **kwargs: Any) -> None:
    if STATE.quiet:
        return
    console.print(*args, **kwargs)


def _emit_json(payload: Any) -> None:
    typer.echo(json.dumps(payload, default=str, indent=2 if sys.stdout.isatty() else None))


def _die(code: int, message: str, *, hint: str | None = None) -> None:
    if STATE.json_out:
        payload = {"ok": False, "code": code, "error": message}
        if hint:
            payload["hint"] = hint
        _emit_json(payload)
    else:
        console.print(f"[red]✗ {message}[/red]")
        if hint:
            console.print(f"[dim]hint: {hint}[/dim]")
    raise typer.Exit(code)


# ─── Pre-flight checks ──────────────────────────────────────────────────────


def _preflight_initialized() -> None:
    if not SETTINGS.paths.secret_key_file.exists():
        _die(ExitCode.NOT_INITIALIZED, "agent is not initialized",
             hint="run `sovereign init` first")


def _preflight_not_halted() -> None:
    if SETTINGS.paths.halt_flag.exists() or protocol_zero.is_armed():
        _die(ExitCode.HALTED, "PROTOCOL-ZERO is armed",
             hint="review HALT file, then `sovereign disarm`")


def _preflight_ollama_reachable(*, fatal: bool = True) -> bool:
    import socket
    from urllib.parse import urlparse

    parsed = urlparse(SETTINGS.ollama_host)
    host = parsed.hostname or "localhost"
    port = parsed.port or 11434
    try:
        with socket.create_connection((host, port), timeout=3):
            return True
    except (OSError, socket.timeout) as e:
        if fatal:
            _die(ExitCode.OLLAMA_UNREACHABLE,
                 f"ollama unreachable at {host}:{port}: {e}",
                 hint="start ollama, or set OLLAMA_HOST")
        return False


# ─── Banner ─────────────────────────────────────────────────────────────────


BANNER = """[bold cyan]
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║              ◈  S O V E R E I G N   A G E N T  ◈                     ║
║                                                                      ║
║       local · authority-tiered · audited · recoverable · yours       ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
[/bold cyan]"""


def _build_tools_for_mode(mode: Mode) -> dict:
    from .tools import (
        CopyFileTool, EditFileTool, EmbedQueryTool, ListDirTool,
        MemorySearchTool, MemoryWriteTool, ReadFileTool, SearchTextTool,
        WebFetchTool, WriteFileTool,
    )
    return {
        "read_file": ReadFileTool(),
        "list_dir": ListDirTool(),
        "search_text": SearchTextTool(),
        "embed_query": EmbedQueryTool(),
        "web_fetch": WebFetchTool(),
        "memory_search": MemorySearchTool(),
        "memory_write": MemoryWriteTool(),
        "write_file": WriteFileTool(mode=mode),
        "edit_file": EditFileTool(mode=mode),
        "copy_file": CopyFileTool(mode=mode),
    }


# ═══════════════════════════════════════════════════════════════════════════
#  SETUP
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def init() -> None:
    """Bootstrap config dirs, generate secret key, initialize DBs."""
    if not STATE.json_out:
        _print(BANNER)
        _print("[bold]Initializing sovereign-agent...[/bold]\n")

    SETTINGS.paths.ensure()
    from .approval import _load_or_create_secret  # noqa: WPS437
    _load_or_create_secret()

    conn_e = init_events_db()
    conn_e.close()
    from .db import open_atoms_db
    conn_a = open_atoms_db()
    conn_a.close()

    if STATE.json_out:
        _emit_json({
            "ok": True,
            "config_dir": str(SETTINGS.paths.config_dir),
            "data_dir": str(SETTINGS.paths.data_dir),
            "sandbox": str(SETTINGS.paths.sandbox_dir),
            "events": str(SETTINGS.paths.events_dir),
            "atoms_db": str(SETTINGS.paths.atoms_db),
            "continuations": str(SETTINGS.paths.continuations_dir),
        })
        return

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column(style="dim")
    table.add_column()
    table.add_row("config dir", str(SETTINGS.paths.config_dir))
    table.add_row("data dir", str(SETTINGS.paths.data_dir))
    table.add_row("sandbox", str(SETTINGS.paths.sandbox_dir))
    table.add_row("events", str(SETTINGS.paths.events_dir))
    table.add_row("atoms.db", str(SETTINGS.paths.atoms_db))
    table.add_row("continuations", str(SETTINGS.paths.continuations_dir))
    table.add_row("secret key", "[green]created[/green] (mode 0600)")
    _print(Panel(table, title="◈ initialized", border_style="green"))


@app.command()
def doctor() -> None:
    """Diagnose the agent's environment: paths, models, Ollama, VRAM, locks."""
    import shutil
    import socket
    from urllib.parse import urlparse

    if not STATE.json_out:
        _print(BANNER)
        _print("[bold]Running diagnostics...[/bold]\n")

    rows: list[dict[str, str]] = []

    def add(name: str, status: str, detail: str = "") -> None:
        rows.append({"check": name, "status": status, "detail": detail})

    for label, path in [
        ("config_dir", SETTINGS.paths.config_dir),
        ("data_dir", SETTINGS.paths.data_dir),
        ("sandbox_dir", SETTINGS.paths.sandbox_dir),
        ("events_dir", SETTINGS.paths.events_dir),
        ("atoms.db", SETTINGS.paths.atoms_db),
        ("secret.key", SETTINGS.paths.secret_key_file),
        ("continuations", SETTINGS.paths.continuations_dir),
    ]:
        add(label, "PASS" if path.exists() else "WARN",
            str(path) if path.exists() else f"{path} (run `sovereign init`)")

    if SETTINGS.paths.secret_key_file.exists():
        mode = SETTINGS.paths.secret_key_file.stat().st_mode & 0o777
        if mode == 0o600:
            add("secret mode", "PASS", "0600 (owner read-only)")
        else:
            add("secret mode", "FAIL", f"mode {oct(mode)} — should be 0600")

    add("orchestrator", "PASS", SETTINGS.orchestrator_model)
    add("coder", "PASS", SETTINGS.coder_model)
    add("embedder", "PASS", SETTINGS.embed_model)
    add("reflector", "PASS", SETTINGS.reflector_model)

    parsed = urlparse(SETTINGS.ollama_host)
    host = parsed.hostname or "localhost"
    port = parsed.port or 11434
    ollama_up = False
    try:
        with socket.create_connection((host, port), timeout=2):
            add("ollama tcp", "PASS", f"{host}:{port}")
            ollama_up = True
    except (OSError, socket.timeout) as e:
        add("ollama tcp", "FAIL", f"{host}:{port} unreachable: {e}")

    if ollama_up:
        try:
            import httpx
            r = httpx.get(f"{SETTINGS.ollama_host}/api/tags", timeout=5)
            r.raise_for_status()
            installed = {m["name"] for m in r.json().get("models", [])}
            for label, name in [
                ("orchestrator model", SETTINGS.orchestrator_model),
                ("embedder model", SETTINGS.embed_model),
                ("reflector model", SETTINGS.reflector_model),
            ]:
                if name in installed or any(n.startswith(name + ":") for n in installed):
                    add(label, "PASS", "found")
                else:
                    add(label, "FAIL", f"{name!r} not installed (try `ollama pull {name}`)")

            try:
                from .ollama_client import OllamaClient

                async def _probe():
                    cli = OllamaClient()
                    return {
                        "orchestrator": await cli.supports_thinking(SETTINGS.orchestrator_model),
                        "reflector": await cli.supports_thinking(SETTINGS.reflector_model),
                    }
                caps = asyncio.run(_probe())
                for label, key in [("orch thinking", "orchestrator"), ("reflector thinking", "reflector")]:
                    add(label, "PASS" if caps[key] else "WARN",
                        "supported" if caps[key] else "NOT supported (auto-disabled)")
            except Exception as e:  # noqa: BLE001
                add("capabilities", "WARN", f"could not probe: {e}")
        except Exception as e:  # noqa: BLE001
            add("ollama models", "WARN", f"could not query: {e}")

    if shutil.which("bwrap"):
        add("bubblewrap", "PASS", shutil.which("bwrap"))
    else:
        add("bubblewrap", "FAIL", "not installed — `apt install bubblewrap`")

    if SETTINGS.paths.halt_flag.exists():
        add("protocol-zero", "WARN", "ARMED — `sovereign disarm`")
    else:
        add("protocol-zero", "PASS", "clear")

    try:
        from .vram import read_vram
        snap = read_vram()
        add("vram", "PASS", f"{snap.free_mb} MB free / {snap.total_mb} MB total ({snap.source})")
    except Exception as e:  # noqa: BLE001
        add("vram", "WARN", f"could not read: {e}")

    if STATE.json_out:
        n_fail = sum(1 for r in rows if r["status"] == "FAIL")
        _emit_json({"ok": n_fail == 0, "checks": rows, "fail_count": n_fail})
        return

    table = Table(title="◈ doctor", show_header=True, header_style="bold cyan")
    table.add_column("check", style="dim", width=22)
    table.add_column("status", width=8)
    table.add_column("detail", overflow="fold")
    for r in rows:
        color = {"PASS": "green", "WARN": "yellow", "FAIL": "red"}.get(r["status"], "white")
        table.add_row(r["check"], f"[{color}]{r['status']}[/{color}]", r["detail"])
    _print(table)


@app.command(name="config")
def show_config() -> None:
    """Print the resolved configuration with effective values."""
    payload = {
        "version": __version__,
        "paths": {
            "config_dir": str(SETTINGS.paths.config_dir),
            "data_dir": str(SETTINGS.paths.data_dir),
            "sandbox_dir": str(SETTINGS.paths.sandbox_dir),
            "events_dir": str(SETTINGS.paths.events_dir),
            "atoms_db": str(SETTINGS.paths.atoms_db),
            "continuations_dir": str(SETTINGS.paths.continuations_dir),
            "backlog_yaml": str(SETTINGS.paths.backlog_yaml),
        },
        "models": {
            "orchestrator": SETTINGS.orchestrator_model,
            "coder": SETTINGS.coder_model,
            "embedder": SETTINGS.embed_model,
            "reflector": SETTINGS.reflector_model,
            "fast": SETTINGS.fast_model,
        },
        "ollama_host": SETTINGS.ollama_host,
        "think_mode": SETTINGS.think_mode,
        "num_ctx": SETTINGS.num_ctx,
        "approval_default_expiry_seconds": SETTINGS.approval_default_expiry_seconds,
        "env_overrides": {
            k: os.environ.get(k) for k in (
                "OLLAMA_HOST", "AGENT_ORCHESTRATOR_MODEL", "AGENT_CODER_MODEL",
                "AGENT_EMBED_MODEL", "AGENT_REFLECTOR_MODEL", "AGENT_FAST_MODEL",
                "AGENT_THINK",
            ) if os.environ.get(k) is not None
        },
    }

    if STATE.json_out:
        _emit_json(payload)
        return

    table = Table(title="◈ config", show_header=False, box=None, padding=(0, 1))
    table.add_column(style="dim")
    table.add_column()
    table.add_row("version", payload["version"])
    table.add_row("ollama_host", payload["ollama_host"])
    table.add_row("think_mode", payload["think_mode"])
    table.add_row("num_ctx", str(payload["num_ctx"]))
    table.add_row("orchestrator", payload["models"]["orchestrator"])
    table.add_row("coder", payload["models"]["coder"])
    table.add_row("embedder", payload["models"]["embedder"])
    table.add_row("reflector", payload["models"]["reflector"])
    table.add_row("fast", payload["models"]["fast"])
    for k, v in payload["paths"].items():
        table.add_row(f"path.{k}", v)
    if payload["env_overrides"]:
        for k, v in payload["env_overrides"].items():
            table.add_row(f"env.{k}", v)
    _print(table)


# ═══════════════════════════════════════════════════════════════════════════
#  RUN
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def run(
    goal: str = typer.Argument(..., help="What you want the agent to accomplish"),
    mode: Mode = typer.Option(Mode.ONESHOT, "--mode"),
    max_iterations: int = typer.Option(25, "--max-iter"),
    max_wall_seconds: int = typer.Option(1800, "--max-wall"),
    max_tokens: int = typer.Option(200_000, "--max-tokens"),
    dry_run: bool = typer.Option(False, "--dry-run",
        help="Show resolved tools, mode, and budget without invoking the model."),
) -> None:
    """Run a single task through the agent loop."""
    _preflight_initialized()
    if not dry_run:
        _preflight_not_halted()
        _preflight_ollama_reachable()

    from .loop import agent_loop

    protocol_zero.install_signal_handlers()
    tools = _build_tools_for_mode(mode)
    budget = RunBudget(max_iterations=max_iterations,
                      max_wall_seconds=max_wall_seconds, max_tokens=max_tokens)

    if dry_run:
        from .authority import tools_available_in_mode
        from .modes import MODE_TIER_CEILING
        available = sorted(m.name for m in tools_available_in_mode(mode))
        payload = {
            "ok": True, "dry_run": True, "goal": goal, "mode": mode.value,
            "tier_ceiling": MODE_TIER_CEILING[mode],
            "available_tools": available,
            "budget": {
                "max_iterations": budget.max_iterations,
                "max_wall_seconds": budget.max_wall_seconds,
                "max_tokens": budget.max_tokens,
            },
        }
        if STATE.json_out:
            _emit_json(payload)
        else:
            table = Table(title=f"◈ dry-run · {mode.value}")
            table.add_column("field", style="dim")
            table.add_column("value", overflow="fold")
            table.add_row("goal", goal)
            table.add_row("mode", mode.value)
            table.add_row("tier_ceiling", str(payload["tier_ceiling"]))
            table.add_row("tools", ", ".join(available))
            table.add_row("budget.iter", str(budget.max_iterations))
            table.add_row("budget.wall", f"{budget.max_wall_seconds}s")
            table.add_row("budget.tokens", str(budget.max_tokens))
            _print(table)
        raise typer.Exit(ExitCode.OK)

    _print(f"\n◈ [bold]{mode.value}[/bold] · {goal[:80]}\n")
    result = asyncio.run(agent_loop(goal=goal, mode=mode, budget=budget, tools=tools))

    if STATE.json_out:
        _emit_json({
            "ok": result.ok, "reason": result.reason,
            "iterations": result.iterations, "tokens": result.tokens_used,
            "lesson_id": result.lesson_id, "final_message": result.final_message,
        })
    else:
        color = "green" if result.ok else "yellow"
        _print(Panel(
            f"[bold]{result.reason}[/bold]\n"
            f"iterations: {result.iterations}  ·  tokens: {result.tokens_used}\n"
            f"lesson: {result.lesson_id or '(none)'}",
            title="◈ result", border_style=color,
        ))
        if result.final_message:
            _print("\n" + result.final_message)
    raise typer.Exit(ExitCode.OK if result.ok else ExitCode.ERROR)


@app.command()
def busy(
    cooldown: float = typer.Option(5.0, "--cooldown", help="Seconds between tasks"),
    empty_sleep: float = typer.Option(30.0, "--empty-sleep", help="Sleep when backlog empty"),
    max_iter_per_task: int = typer.Option(25, "--max-iter"),
    max_wall_per_task: int = typer.Option(1800, "--max-wall"),
    once: bool = typer.Option(False, "--once", help="Drain one task then exit (cron-friendly)."),
    max_tasks: int = typer.Option(0, "--max-tasks", help="At most N tasks then exit (0=unbounded)."),
) -> None:
    """Drain the backlog. PROTOCOL-ZERO is the only stop signal in unbounded mode."""
    _preflight_initialized()
    _preflight_not_halted()
    _preflight_ollama_reachable()

    from .mode_controller import ControllerSettings, ModeController

    _print(BANNER)
    _print(Panel(
        "[bold yellow]BUSY mode[/bold yellow] — Tier 0 + Tier 1 only.\n"
        "Tier 2 and Tier 3 are not in the agent's tool list.\n"
        "Stop with: [cyan]sovereign halt[/cyan]  or  [cyan]echo > ~/.config/sovereign-agent/HALT[/cyan]",
        border_style="yellow",
    ))

    tools = _build_tools_for_mode(Mode.BUSY)
    settings = ControllerSettings(
        cooldown_seconds=cooldown, empty_backlog_sleep=empty_sleep,
        per_task_budget=RunBudget(max_iterations=max_iter_per_task,
                                  max_wall_seconds=max_wall_per_task),
    )
    controller = ModeController(tools=tools, settings=settings)
    try:
        if once:
            asyncio.run(controller._drain_iteration())
        elif max_tasks > 0:
            async def _bounded() -> None:
                count = 0
                while count < max_tasks and not protocol_zero.is_armed():
                    ran = await controller._drain_iteration()
                    if ran:
                        count += 1
                        await asyncio.sleep(cooldown)
                    else:
                        await asyncio.sleep(empty_sleep)
            asyncio.run(_bounded())
        else:
            asyncio.run(controller.run_busy())
    except KeyboardInterrupt:
        _print("\n[yellow]interrupted[/yellow]")
    _print("[green]busy mode stopped[/green]")


@app.command()
def until(
    minutes: int = typer.Option(..., "--minutes", help="Stop after this many minutes"),
    mode: Mode = typer.Option(Mode.ONESHOT, "--mode"),
) -> None:
    """Drain backlog until a time limit is reached."""
    _preflight_initialized()
    _preflight_not_halted()
    _preflight_ollama_reachable()

    from .mode_controller import ModeController

    end_ts = time.time() + minutes * 60
    tools = _build_tools_for_mode(mode)
    controller = ModeController(tools=tools)

    def _done() -> bool:
        return time.time() >= end_ts

    _print(f"\n◈ [bold]until[/bold] · stopping in {minutes} minutes\n")
    asyncio.run(controller.run_until(_done))


# ═══════════════════════════════════════════════════════════════════════════
#  RE-TRIGGER ARCHITECTURE — plan / continue / continuations
# ═══════════════════════════════════════════════════════════════════════════


plan_app = typer.Typer(help="◈ pre-decompose a large task into atomic continuation steps")


@app.command(name="plan")
def plan_cmd(
    planner: str | None = typer.Argument(None, help="Planner name (omit to list)."),
    root: Path | None = typer.Option(None, "--root", help="Root path the planner walks."),
    output: Path | None = typer.Option(None, "--output", help="Aggregation output."),
    pattern: list[str] = typer.Option([], "--pattern", help="Glob pattern. Repeatable."),
    max_files: int = typer.Option(0, "--max-files", help="Cap step count (0=unbounded)."),
    no_recursive: bool = typer.Option(False, "--no-recursive", help="Don't walk subdirs."),
    tag: str | None = typer.Option(None, "--tag", help="Tag (read-files planner)."),
    task_id: str | None = typer.Option(None, "--task-id", help="Override generated ULID."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show the plan, don't write."),
) -> None:
    """Run a planner. With no planner name, lists available planners."""
    from .planners import REGISTRY, get_planner
    from .planners.base import PlannerError, PlannerNotFound
    from .continuation import ContinuationStore

    if planner is None:
        if STATE.json_out:
            _emit_json({"planners": [
                {"name": p.name, "description": p.description,
                 "required_args": list(p.required_args())}
                for p in REGISTRY.values()
            ]})
            return
        table = Table(title="◈ planners", show_header=True, header_style="bold cyan")
        table.add_column("name", style="cyan")
        table.add_column("required args", style="magenta")
        table.add_column("description")
        for p in REGISTRY.values():
            table.add_row(p.name, ", ".join(p.required_args()) or "—", p.description)
        _print(table)
        _print("\n[dim]Run a planner: [/dim][cyan]sovereign plan inventory --root <dir> --output <file>[/cyan]")
        return

    try:
        planner_obj = get_planner(planner)
    except PlannerNotFound as e:
        _die(ExitCode.USAGE, str(e), hint="run `sovereign plan` to list planners")

    args = {
        "root": str(root) if root else None,
        "output": str(output) if output else None,
        "patterns": pattern or None,
        "max_files": max_files,
        "recursive": not no_recursive,
        "tag": tag,
    }
    args = {k: v for k, v in args.items() if v is not None}

    try:
        result = planner_obj.plan(**args)
    except PlannerError as e:
        _die(ExitCode.USAGE, f"plan failed: {e}")

    if dry_run:
        payload = {
            "ok": True, "dry_run": True, "planner": planner,
            "goal": result.goal, "step_count": len(result.steps),
            "output_path": result.output_path,
            "first_steps": [{"id": s.id, "kind": s.kind, "args": s.args}
                           for s in result.steps[:5]],
        }
        if STATE.json_out:
            _emit_json(payload)
        else:
            _print(Panel(
                f"[bold]{result.goal}[/bold]\n"
                f"steps: {len(result.steps)}\n"
                f"output: {result.output_path or '(none)'}\n"
                f"notes: {result.notes}",
                title=f"◈ plan (dry-run) · {planner}", border_style="cyan",
            ))
            if result.steps:
                t = Table(title="first 5 steps", show_header=True)
                t.add_column("id", style="dim")
                t.add_column("kind")
                t.add_column("args", overflow="fold")
                for s in result.steps[:5]:
                    t.add_row(str(s.id), s.kind, json.dumps(s.args, default=str)[:120])
                _print(t)
        return

    _preflight_initialized()
    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    cont = store.create(
        goal=result.goal, planner=planner, planner_args=args,
        steps=result.steps, output_path=result.output_path,
        task_id=task_id, notes=result.notes,
    )

    if STATE.json_out:
        _emit_json({"ok": True, "task_id": cont.task_id,
                    "step_count": len(cont.steps), "goal": cont.goal,
                    "output_path": cont.output_path})
    else:
        _print(Panel(
            f"[bold]{cont.goal}[/bold]\n"
            f"task_id: [cyan]{cont.task_id}[/cyan]\n"
            f"steps: {len(cont.steps)}\n"
            f"output: {cont.output_path or '(none)'}\n\n"
            f"[dim]drive it:[/dim] [cyan]sovereign continue {cont.task_id}[/cyan]\n"
            f"[dim]or loop:[/dim]  [cyan]scripts/sovereign-continue-loop.sh {cont.task_id}[/cyan]",
            title="◈ continuation created", border_style="green",
        ))


@app.command(name="continue")
def continue_(
    task_id: str = typer.Argument(..., help="Continuation ID from `sovereign plan`"),
    max_iter: int = typer.Option(5, "--max-iter", help="Per-step iteration cap."),
    max_wall: int = typer.Option(120, "--max-wall", help="Per-step wall-time cap (seconds)."),
    max_tokens: int = typer.Option(20_000, "--max-tokens", help="Per-step token cap."),
) -> None:
    """Execute exactly ONE pending step from a continuation, then exit.

    Exit codes: 0 step OK · 1 step poison · 3 halted · 8 drained · 9 locked
    """
    _preflight_initialized()
    _preflight_not_halted()
    _preflight_ollama_reachable()

    from .continuation import ContinuationStore
    from .continue_runner import run_one_step

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    tools = _build_tools_for_mode(Mode.ONESHOT)
    budget = RunBudget(max_iterations=max_iter, max_wall_seconds=max_wall,
                      max_tokens=max_tokens, consecutive_fail_limit=2)

    protocol_zero.install_signal_handlers()
    result = asyncio.run(run_one_step(
        task_id=task_id, tools=tools, store=store, budget=budget, mode=Mode.ONESHOT,
    ))

    payload = {
        "task_id": result.task_id, "step_id": result.step_id,
        "step_kind": result.step_kind, "outcome": result.outcome,
        "iterations": result.iterations, "tokens": result.tokens,
        "cont_status": result.cont_status, "progress": list(result.progress),
        "final_message": result.final_message,
    }

    if result.outcome == "locked":
        if STATE.json_out:
            _emit_json({"ok": False, "code": ExitCode.LOCKED, **payload})
        else:
            _print(f"[yellow]locked[/yellow] · {task_id} held by another runner")
        raise typer.Exit(ExitCode.LOCKED)

    if result.outcome in ("drained", "no_step"):
        if STATE.json_out:
            _emit_json({"ok": True, "code": ExitCode.DRAINED, **payload})
        else:
            done, total = result.progress
            _print(f"[green]drained[/green] · {done}/{total} · status={result.cont_status}")
        raise typer.Exit(ExitCode.DRAINED)

    if STATE.json_out:
        ok = result.outcome == "complete"
        _emit_json({"ok": ok, "code": ExitCode.OK if ok else ExitCode.ERROR, **payload})
    else:
        done, total = result.progress
        if result.outcome == "complete":
            _print(f"[green]✓ step {result.step_id}[/green] ({result.step_kind}) · "
                  f"{done}/{total} · iter={result.iterations} tokens={result.tokens}")
        else:
            _print(f"[red]✗ step {result.step_id}[/red] ({result.step_kind}) · "
                  f"{result.outcome} · {done}/{total}")
    raise typer.Exit(ExitCode.OK if result.outcome == "complete" else ExitCode.ERROR)


cont_app = typer.Typer(help="◈ inspect / manage continuation files")
app.add_typer(cont_app, name="continuations")


@cont_app.command("list")
def cont_list(status: str | None = typer.Option(None, "--status")) -> None:
    """List all continuation files with progress."""
    from .continuation import ContinuationStore

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    conts = store.list_all(status=status)

    if STATE.json_out:
        _emit_json({"continuations": [
            {"task_id": c.task_id, "status": c.status, "planner": c.planner,
             "goal": c.goal, "progress": list(c.progress),
             "updated_at": c.updated_at, "output_path": c.output_path}
            for c in conts
        ]})
        return

    if not conts:
        _print("[dim](no continuations)[/dim]")
        return

    table = Table(title="◈ continuations")
    table.add_column("task_id", style="cyan")
    table.add_column("status")
    table.add_column("planner", style="magenta")
    table.add_column("progress", justify="right")
    table.add_column("goal", overflow="fold")
    for c in conts:
        done, total = c.progress
        color = {"planned": "yellow", "in_progress": "cyan", "done": "green",
                 "poisoned": "red", "halted": "red"}.get(c.status, "white")
        table.add_row(c.task_id, f"[{color}]{c.status}[/{color}]",
                     c.planner, f"{done}/{total}", c.goal[:80])
    _print(table)


@cont_app.command("show")
def cont_show(task_id: str) -> None:
    """Show a continuation in detail, including all steps."""
    from .continuation import ContinuationNotFound, ContinuationStore

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    try:
        cont = store.get(task_id)
    except ContinuationNotFound:
        _die(ExitCode.USAGE, f"continuation not found: {task_id}")

    if STATE.json_out:
        from dataclasses import asdict
        _emit_json({
            "task_id": cont.task_id, "goal": cont.goal,
            "planner": cont.planner, "planner_args": cont.planner_args,
            "status": cont.status, "progress": list(cont.progress),
            "output_path": cont.output_path, "notes": cont.notes,
            "created_at": cont.created_at, "updated_at": cont.updated_at,
            "steps": [asdict(s) for s in cont.steps],
        })
        return

    done, total = cont.progress
    _print(Panel(
        f"[bold]{cont.goal}[/bold]\n"
        f"planner: {cont.planner}\n"
        f"status: {cont.status} · progress: {done}/{total}\n"
        f"output: {cont.output_path or '(none)'}\n"
        f"created: {cont.created_at}\n"
        f"updated: {cont.updated_at}",
        title=f"◈ {cont.task_id}", border_style="cyan",
    ))

    table = Table(title="steps", show_header=True)
    table.add_column("id", style="dim", width=4)
    table.add_column("kind", style="magenta")
    table.add_column("status")
    table.add_column("iter", justify="right")
    table.add_column("tokens", justify="right")
    table.add_column("args", overflow="fold")
    for s in cont.steps:
        color = {"pending": "yellow", "done": "green",
                 "poisoned": "red", "skipped": "dim"}.get(s.status, "white")
        table.add_row(str(s.id), s.kind, f"[{color}]{s.status}[/{color}]",
                     str(s.iterations), str(s.tokens),
                     json.dumps(s.args, default=str)[:80])
    _print(table)


@cont_app.command("delete")
def cont_delete(task_id: str) -> None:
    """Delete a continuation. Refuses if a runner holds the lock."""
    from .continuation import ContinuationLocked, ContinuationStore

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    try:
        existed = store.delete(task_id)
    except ContinuationLocked:
        _die(ExitCode.LOCKED, f"continuation {task_id} is locked by a runner")

    if STATE.json_out:
        _emit_json({"ok": existed, "task_id": task_id, "deleted": existed})
    elif existed:
        _print(f"[green]deleted[/green] {task_id}")
    else:
        _print(f"[yellow]not found[/yellow] {task_id}")


# ═══════════════════════════════════════════════════════════════════════════
#  BACKLOG
# ═══════════════════════════════════════════════════════════════════════════


backlog_app = typer.Typer(help="◈ manage the task backlog")
app.add_typer(backlog_app, name="backlog")


@backlog_app.command("list")
def backlog_list(status: str | None = typer.Option(None, "--status")) -> None:
    """Show the current backlog."""
    from .mode_controller import read_backlog

    tasks = read_backlog()
    if status:
        tasks = [t for t in tasks if t.status == status]

    if STATE.json_out:
        _emit_json({"tasks": [
            {"id": t.id, "priority": t.priority, "mode": t.mode,
             "status": t.status, "goal": t.goal, "notes": t.notes}
            for t in tasks
        ]})
        return

    if not tasks:
        _print("[dim](backlog empty)[/dim]")
        return

    table = Table(title="◈ backlog")
    table.add_column("id", style="cyan")
    table.add_column("priority", style="magenta")
    table.add_column("mode")
    table.add_column("status")
    table.add_column("goal", overflow="fold")
    for t in tasks:
        status_color = {"pending": "yellow", "running": "cyan", "done": "green",
                       "poison": "red", "budget": "yellow", "halted": "red"}.get(t.status, "white")
        table.add_row(t.id[:18], t.priority, t.mode,
                     f"[{status_color}]{t.status}[/{status_color}]", t.goal[:80])
    _print(table)


@backlog_app.command("add")
def backlog_add(
    goal: str = typer.Argument(...),
    priority: str = typer.Option("medium", "--priority"),
    mode: str = typer.Option("oneshot", "--mode"),
) -> None:
    """Add a task to the backlog."""
    from .mode_controller import add_task
    task = add_task(goal=goal, priority=priority, mode=mode)
    if STATE.json_out:
        _emit_json({"ok": True, "id": task.id})
    else:
        _print(f"[green]added[/green] {task.id}")


@backlog_app.command("remove")
def backlog_remove(task_id: str) -> None:
    """Remove a task from the backlog by id."""
    from .mode_controller import remove_task
    if remove_task(task_id):
        if STATE.json_out:
            _emit_json({"ok": True, "id": task_id})
        else:
            _print(f"[green]removed[/green] {task_id}")
    else:
        if STATE.json_out:
            _emit_json({"ok": False, "id": task_id})
        else:
            _print(f"[yellow]not found[/yellow] {task_id}")


@backlog_app.command("show")
def backlog_show(task_id: str) -> None:
    """Show one task in detail."""
    from .mode_controller import read_backlog
    task = next((t for t in read_backlog() if t.id == task_id or t.id.startswith(task_id)), None)
    if task is None:
        _die(ExitCode.USAGE, f"task not found: {task_id}")

    if STATE.json_out:
        _emit_json({"id": task.id, "goal": task.goal, "priority": task.priority,
                   "mode": task.mode, "status": task.status, "notes": task.notes})
        return

    _print(Panel(
        f"[bold]{task.goal}[/bold]\n"
        f"id: {task.id}\n"
        f"priority: {task.priority}\n"
        f"mode: {task.mode}\n"
        f"status: {task.status}\n"
        f"notes: {task.notes or '(none)'}",
        title=f"◈ {task.id[:18]}",
    ))


@backlog_app.command("requeue")
def backlog_requeue(task_id: str) -> None:
    """Reset a task to 'pending' so it'll be picked up again."""
    from .mode_controller import read_backlog, write_backlog
    tasks = read_backlog()
    target = next((t for t in tasks if t.id == task_id), None)
    if target is None:
        _die(ExitCode.USAGE, f"task not found: {task_id}")
    target.status = "pending"
    target.notes = "requeued by operator"
    write_backlog(tasks)
    if STATE.json_out:
        _emit_json({"ok": True, "id": task_id})
    else:
        _print(f"[green]requeued[/green] {task_id}")


@backlog_app.command("priority")
def backlog_priority(
    task_id: str,
    priority: str = typer.Argument(..., help="critical | high | medium | low"),
) -> None:
    """Change a task's priority."""
    valid = {"critical", "high", "medium", "low"}
    if priority not in valid:
        _die(ExitCode.USAGE, f"priority must be one of {sorted(valid)}")

    from .mode_controller import read_backlog, write_backlog
    tasks = read_backlog()
    target = next((t for t in tasks if t.id == task_id), None)
    if target is None:
        _die(ExitCode.USAGE, f"task not found: {task_id}")
    target.priority = priority
    write_backlog(tasks)
    if STATE.json_out:
        _emit_json({"ok": True, "id": task_id, "priority": priority})
    else:
        _print(f"[green]priority={priority}[/green] {task_id}")


@backlog_app.command("clear")
def backlog_clear(
    status: str = typer.Option(..., "--status", help="Clear tasks with this status."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Remove all tasks with the given status."""
    from .mode_controller import read_backlog, write_backlog

    tasks = read_backlog()
    keep = [t for t in tasks if t.status != status]
    removed = len(tasks) - len(keep)
    if removed == 0:
        _print(f"[dim]no tasks with status={status!r}[/dim]")
        return
    if not yes and not STATE.json_out:
        if not typer.confirm(f"Remove {removed} task(s) with status={status!r}?"):
            _print("[dim]cancelled[/dim]")
            return
    write_backlog(keep)
    if STATE.json_out:
        _emit_json({"ok": True, "removed": removed, "status": status})
    else:
        _print(f"[green]cleared[/green] {removed} task(s) with status={status!r}")


# ═══════════════════════════════════════════════════════════════════════════
#  APPROVALS
# ═══════════════════════════════════════════════════════════════════════════


def _parse_expiry(expiry_ts: str) -> datetime | None:
    """RFC3339-ish expiry parser. Tolerates whole-second AND fractional forms.

    The v0.2.4 implementation hard-coded ``%Y-%m-%dT%H:%M:%S.%f%z`` which
    silently fails on whole-second timestamps. Falls back to fromisoformat
    which Python 3.11 accepts both forms of.
    """
    if not expiry_ts:
        return None
    s = expiry_ts.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def _scan_pending_approval_requests() -> list[dict]:
    """Find approval-needed-d events that haven't been resolved."""
    from .events import init_events_db, tail_to_sqlite

    conn = init_events_db()
    tail_to_sqlite(conn)
    rows = conn.execute(
        "SELECT event_id, ts, payload FROM events "
        "WHERE flag = 'approval-needed-d' ORDER BY ts ASC"
    ).fetchall()

    pending: list[dict] = []
    for ev_id, ts, payload_json in rows:
        try:
            payload = json.loads(payload_json)
        except json.JSONDecodeError:
            continue

        resolved = conn.execute(
            "SELECT 1 FROM events "
            "WHERE flag IN ('approval-d', 'approval-x', 'approval-denied-d') "
            "AND payload LIKE ? LIMIT 1",
            (f'%"event_id":"{ev_id}"%',),
        ).fetchone()
        if resolved:
            continue

        expiry = _parse_expiry(payload.get("expiry_ts", ""))
        if expiry and datetime.now(timezone.utc) >= expiry:
            continue

        pending.append({
            "event_id": ev_id, "requested_at": ts,
            "tool_name": payload.get("tool_name"),
            "args_hash": payload.get("args_hash"),
            "args_preview": payload.get("args_preview"),
            "justification": payload.get("justification"),
            "expiry_ts": payload.get("expiry_ts"),
            "expiry_dt": expiry,
        })

    conn.close()
    return pending


def _format_ttl(expiry: datetime | None) -> str:
    if expiry is None:
        return "(unknown)"
    delta = expiry - datetime.now(timezone.utc)
    secs = int(delta.total_seconds())
    if secs <= 0:
        return "expired"
    if secs < 60:
        return f"{secs}s"
    if secs < 3600:
        return f"{secs // 60}m {secs % 60}s"
    return f"{secs // 3600}h {(secs % 3600) // 60}m"


@app.command()
def approvals() -> None:
    """List pending Tier 3 approval requests."""
    pending = _scan_pending_approval_requests()

    if STATE.json_out:
        _emit_json({"pending": [
            {**{k: v for k, v in p.items() if k != "expiry_dt"},
             "ttl": _format_ttl(p.get("expiry_dt"))}
            for p in pending
        ]})
        return

    if not pending:
        _print("[dim](no pending approvals)[/dim]")
        return

    for req in pending:
        ttl = _format_ttl(req.get("expiry_dt"))
        body = (
            f"[bold]tool:[/bold]      {req['tool_name']}\n"
            f"[bold]requested:[/bold] {req['requested_at']}\n"
            f"[bold]expires in:[/bold] {ttl}\n"
            f"[bold]args:[/bold]      {req['args_preview']}\n"
            f"[bold]reason:[/bold]    {req['justification']}\n\n"
            f"[dim]grant:  sovereign approve {req['event_id']}\n"
            f"deny:   sovereign deny {req['event_id']}[/dim]"
        )
        _print(Panel(body, title=f"◈ {req['event_id']}", border_style="yellow"))


@app.command()
def approve(
    event_id: str,
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Grant a Tier 3 approval. The agent picks it up on next dispatch."""
    pending = _scan_pending_approval_requests()
    match = next((p for p in pending if p["event_id"] == event_id), None)
    if match is None:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"not found or already resolved: {event_id}")

    if not yes and not STATE.json_out:
        body = (
            f"tool:      {match['tool_name']}\n"
            f"args:      {match['args_preview']}\n"
            f"reason:    {match['justification']}\n"
            f"expires:   {match['expiry_ts']}"
        )
        _print(Panel(body, title=f"◈ approve {event_id}?", border_style="yellow"))
        if not typer.confirm("Grant this approval?"):
            _print("[dim]cancelled[/dim]")
            raise typer.Exit(ExitCode.OK)

    from .approval import ApprovalRequest, write_grant
    req = ApprovalRequest(
        event_id=event_id, tool_name=match["tool_name"], args={},
        args_hash=match["args_hash"], justification=match["justification"] or "",
        expiry_ts=match["expiry_ts"],
    )
    write_grant(req)
    if STATE.json_out:
        _emit_json({"ok": True, "granted": event_id})
    else:
        _print(f"[green]✓ granted[/green] {event_id}")


@app.command()
def deny(event_id: str, reason: str = typer.Option("operator denied", "--reason")) -> None:
    """Refuse a Tier 3 approval."""
    from .approval import write_denial
    write_denial(event_id, trace_id="cli-deny", reason=reason)
    if STATE.json_out:
        _emit_json({"ok": True, "denied": event_id, "reason": reason})
    else:
        _print(f"[red]✗ denied[/red] {event_id}")


# ═══════════════════════════════════════════════════════════════════════════
#  SAFETY
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def halt(reason: str = typer.Option("operator", "--reason")) -> None:
    """Trip PROTOCOL-ZERO. The agent halts at the next iteration boundary."""
    protocol_zero.arm(reason)
    if STATE.json_out:
        _emit_json({"ok": True, "halted": True, "reason": reason})
    else:
        _print(Panel(
            f"[red]PROTOCOL-ZERO armed[/red]\nreason: {reason}\n\n"
            f"[dim]clear with: sovereign disarm[/dim]",
            border_style="red",
        ))


@app.command()
def disarm() -> None:
    """Clear PROTOCOL-ZERO. Manual ack required after operator review."""
    protocol_zero.disarm()
    if STATE.json_out:
        _emit_json({"ok": True, "disarmed": True})
    else:
        _print("[green]✓ disarmed[/green]")


# ═══════════════════════════════════════════════════════════════════════════
#  AUDIT
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def tail() -> None:
    """Ingest events.jsonl into the SQLite events projection."""
    conn = init_events_db()
    inserted = tail_to_sqlite(conn)
    conn.close()
    if STATE.json_out:
        _emit_json({"ok": True, "inserted": inserted})
    else:
        _print(f"[green]ingested[/green] {inserted} events")


@app.command()
def seal() -> None:
    """Compute yesterday's Merkle seal over events.jsonl."""
    from .seal import seal_yesterday
    root = seal_yesterday()
    if STATE.json_out:
        _emit_json({"ok": True, "root": root})
        return
    if root:
        _print(f"[green]✓ sealed[/green] yesterday: [cyan]{root}[/cyan]")
    else:
        _print("[dim]no events to seal[/dim]")


@app.command()
def verify(target_date: str = typer.Argument(..., help="YYYY-MM-DD")) -> None:
    """Verify a past seal still matches its events file."""
    from .seal import verify_seal
    try:
        d = date.fromisoformat(target_date)
    except ValueError:
        _die(ExitCode.USAGE, f"invalid date: {target_date}")

    matches, msg = verify_seal(d)
    if STATE.json_out:
        _emit_json({"ok": matches, "message": msg, "date": target_date})
    else:
        style = "green" if matches else "red"
        _print(f"[{style}]{msg}[/{style}]")
    raise typer.Exit(ExitCode.OK if matches else ExitCode.ERROR)


@app.command()
def events(
    n: int = typer.Option(20, "-n", help="How many recent events to show"),
    flag: str | None = typer.Option(None, "--flag", help="Filter by flag (e.g., 'tool-x')"),
    follow: bool = typer.Option(False, "--follow", "-f", help="tail -f mode (Ctrl-C to stop)"),
    interval: float = typer.Option(1.0, "--interval", help="Poll interval for --follow."),
) -> None:
    """Show recent events from the SQLite projection.

    With ``--follow``, polls for new events forever (Ctrl-C to stop).
    """
    if follow:
        _follow_events(flag=flag, interval=interval)
        return

    conn = init_events_db()
    tail_to_sqlite(conn)
    if flag:
        rows = conn.execute(
            "SELECT ts, flag, trace_id, payload FROM events "
            "WHERE flag = ? ORDER BY ts DESC LIMIT ?",
            (flag, n),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT ts, flag, trace_id, payload FROM events "
            "ORDER BY ts DESC LIMIT ?", (n,),
        ).fetchall()
    conn.close()

    if STATE.json_out:
        _emit_json({"events": [
            {"ts": ts, "flag": fl, "trace_id": tid, "payload": pl}
            for ts, fl, tid, pl in rows
        ]})
        return

    table = Table(title="◈ recent events" + (f" (flag={flag})" if flag else ""))
    table.add_column("ts", style="dim")
    table.add_column("flag", style="cyan")
    table.add_column("trace", style="dim")
    table.add_column("payload", overflow="fold")
    for ts, fl, tid, pl in rows:
        table.add_row(ts.split("T")[1][:12], fl, tid[:8], pl[:80])
    _print(table)


def _follow_events(*, flag: str | None, interval: float) -> None:
    """tail -f over the events table."""
    conn = init_events_db()
    tail_to_sqlite(conn)
    last_ts = ""
    row = conn.execute("SELECT MAX(ts) FROM events").fetchone()
    if row and row[0]:
        last_ts = row[0]
    if not STATE.json_out:
        _print(f"[dim]following events (interval={interval}s, Ctrl-C to stop)…[/dim]")
    try:
        while True:
            tail_to_sqlite(conn)
            if flag:
                rows = conn.execute(
                    "SELECT ts, flag, trace_id, payload FROM events "
                    "WHERE flag = ? AND ts > ? ORDER BY ts ASC LIMIT 100",
                    (flag, last_ts),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT ts, flag, trace_id, payload FROM events "
                    "WHERE ts > ? ORDER BY ts ASC LIMIT 100", (last_ts,),
                ).fetchall()
            for ts, fl, tid, pl in rows:
                if STATE.json_out:
                    _emit_json({"ts": ts, "flag": fl, "trace_id": tid, "payload": pl})
                else:
                    _print(f"[dim]{ts.split('T')[1][:12]}[/dim] [cyan]{fl}[/cyan] {tid[:8]} {pl[:120]}")
                last_ts = ts
            time.sleep(interval)
    except KeyboardInterrupt:
        if not STATE.json_out:
            _print("\n[dim]stopped[/dim]")
    finally:
        conn.close()


@app.command()
def lessons(n: int = typer.Option(10, "-n")) -> None:
    """Show recent distilled lessons from the Reflector."""
    from .db import open_atoms_db
    conn = open_atoms_db()
    rows = conn.execute(
        "SELECT ts, trigger, rule, confidence FROM lessons "
        "ORDER BY ts DESC LIMIT ?", (n,),
    ).fetchall()
    conn.close()

    if STATE.json_out:
        _emit_json({"lessons": [
            {"ts": ts, "trigger": trigger, "rule": rule, "confidence": conf}
            for ts, trigger, rule, conf in rows
        ]})
        return

    if not rows:
        _print("[dim](no lessons yet)[/dim]")
        return

    table = Table(title="◈ lessons")
    table.add_column("when", style="dim")
    table.add_column("trigger", style="yellow")
    table.add_column("confidence", justify="right")
    table.add_column("rule")
    for ts, trigger, rule, conf in rows:
        table.add_row(ts.split("T")[0], trigger[:30], f"{conf:.2f}", rule)
    _print(table)


if __name__ == "__main__":
    app()
