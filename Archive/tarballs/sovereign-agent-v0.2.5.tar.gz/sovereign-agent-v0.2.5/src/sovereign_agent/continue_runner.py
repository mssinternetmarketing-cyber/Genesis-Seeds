"""
╔══════════════════════════════════════════════════════════════════════════╗
║  continue_runner.py — Re-trigger executor                                ║
║  Architecture §13 (new in v0.2.5)                                        ║
╚══════════════════════════════════════════════════════════════════════════╝

One ``sovereign continue <task_id>`` invocation does exactly this:

    1. Acquire exclusive lock on the continuation
    2. Read the continuation's next pending step
    3. Render it into a goal string via the planner
    4. Run agent_loop(goal, mode=ONESHOT, budget=<small>)
    5. Update the step's status from the LoopResult
    6. Recompute continuation.status
    7. Release lock and exit

The model only sees ONE step's worth of context per invocation. Memory
across invocations is durable: events.jsonl, atoms.db, lessons. The
continuation file remembers the cursor position.

This module does NOT loop. The driver (cron, systemd timer, or the
shipped ``sovereign-continue-loop.sh`` script) is responsible for repeated
invocation. That separation is intentional — it lets the OS manage the
process lifecycle, which is much more robust than a Python while-loop
trying to be its own scheduler.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

from .config import SETTINGS
from .continuation import (
    Continuation,
    ContinuationLocked,
    ContinuationNotFound,
    ContinuationStore,
    Step,
)
from .events import emit_event
from .modes import Mode, RunBudget
from .planners import get_planner
from .planners.base import Planner


@dataclass
class StepRunResult:
    """Outcome of running a single continuation step."""

    task_id: str
    step_id: int
    step_kind: str
    outcome: str                # "complete" | "budget" | "poison" | "halted" | "drained" | "locked" | "no_step"
    iterations: int = 0
    tokens: int = 0
    final_message: str | None = None
    cont_status: str = ""       # status of the parent continuation after this step
    progress: tuple[int, int] = (0, 0)


# Default per-step budget. Generous on iterations (a step might require
# 2-3 tool calls), tight on wall-time so a hung step doesn't block the
# driver loop forever. Override per-invocation via run_one_step(budget=…).
DEFAULT_STEP_BUDGET = RunBudget(
    max_iterations=5,
    max_wall_seconds=120,
    max_tokens=20_000,
    consecutive_fail_limit=2,
)


def _bind_step_to_loop_result(
    step: Step, loop_result, *, planner: Planner, planner_args: dict
) -> None:
    """Mutate ``step`` to reflect the loop's outcome.

    Maps loop reasons to step statuses:
      complete → done
      poison   → poisoned
      budget   → poisoned (we treat budget-exhaustion as poisoning the step;
                 the operator can replan a smaller version)
      halted   → leave as pending; the operator should disarm and retry
    """
    step.iterations = loop_result.iterations
    step.tokens = loop_result.tokens_used
    step.completed_at = _utc_now()

    if loop_result.reason == "complete":
        step.status = "done"
        step.result = (loop_result.final_message or "")[:500] or None
    elif loop_result.reason == "poison":
        step.status = "poisoned"
        step.error = (loop_result.final_message or "poison")[:500]
    elif loop_result.reason == "budget":
        step.status = "poisoned"
        step.error = "budget exhausted on step"
    elif loop_result.reason == "halted":
        # Roll back: the step did not get a fair shot.
        step.status = "pending"
        step.completed_at = None
    else:
        step.status = "poisoned"
        step.error = f"unknown loop outcome: {loop_result.reason!r}"


def _utc_now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


async def run_one_step(
    *,
    task_id: str,
    tools: dict,
    store: ContinuationStore | None = None,
    budget: RunBudget | None = None,
    mode: Mode = Mode.ONESHOT,
) -> StepRunResult:
    """Execute exactly one pending step from a continuation.

    Acquires the lock non-blocking. If the lock is held by another runner,
    returns a ``locked`` result without invoking the model — the caller (a
    driver loop) should sleep and retry.

    If the continuation is drained (all steps terminal) or has no pending
    steps, returns a ``drained`` / ``no_step`` result without invoking the
    model.

    The model is invoked at most ONCE per call, even if more pending steps
    remain. The driver re-invokes us for the next step. This is the
    architectural property that bounds the model's per-invocation context.
    """
    from .loop import agent_loop  # local import — avoid loop-import cycle

    store = store or ContinuationStore(SETTINGS.paths.continuations_dir)
    budget = budget or DEFAULT_STEP_BUDGET

    try:
        # Non-blocking lock — drivers should expect contention and retry.
        with store.lock(task_id, blocking=False) as cont:
            return await _run_one_step_locked(
                cont=cont, tools=tools, budget=budget, mode=mode
            )
    except ContinuationLocked:
        return StepRunResult(
            task_id=task_id,
            step_id=-1,
            step_kind="",
            outcome="locked",
        )
    except ContinuationNotFound:
        return StepRunResult(
            task_id=task_id,
            step_id=-1,
            step_kind="",
            outcome="no_step",
        )


async def _run_one_step_locked(
    *, cont: Continuation, tools: dict, budget: RunBudget, mode: Mode
) -> StepRunResult:
    """Execute one step. Caller holds the continuation lock."""
    from .loop import agent_loop

    if cont.is_drained():
        return StepRunResult(
            task_id=cont.task_id,
            step_id=-1,
            step_kind="",
            outcome="drained",
            cont_status=cont.status,
            progress=cont.progress,
        )

    step = cont.next_pending()
    if step is None:
        return StepRunResult(
            task_id=cont.task_id,
            step_id=-1,
            step_kind="",
            outcome="no_step",
            cont_status=cont.status,
            progress=cont.progress,
        )

    planner = get_planner(cont.planner)
    rendered_goal = planner.render_step(step, cont.planner_args)

    emit_event(
        "continue-start-d",
        plane="control",
        trace_id=f"cont:{cont.task_id}",
        payload={
            "task_id": cont.task_id,
            "step_id": step.id,
            "step_kind": step.kind,
            "planner": cont.planner,
        },
    )

    step.started_at = _utc_now()
    step.status = "pending"  # explicit; will be mutated by _bind_step_to_loop_result

    started_wall = time.monotonic()
    loop_result = await agent_loop(
        goal=rendered_goal,
        mode=mode,
        budget=budget,
        tools=tools,
    )
    elapsed = time.monotonic() - started_wall

    _bind_step_to_loop_result(
        step, loop_result, planner=planner, planner_args=cont.planner_args
    )
    cont.update_status_from_steps()

    emit_event(
        "continue-end-d",
        plane="control",
        trace_id=f"cont:{cont.task_id}",
        payload={
            "task_id": cont.task_id,
            "step_id": step.id,
            "outcome": loop_result.reason,
            "step_status": step.status,
            "iterations": loop_result.iterations,
            "tokens": loop_result.tokens_used,
            "elapsed_seconds": round(elapsed, 2),
            "cont_status": cont.status,
            "progress": list(cont.progress),
        },
    )

    return StepRunResult(
        task_id=cont.task_id,
        step_id=step.id,
        step_kind=step.kind,
        outcome=loop_result.reason or "complete",
        iterations=loop_result.iterations,
        tokens=loop_result.tokens_used,
        final_message=loop_result.final_message,
        cont_status=cont.status,
        progress=cont.progress,
    )
