"""
╔══════════════════════════════════════════════════════════════════════════╗
║  horizon.py — Just-Horizon document generator                            ║
║  v0.2.14 · MOS canon §6.5                                                 ║
║                                                                           ║
║  A Horizon Scan is a forward projection: will this design still be the  ║
║  right one in 3 months? 12 months? 3 years? 7 generations? It is part   ║
║  of the MOS universal workflow loop, called after Angel's Advocate and  ║
║  before Transmit.                                                        ║
║                                                                           ║
║  This module renders a Horizon Scan as a markdown document, optionally  ║
║  saves it through the appendix system, and returns the rendered text   ║
║  for inclusion in CLI output or model prompts.                          ║
║                                                                           ║
║  THE FOUR HORIZONS                                                       ║
║                                                                           ║
║    3-month — what must be true for this to remain right?                 ║
║    12-month — emerging risks, protocol changes, capability shifts        ║
║    3-year — architectural bets; what becomes irreversible                ║
║    7th-generation — sovereignty, lock-in, flourishing trajectory         ║
║                                                                           ║
║  Aria emits these proactively at major decision points (dream start,    ║
║  project pivots, financial commitments) and the operator can request   ║
║  one any time via `sov horizon scan`.                                   ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path


@dataclass
class HorizonInputs:
    """The decision under audit. Caller fills in what they know.

    Empty fields render as "(none specified)" in the output rather than
    crashing — Horizon Scans are scaffolds; they accept partial input.
    """
    label: str                              # short title for the scan
    decision: str                           # what is being decided
    three_month: str = ""                   # what must remain true
    twelve_month: str = ""                  # emerging risks
    three_year: str = ""                    # irreversibility points
    seventh_generation: str = ""            # sovereignty / flourishing
    emerging_signals: list[str] = field(default_factory=list)
    best_forward_path: str = ""             # the one thing to prioritize


def render(inputs: HorizonInputs) -> str:
    """Render a Horizon Scan as markdown.

    Output shape mirrors the MOS canon §6.5 template exactly, so the
    rendered doc is reusable in operator briefings, ADRs, and PR
    descriptions without translation.
    """
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    lines = [
        f"# Horizon Scan — {inputs.label}",
        "",
        f"*Generated {now} by Aria-Sovereign-V1*",
        "",
        f"**Decision:** {inputs.decision}",
        "",
        "## 3-month",
        "",
        f"_What must be true for this to remain right?_",
        "",
        inputs.three_month or "(none specified)",
        "",
        "## 12-month",
        "",
        f"_Emerging risks, protocol changes, capability shifts._",
        "",
        inputs.twelve_month or "(none specified)",
        "",
        "## 3-year",
        "",
        f"_Architectural bets; what becomes irreversible._",
        "",
        inputs.three_year or "(none specified)",
        "",
        "## 7th-generation",
        "",
        f"_Sovereignty, lock-in, flourishing trajectory._",
        "",
        inputs.seventh_generation or "(none specified)",
        "",
        "## Emerging signals to watch",
        "",
    ]
    if inputs.emerging_signals:
        for sig in inputs.emerging_signals:
            lines.append(f"- {sig}")
    else:
        lines.append("(none yet identified)")
    lines.append("")
    lines.append("## ✅ Best forward path")
    lines.append("")
    lines.append(inputs.best_forward_path or "(decide before transmit)")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("*Per MOS canon §6.5. Score ≤ −1 escalates; −2 rejects.*")
    return "\n".join(lines)


def save_through_appendix(
    conn,
    *,
    appendix_dir: Path,
    inputs: HorizonInputs,
    atom_id: str | None = None,
):
    """Generate a Horizon Scan and persist it through the appendix system.

    Returns the AppendixDoc record. Convenience wrapper combining
    `render()` with `appendix.write_doc()`.
    """
    from .appendix import write_doc
    body = render(inputs)
    return write_doc(
        conn, appendix_dir=appendix_dir,
        kind="horizon", title=f"Horizon: {inputs.label}",
        body=body, summary=inputs.decision,
        atom_id=atom_id, created_by="aria-horizon",
    )


__all__ = [
    "HorizonInputs",
    "render",
    "save_through_appendix",
]
