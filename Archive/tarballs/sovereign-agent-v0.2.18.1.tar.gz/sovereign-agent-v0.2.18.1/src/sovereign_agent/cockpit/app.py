"""
╔══════════════════════════════════════════════════════════════════════════╗
║  cockpit/app.py — sovereign-agent operator cockpit                       ║
║  v0.2.15.3 · Aria-Sovereign-V1                                            ║
║                                                                            ║
║  A full-screen TUI for talking to the agent. Built on Textual.            ║
║                                                                            ║
║  Layout:                                                                   ║
║                                                                            ║
║    ┌─ sovereign-agent · cockpit ───── 0.2.15.3 · ◈ calm ─┐                ║
║    │┌─ chat ────────────────────┐┌─ live ──────────────┐│                ║
║    ││ history scrolls here       ││ events stream        ││                ║
║    ││                            ││ snapshot age         ││                ║
║    ││                            ││ continuations active ││                ║
║    │└────────────────────────────┘└──────────────────────┘│                ║
║    │┌─ input ──────────────────────────────────────────────┐│                ║
║    ││ > _                                                  ││                ║
║    │└──────────────────────────────────────────────────────┘│                ║
║    │ HALT · daemon · ledger · backup                       │                ║
║    └────────────────────────────────────────────────────────┘                ║
║                                                                            ║
║  Bindings:                                                                 ║
║    Enter      submit input                                                 ║
║    Ctrl-Q    quit cockpit (agent keeps running)                            ║
║    Ctrl-H    halt the agent (PROTOCOL-ZERO)                                ║
║    Ctrl-D    disarm PROTOCOL-ZERO                                          ║
║    Ctrl-L    clear chat pane                                               ║
║    F1        help overlay                                                  ║
║                                                                            ║
║  Execution model:                                                          ║
║    User input → spawn ``sovereign do "..."`` in a subprocess.             ║
║    Stream its stdout to the chat pane.                                    ║
║    In parallel, tail events.jsonl and forward new events to live pane.    ║
║    Status bar refreshes every 5 seconds (ledger audit, snapshot age).     ║
║                                                                            ║
║  What this doesn't do (deferred to later releases):                       ║
║    - Inline Tier 3 approval modal (use 'sov approvals' in another shell)  ║
║    - Multi-conversation tabs                                              ║
║    - Search over chat history (chat is in atoms.db; search via channels)  ║
║    - Dream-tail integration (use 'sov dream tail' in another shell)       ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import asyncio
import json
import os
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.widgets import (
    Footer, Header, Input, Label, RichLog, Static,
)

from .sysmon import (
    SystemMonitor, SystemSnapshot,
    render_compact_metrics, render_health_report,
)


# ─── Helpers ────────────────────────────────────────────────────────────────


def _now_short() -> str:
    return datetime.now().strftime("%H:%M:%S")


def _format_age(seconds: Optional[float]) -> str:
    if seconds is None:
        return "—"
    if seconds < 60:
        return f"{seconds:.0f}s"
    if seconds < 3600:
        return f"{seconds/60:.0f}m"
    if seconds < 86400:
        return f"{seconds/3600:.1f}h"
    return f"{seconds/86400:.1f}d"


@dataclass
class CockpitStatus:
    """Single snapshot of system state for the status bar."""
    halt: bool = False
    daemon_active: bool = False
    ledger_clean: bool = True
    ledger_rows: int = 0
    snapshot_age_seconds: Optional[float] = None
    snapshot_verify_ok: bool = True
    version: str = "0.2.15.3"
    mood: str = "calm"
    # System metrics (set by SystemMonitor.read())
    system: Optional["SystemSnapshot"] = None
    # VRAM (set by sovereign_agent.vram.read_vram())
    vram_total_mb: Optional[int] = None
    vram_used_mb: Optional[int] = None
    vram_source: str = ""
    vram_temp_c: Optional[float] = None


# ─── Help overlay ───────────────────────────────────────────────────────────


class HelpScreen(ModalScreen):
    """F1 → modal with keybindings and routing reference."""

    BINDINGS = [Binding("escape,f1,q", "app.pop_screen", "close")]

    def compose(self) -> ComposeResult:
        yield Vertical(
            Static(
                "[b]sovereign-agent cockpit · help[/b]\n\n"
                "[b]How to talk to aria[/b]\n"
                "  Type a [b]direction[/b] in plain english — what you want done.\n"
                "  Aria parses it, plans the commands, and executes. You\n"
                "  never need to know the underlying CLI. Steps stream into\n"
                "  the chat pane as they happen; events appear on the right.\n\n"
                "  Examples:\n"
                "    [dim]> inventory ~/AA-Erebo for markdown files[/dim]\n"
                "    [dim]> build trillion-dollar software, max 2000 files[/dim]\n"
                "    [dim]> show me what's happening[/dim]\n"
                "    [dim]> pause my dream[/dim]\n\n"
                "[b]Slash commands (operator overrides)[/b]\n"
                "  /halt           PROTOCOL-ZERO\n"
                "  /disarm         clear PROTOCOL-ZERO\n"
                "  /snap [label]   take a snapshot\n"
                "  /audit          run financial audit\n"
                "  /events [N]     dump latest N events to chat\n"
                "  /lessons        recent lesson atoms\n"
                "  /health         quick system health summary\n"
                "  /report         full health report, saved to disk\n"
                "  /drafts [N]     list archived drafts (newest first)\n"
                "  /draft <t> <p>  archive a project under <data>/drafts\n"
                "  /marketing <p>  generate a marketing brief for <product>\n"
                "  /heart          toggle the heartbeat badge\n"
                "  /clear          clear chat\n"
                "  /help           this help\n"
                "  /quit           quit\n\n"
                "[b]Keys[/b]\n"
                "  Enter           submit input\n"
                "  Ctrl-Q          quit cockpit (agent keeps running)\n"
                "  Ctrl-H          [red]halt[/red] (PROTOCOL-ZERO)\n"
                "  Ctrl-D          [green]disarm[/green] PROTOCOL-ZERO\n"
                "  Ctrl-L          clear chat pane\n"
                "  Ctrl-B          toggle the [red]♥[/red] heartbeat\n"
                "  F1, ?           this help\n"
                "  Esc             close overlay\n\n"
                "[dim]Esc to close[/dim]",
                id="help-content",
            ),
            id="help-modal",
        )

    DEFAULT_CSS = """
    HelpScreen {
        align: center middle;
        background: $surface 60%;
    }
    #help-modal {
        width: 72;
        height: auto;
        max-height: 90%;
        padding: 1 2;
        border: thick $primary;
        background: $surface;
    }
    """


# ─── The cockpit ────────────────────────────────────────────────────────────


class CockpitApp(App):
    """Full-screen operator cockpit for sovereign-agent."""

    TITLE = "sovereign-agent · cockpit"
    SUB_TITLE = "0.2.15.3"

    BINDINGS = [
        Binding("ctrl+q", "quit", "quit"),
        Binding("ctrl+h", "halt", "halt", show=True),
        Binding("ctrl+d", "disarm", "disarm", show=True),
        Binding("ctrl+l", "clear_chat", "clear", show=True),
        Binding("ctrl+b", "toggle_heart", "♥", show=True),
        Binding("f1,question_mark", "help", "help", show=True),
    ]

    CSS = """
    Screen {
        background: $surface;
        scrollbar-size: 0 0;
    }

    /* ── Outer frame: a SINGLE rounded border owns chat + live.        ──
       ── Two adjacent inner borders previously produced a visible seam.── */
    #main {
        height: 1fr;
        border: round $primary;
        padding: 0;
    }

    /* Breathing border — applied when the agent is mid-directive.
       Three phases are cycled by the breathing worker to fake a slow
       inhale/exhale on the frame. Idle state has no class and stays
       on the steady #main rule above. */
    #main.breathing-1 { border: round $primary; }
    #main.breathing-2 { border: round $accent; }
    #main.breathing-3 { border: round $secondary; }

    /* Inner panes carry NO outer borders — the #main frame owns the chrome.
       The live pane carries a single border on its LEFT side, which
       Textual renders as one continuous key line. That replaces the old
       Static-as-divider, which produced visual seams at row boundaries. */
    #chat-pane {
        width: 2fr;
        padding: 0 1;
    }
    #live-pane {
        width: 1fr;
        padding: 0 1;
        border-left: solid $primary;
    }

    /* Pane titles: accent-coloured, small, with a one-row breathing gap */
    .pane-title {
        color: $accent;
        text-style: bold;
        height: 1;
        margin-bottom: 1;
    }

    /* The two scrolling logs */
    #chat-log {
        height: 1fr;
        background: $surface;
        border: none;
    }
    #events-log {
        height: 1fr;
        background: $surface;
        border: none;
    }

    /* ── Scrollbars: invisible at rest, thin/themed when scrolling. ──
       ── Default Textual scrollbar background is near-black, which   ──
       ── previously sat against the rounded border as a phantom edge.── */
    RichLog {
        scrollbar-size-vertical: 1;
        scrollbar-background: $surface;
        scrollbar-background-active: $surface;
        scrollbar-background-hover: $surface;
        scrollbar-color: $primary 30%;
        scrollbar-color-active: $accent;
        scrollbar-color-hover: $primary 60%;
        scrollbar-corner-color: $surface;
    }

    /* Input box: gap above so it doesn't graze the main frame.
       Border accent shifts to bold-bright on focus. */
    #input-box {
        height: 3;
        margin: 1 0 0 0;
        padding: 0 1;
        border: round $accent;
    }
    #input-box:focus {
        border: round $accent;
        background: $surface;
    }

    /* Status row: heartbeat on the left, metrics on the right. Tint
       applied to the row so the heart sits inside the same band. The
       width: 100% + dock: bottom combo guarantees the tint fills the
       full terminal width — fixes the right-edge leak where a Label
       alone would only paint its text cells. */
    #status-row {
        height: 1;
        width: 100%;
        background: $primary 15%;
        layout: horizontal;
    }
    #heart {
        width: 3;
        height: 1;
        content-align: center middle;
        padding: 0;
        background: $primary 15%;
    }
    #status-bar {
        height: 1;
        width: 1fr;
        background: $primary 15%;
        color: $text;
        padding: 0 1;
    }

    .label-warn  { color: $warning; }
    .label-ok    { color: $success; }
    .label-bad   { color: $error;   }
    .you         { color: #FF8C00;  }
    .aria        { color: #1E90FF;  }
    .meta        { color: $text-muted; }
    """

    status: reactive[CockpitStatus] = reactive(CockpitStatus(), recompose=False)

    def __init__(self) -> None:
        super().__init__()
        self._events_log: Optional[RichLog] = None
        self._chat_log: Optional[RichLog] = None
        self._status_label: Optional[Label] = None
        self._mood_label: Optional[Label] = None
        self._heart_label: Optional[Static] = None
        self._heart_visible: bool = True
        self._sysmon = SystemMonitor(data_dir=self._resolve_data_dir())
        self._events_path = self._resolve_events_path()
        self._events_offset = 0
        self._busy = False

    # ── Setup ────────────────────────────────────────────────────────

    @staticmethod
    def _resolve_events_path() -> Path:
        """Find events.jsonl using the same config resolution the agent uses."""
        from sovereign_agent.config import SETTINGS
        return SETTINGS.paths.events_jsonl

    @staticmethod
    def _resolve_data_dir() -> Optional[Path]:
        """Find the agent's data dir so SystemMonitor reports disk usage of
        the right volume (where atoms.db, blobs, and snapshots live).
        Returns None on any error — SystemMonitor falls back to $HOME."""
        try:
            from sovereign_agent.config import SETTINGS
            return SETTINGS.paths.data_dir
        except Exception:  # noqa: BLE001
            return None

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main"):
            with Vertical(id="chat-pane"):
                yield Label("◈ chat", classes="pane-title")
                yield RichLog(
                    id="chat-log",
                    highlight=True, markup=True, wrap=True,
                    auto_scroll=True,
                )
            with Vertical(id="live-pane"):
                yield Label("◈ live", classes="pane-title")
                yield RichLog(
                    id="events-log",
                    highlight=True, markup=True, wrap=False,
                    auto_scroll=True, max_lines=200,
                )
        yield Input(
            placeholder="tell aria what to do · F1 help · /help commands",
            id="input-box",
        )
        with Horizontal(id="status-row"):
            yield Static("♥", id="heart")
            yield Label("", id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        self._chat_log = self.query_one("#chat-log", RichLog)
        self._events_log = self.query_one("#events-log", RichLog)
        self._status_label = self.query_one("#status-bar", Label)
        self._heart_label = self.query_one("#heart", Static)

        # Welcome banner — Aria approaches with love.
        self._chat_log.write(
            "[bold red]♥[/bold red]  [bold bright_blue]aria[/bold bright_blue] "
            "· sovereign-agent v0.2.15.3"
        )
        self._chat_log.write(
            "[dim]welcome back. the kernel is whole.[/dim]"
        )
        self._chat_log.write(
            "[dim]speak in plain english — i'll plan the commands.[/dim]"
        )
        self._chat_log.write(
            "[dim]F1 for help.[/dim]"
        )
        self._chat_log.write("")

        # Seed live pane with current state
        self._events_log.write("[dim]── live events ──[/dim]")

        # Position the events file pointer at end-of-file so we only show
        # NEW events from now on (not the entire historical log).
        if self._events_path.exists():
            self._events_offset = self._events_path.stat().st_size

        # Background workers
        self._refresh_status_worker()
        self._tail_events_worker()
        self._heartbeat_worker()
        self._breathing_worker()

    # ── Heartbeat ────────────────────────────────────────────────────

    @work(exclusive=True, group="heart")
    async def _heartbeat_worker(self) -> None:
        """A pulsing ♥ in the status bar — proof of life for the cockpit.

        Pattern is a real cardiac rhythm: lub (bright) ─ dub (bright) ─
        rest (dim). Roughly 60 bpm so it's calming, not anxious. If the
        agent has tripped PROTOCOL-ZERO, the heart turns red-on-red so
        the bar reads "alarm" at a glance.
        """
        # Frame: (rendered_text, hold_ms)
        # The heart is rendered as a 3-cell badge: [space][♥][space], all
        # three cells carrying the same `on rgb(...)` background so the
        # halo appears as a clean rectangle that pulses, not as a heart
        # with stub-edges. Cycle ≈ 1 second — about 60 bpm.
        #
        # If the operator hides the heart (Ctrl-B or /heart), the widget
        # is updated to a blank cell and the worker idles.
        normal_cycle = [
            # lub  — bright halo
            ("[bold red on rgb(120,0,15)] ♥ [/]", 140),
            # gap  — halo dimming
            ("[red on rgb(70,0,8)] ♥ [/]", 90),
            # dub  — bright halo
            ("[bold red on rgb(120,0,15)] ♥ [/]", 140),
            # rest — faint halo, outline heart
            ("[red on rgb(30,0,4)] ♡ [/]", 630),
        ]
        halted_cycle = [
            ("[bold red on rgb(160,0,20)] ◈ [/]", 500),
            ("[red on rgb(60,0,8)] ◈ [/]", 500),
        ]
        while True:
            if not self._heart_visible:
                # Operator hid the heart — clear the cell and back off.
                if self._heart_label is not None:
                    self._heart_label.update("   ")
                await asyncio.sleep(0.5)
                continue
            cycle = halted_cycle if self.status.halt else normal_cycle
            for rendered, ms in cycle:
                if self._heart_label is not None:
                    self._heart_label.update(rendered)
                await asyncio.sleep(ms / 1000.0)

    @work(exclusive=True, group="breathe")
    async def _breathing_worker(self) -> None:
        """Outer border colour-cycles when the agent is mid-directive.

        Idle:    steady $primary frame.
        Working: cycles primary → accent → secondary → primary, ~700ms
                 per phase. Communicates "i am thinking" with no extra
                 text noise, and keeps the visual quiet during downtime.
        """
        phases = ["breathing-1", "breathing-2", "breathing-3"]
        idx = 0
        last_busy = False
        while True:
            try:
                main = self.query_one("#main")
            except Exception:  # noqa: BLE001
                # Layout not yet ready; try again next tick.
                await asyncio.sleep(0.7)
                continue
            if self._busy:
                # Advance the phase
                main.add_class(phases[idx])
                for p in phases:
                    if p != phases[idx]:
                        main.remove_class(p)
                idx = (idx + 1) % len(phases)
                last_busy = True
            else:
                # Return to the steady idle state
                if last_busy:
                    for p in phases:
                        main.remove_class(p)
                    last_busy = False
            await asyncio.sleep(0.7)

    # ── Status bar ───────────────────────────────────────────────────

    @work(exclusive=True, group="status")
    async def _refresh_status_worker(self) -> None:
        """Periodically refresh the status bar."""
        while True:
            try:
                self.status = await asyncio.to_thread(self._read_status)
                self._render_status_bar()
            except Exception as exc:  # noqa: BLE001
                # Don't let a transient read failure kill the worker.
                if self._status_label is not None:
                    self._status_label.update(
                        f"[red]status read error: {exc!r}[/red]"
                    )
            await asyncio.sleep(5)

    def _read_status(self) -> CockpitStatus:
        """Synchronous status read — runs off the event loop."""
        from sovereign_agent.config import SETTINGS
        from sovereign_agent.db import open_atoms_db
        from sovereign_agent.mem_channels.financial import FinancialChannel
        from sovereign_agent import backup as backup_mod

        s = CockpitStatus()

        # HALT
        halt_file = SETTINGS.paths.config_dir / "HALT"
        s.halt = halt_file.exists()

        # Daemon
        try:
            r = subprocess.run(
                ["systemctl", "--user", "is-active", "sovereign-agent.service"],
                capture_output=True, text=True, timeout=2,
            )
            s.daemon_active = (r.stdout.strip() == "active")
        except (subprocess.SubprocessError, FileNotFoundError):
            s.daemon_active = False

        # Ledger
        try:
            conn = open_atoms_db()
            try:
                fc = FinancialChannel(conn)
                result = fc.audit()
                s.ledger_clean = result.ok
                s.ledger_rows = result.ledger_rows
            finally:
                conn.close()
        except Exception:  # noqa: BLE001
            s.ledger_clean = False

        # Backup
        try:
            bs = backup_mod.status()
            s.snapshot_age_seconds = bs.most_recent_age_seconds
            s.snapshot_verify_ok = bool(bs.last_verify_ok) if bs.last_verify_ok is not None else True
        except Exception:  # noqa: BLE001
            pass

        # System (CPU/RAM/disk/load/uptime — never raises)
        s.system = self._sysmon.read()

        # VRAM — best effort. Skip silently if no GPU stack is available.
        try:
            from sovereign_agent.vram import read_vram
            v = read_vram()
            s.vram_total_mb = v.total_mb
            s.vram_used_mb = v.used_mb
            s.vram_source = v.source
        except Exception:  # noqa: BLE001
            pass

        # GPU temperature — independent call (vram.py untouched)
        try:
            from .sysmon import read_gpu_temp
            s.vram_temp_c = read_gpu_temp()
        except Exception:  # noqa: BLE001
            pass

        # Append a telemetry sample. write_sample never raises.
        try:
            from .telemetry import write_sample
            write_sample(
                s.system,
                vram_total_mb=s.vram_total_mb,
                vram_used_mb=s.vram_used_mb,
                vram_temp_c=s.vram_temp_c,
            )
        except Exception:  # noqa: BLE001
            pass

        return s

    def _render_status_bar(self) -> None:
        if self._status_label is None:
            return
        s = self.status

        halt = "[red b]◈HALT[/red b]" if s.halt else "[green]clear[/green]"
        daemon = "[green]●[/green]" if s.daemon_active else "[dim]○[/dim]"
        ledger = (
            f"[green]✓[/green] {s.ledger_rows}r"
            if s.ledger_clean
            else "[red]✗[/red]"
        )
        if s.snapshot_age_seconds is None:
            backup = "[yellow]no snap[/yellow]"
        else:
            mark = "[green]✓[/green]" if s.snapshot_verify_ok else "[red]✗[/red]"
            backup = f"{mark} {_format_age(s.snapshot_age_seconds)}"

        # System metrics: compact, colour-coded (replaces the old key-hint
        # suffix — the Footer already shows the keybindings). RAM and VRAM
        # are now labelled distinctly — they are different hardware. Temps
        # are appended where they're meaningful and available.
        if s.system is not None:
            vram_pct: Optional[float] = None
            if s.vram_total_mb and s.vram_used_mb is not None and s.vram_total_mb > 0:
                vram_pct = 100.0 * s.vram_used_mb / s.vram_total_mb
            metrics = render_compact_metrics(
                s.system, vram_percent=vram_pct, vram_temp_c=s.vram_temp_c,
            )
        else:
            metrics = "[dim]metrics ...[/dim]"

        self._status_label.update(
            f"halt: {halt}  │  daemon: {daemon}  │  "
            f"ledger: {ledger}  │  backup: {backup}  │  "
            f"{metrics}"
        )

    # ── Event tail ───────────────────────────────────────────────────

    @work(exclusive=True, group="events")
    async def _tail_events_worker(self) -> None:
        """Tail events.jsonl and forward to the live pane."""
        while True:
            try:
                if self._events_path.exists():
                    current_size = self._events_path.stat().st_size
                    if current_size < self._events_offset:
                        # File rotated; reset.
                        self._events_offset = 0
                    if current_size > self._events_offset:
                        new_lines = await asyncio.to_thread(
                            self._read_new_lines,
                        )
                        for line in new_lines:
                            self._render_event(line)
            except Exception as exc:  # noqa: BLE001
                if self._events_log is not None:
                    self._events_log.write(
                        f"[red]tail error: {exc!r}[/red]"
                    )
            await asyncio.sleep(1)

    def _read_new_lines(self) -> list[str]:
        """Synchronous read of new event lines from current offset."""
        out: list[str] = []
        with self._events_path.open("r") as f:
            f.seek(self._events_offset)
            for line in f:
                out.append(line.rstrip("\n"))
            self._events_offset = f.tell()
        return out

    def _render_event(self, raw: str) -> None:
        if self._events_log is None:
            return
        try:
            ev = json.loads(raw)
        except json.JSONDecodeError:
            self._events_log.write(raw[:80])
            return

        ts = ev.get("ts", "")[11:19]  # HH:MM:SS slice
        flag = ev.get("flag", "?")
        # Color by event kind
        if "end" in flag:
            color = "green"
        elif "start" in flag:
            color = "cyan"
        elif "halt" in flag or "fail" in flag or "error" in flag:
            color = "red"
        elif "approval" in flag:
            color = "yellow"
        else:
            color = "white"
        self._events_log.write(f"[dim]{ts}[/dim] [{color}]{flag}[/{color}]")

    # ── Input handling ───────────────────────────────────────────────

    @on(Input.Submitted, "#input-box")
    def on_input_submitted(self, event: Input.Submitted) -> None:
        text = event.value.strip()
        event.input.value = ""
        if not text:
            return
        if text.startswith("/"):
            self._handle_slash(text)
        else:
            self._dispatch_directive(text)

    def _handle_slash(self, text: str) -> None:
        cmd = text.lstrip("/").split(maxsplit=1)
        verb = cmd[0].lower()
        arg = cmd[1] if len(cmd) > 1 else ""

        if verb in ("quit", "q", "exit"):
            self.exit()
        elif verb in ("help", "h", "?"):
            self.action_help()
        elif verb == "clear":
            self.action_clear_chat()
        elif verb == "halt":
            self.action_halt()
        elif verb == "disarm":
            self.action_disarm()
        elif verb == "snap":
            label = arg or ""
            self._run_cli_async(
                ["sovereign", "backup", "snapshot"] +
                (["--label", label] if label else []),
                label="snap",
            )
        elif verb == "audit":
            self._run_cli_async(["sovereign", "financial", "audit"], label="audit")
        elif verb == "events":
            n = arg or "20"
            self._run_cli_async(["sovereign", "events", "-n", n], label="events")
        elif verb == "lessons":
            self._run_cli_async(
                ["sovereign", "channels", "show", "lessons"], label="lessons",
            )
        elif verb == "health":
            self._show_health()
        elif verb == "report":
            self._save_report()
        elif verb == "drafts":
            # /drafts → list. /drafts N → list newest N.
            n = 20
            if rest.strip().isdigit():
                n = int(rest.strip())
            self._run_cli_async(
                ["sovereign", "drafts", "list", "--limit", str(n)],
                label="drafts",
            )
        elif verb == "draft":
            # /draft <title> <source-path>   archive a project as a draft
            parts = rest.strip().split(maxsplit=1)
            if len(parts) < 2:
                self._write_meta(
                    "[yellow]usage: /draft <title> <source-path>[/yellow]"
                )
            else:
                title, src = parts
                self._run_cli_async(
                    ["sovereign", "drafts", "archive", title, src],
                    label="draft",
                )
        elif verb == "marketing":
            # /marketing <product>   generate a marketing brief via the planner
            product = rest.strip()
            if not product:
                self._write_meta(
                    "[yellow]usage: /marketing <product or release name>[/yellow]"
                )
            else:
                self._dispatch_directive(
                    f"generate marketing brief for {product}"
                )
        elif verb == "heart":
            self.action_toggle_heart()
        else:
            self._write_meta(f"unknown command: /{verb}")

    def _dispatch_directive(self, text: str) -> None:
        """Route plain English to 'sovereign do'."""
        if self._busy:
            self._write_meta("aria is still working on the previous turn; "
                             "wait a moment.")
            return
        self._write_you(text)
        self._busy = True
        self._run_directive_worker(text)

    @work(exclusive=False, group="directive")
    async def _run_directive_worker(self, text: str) -> None:
        # ── Pre: snapshot VRAM so we can report the delta on completion
        vram_before_mb: Optional[int] = None
        try:
            from sovereign_agent.vram import read_vram
            vram_before_mb = read_vram().used_mb
        except Exception:  # noqa: BLE001
            pass
        t0 = time.time()
        try:
            self._write_aria_thinking()
            proc = await asyncio.create_subprocess_exec(
                "sovereign", "do", text,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            assert proc.stdout is not None
            async for line_bytes in proc.stdout:
                line = line_bytes.decode("utf-8", errors="replace").rstrip("\n")
                if line:
                    self._write_aria(line)
            await proc.wait()
            # ── Post: VRAM delta + duration, written as a meta line and
            #         appended to the events log so it's traceable
            vram_after_mb: Optional[int] = None
            try:
                from sovereign_agent.vram import read_vram
                vram_after_mb = read_vram().used_mb
            except Exception:  # noqa: BLE001
                pass
            dur_s = time.time() - t0

            footer = f"[dim]turn complete · exit {proc.returncode} · {dur_s:.1f}s"
            if vram_before_mb is not None and vram_after_mb is not None:
                delta = vram_after_mb - vram_before_mb
                sign = "+" if delta >= 0 else ""
                footer += (
                    f" · vram {vram_before_mb}→{vram_after_mb} MB "
                    f"({sign}{delta} MB)"
                )
            footer += "[/dim]"
            self._write_meta(footer)

            # Append a structured event line so the operator can grep for
            # turn timings + vram footprints in the live pane too.
            if self._events_log is not None:
                tag = "task-end" if proc.returncode == 0 else "task-fail"
                colour = "green" if proc.returncode == 0 else "red"
                vram_str = ""
                if vram_before_mb is not None and vram_after_mb is not None:
                    vram_str = f" Δvram={vram_after_mb - vram_before_mb:+d}MB"
                self._events_log.write(
                    f"[dim]{_now_short()}[/dim] [{colour}]{tag}[/{colour}] "
                    f"dur={dur_s:.1f}s{vram_str}"
                )

            # Persistent telemetry — write a task-end record to the daily
            # JSONL file. Includes deltas so the operator can later run
            # `sov telemetry summary` and see which directives are heavy.
            try:
                from .telemetry import write_sample
                s_now = self._sysmon.read()
                extra = {
                    "task_directive": text[:200],
                    "task_phase": "end",
                    "task_status": "ok" if proc.returncode == 0 else "fail",
                    "task_duration_s": round(dur_s, 2),
                    "task_exit_code": proc.returncode,
                }
                if vram_before_mb is not None and vram_after_mb is not None:
                    extra["task_vram_before_mb"] = vram_before_mb
                    extra["task_vram_after_mb"] = vram_after_mb
                    extra["task_vram_delta_mb"] = vram_after_mb - vram_before_mb
                write_sample(
                    s_now,
                    vram_total_mb=self.status.vram_total_mb,
                    vram_used_mb=vram_after_mb,
                    vram_temp_c=self.status.vram_temp_c,
                    extra=extra,
                )
            except Exception:  # noqa: BLE001
                pass
        except FileNotFoundError:
            self._write_meta("[red]sovereign binary not found on PATH[/red]")
        except Exception as exc:  # noqa: BLE001
            self._write_meta(f"[red]error: {exc!r}[/red]")
        finally:
            self._busy = False

    @work(exclusive=False, group="cli")
    async def _run_cli_async(self, argv: list[str], *, label: str) -> None:
        try:
            proc = await asyncio.create_subprocess_exec(
                *argv,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            assert proc.stdout is not None
            self._write_meta(f"[dim]── {label} ──[/dim]")
            async for line_bytes in proc.stdout:
                line = line_bytes.decode("utf-8", errors="replace").rstrip("\n")
                if line:
                    self._write_aria(line)
            await proc.wait()
        except Exception as exc:  # noqa: BLE001
            self._write_meta(f"[red]{label} failed: {exc!r}[/red]")

    # ── Actions ──────────────────────────────────────────────────────

    def action_help(self) -> None:
        self.push_screen(HelpScreen())

    def action_clear_chat(self) -> None:
        if self._chat_log is not None:
            self._chat_log.clear()
            self._write_meta("[dim]── chat cleared ──[/dim]")

    def action_halt(self) -> None:
        self._write_meta("[red]◈ tripping PROTOCOL-ZERO ...[/red]")
        self._run_cli_async(
            ["sovereign", "halt", "--reason", "cockpit Ctrl-H"],
            label="halt",
        )

    def action_disarm(self) -> None:
        self._write_meta("[green]◈ disarming PROTOCOL-ZERO ...[/green]")
        self._run_cli_async(["sovereign", "disarm"], label="disarm")

    def action_toggle_heart(self) -> None:
        """Toggle the heartbeat badge. Ctrl-B or /heart."""
        self._heart_visible = not self._heart_visible
        state = "shown" if self._heart_visible else "hidden"
        self._write_meta(f"[dim]♥ heart {state}[/dim]")

    # ── Health & reporting ───────────────────────────────────────────

    def _show_health(self) -> None:
        """Inline health summary — fast, no disk writes."""
        s = self.status
        if s.system is None:
            self._write_meta("[yellow]system metrics not ready yet — try again in a few seconds[/yellow]")
            return
        sys_ = s.system
        self._write_meta("[dim]── health ──[/dim]")
        self._write_meta(
            f"  daemon: {'[green]● active[/green]' if s.daemon_active else '[red]○ inactive[/red]'}  ·  "
            f"halt: {'[red]◈ TRIPPED[/red]' if s.halt else '[green]clear[/green]'}"
        )
        self._write_meta(
            f"  cpu: [cyan]{sys_.cpu_percent:.1f}%[/cyan]  "
            f"load: [cyan]{sys_.load_1m:.2f} {sys_.load_5m:.2f} {sys_.load_15m:.2f}[/cyan]  "
            f"({sys_.cpu_count} cores)"
        )
        from .sysmon import fmt_bytes, fmt_duration
        self._write_meta(
            f"  mem: [cyan]{sys_.mem_percent:.1f}%[/cyan]  "
            f"{fmt_bytes(sys_.mem_used)} of {fmt_bytes(sys_.mem_total)}"
        )
        self._write_meta(
            f"  disk: [cyan]{sys_.disk_percent:.1f}%[/cyan]  "
            f"{fmt_bytes(sys_.disk_free)} free of {fmt_bytes(sys_.disk_total)}"
        )
        if s.vram_total_mb and s.vram_used_mb is not None:
            vram_pct = 100.0 * s.vram_used_mb / s.vram_total_mb
            self._write_meta(
                f"  vram: [cyan]{vram_pct:.1f}%[/cyan]  "
                f"{s.vram_used_mb} / {s.vram_total_mb} MB  [dim]({s.vram_source})[/dim]"
            )
        self._write_meta(f"  uptime: [cyan]{fmt_duration(sys_.uptime_seconds)}[/cyan]")

    def _save_report(self) -> None:
        """Full health report — printed in chat and saved to disk for sharing."""
        s = self.status
        if s.system is None:
            self._write_meta("[yellow]system metrics not ready yet — try again in a few seconds[/yellow]")
            return

        now = datetime.now(timezone.utc)
        now_iso = now.strftime("%Y-%m-%d %H:%M UTC")

        report = render_health_report(
            s.system,
            version=s.version,
            halt=s.halt,
            daemon_active=s.daemon_active,
            ledger_ok=s.ledger_clean,
            ledger_rows=s.ledger_rows,
            snapshot_age_seconds=s.snapshot_age_seconds,
            snapshot_verify_ok=s.snapshot_verify_ok,
            vram_total_mb=s.vram_total_mb,
            vram_used_mb=s.vram_used_mb,
            vram_source=s.vram_source,
            now_iso=now_iso,
        )

        # Render to chat as a fenced code block (preserves spacing).
        self._write_meta("[dim]── health report ──[/dim]")
        if self._chat_log is not None:
            for line in report.splitlines():
                # Escape any stray rich tags in user-facing strings.
                self._chat_log.write(line.replace("[", "\\["))

        # Save to a timestamped file under data_dir/reports/
        try:
            data_dir = self._resolve_data_dir()
            if data_dir is None:
                self._write_meta("[dim]report not saved: data dir unavailable[/dim]")
                return
            reports_dir = data_dir / "reports"
            reports_dir.mkdir(parents=True, exist_ok=True)
            fname = f"health-{now.strftime('%Y%m%d-%H%M%S')}.txt"
            path = reports_dir / fname
            path.write_text(report + "\n", encoding="utf-8")
            self._write_meta(f"[green]✓[/green] saved → [cyan]{path}[/cyan]")
        except Exception as exc:  # noqa: BLE001
            self._write_meta(f"[red]✗ save failed: {exc!r}[/red]")

    # ── Chat rendering helpers ───────────────────────────────────────

    def _write_you(self, text: str) -> None:
        if self._chat_log is None:
            return
        # `\[you]` escapes the brackets so Rich treats it as literal text,
        # not a markup tag. Colour is dark_orange — warm, distinct from
        # any status colour, and pretty against the surface tone.
        self._chat_log.write(
            f"[bold dark_orange]\\[you][/bold dark_orange] {text}"
        )

    def _write_aria_thinking(self) -> None:
        if self._chat_log is None:
            return
        # Aria's name is bright_blue — a clean, steady, trustworthy hue.
        self._chat_log.write(
            "[bold bright_blue]\\[aria][/bold bright_blue] "
            "[dim]thinking ...[/dim]"
        )

    def _write_aria(self, text: str) -> None:
        if self._chat_log is None:
            return
        self._chat_log.write(f"  {text}")

    def _write_meta(self, text: str) -> None:
        if self._chat_log is None:
            return
        self._chat_log.write(text)


# ─── Entry point ────────────────────────────────────────────────────────────


def run() -> None:
    """Launch the cockpit. Called from cli.cockpit."""
    app = CockpitApp()
    app.run()


if __name__ == "__main__":
    run()
