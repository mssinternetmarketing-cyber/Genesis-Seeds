"""
╔══════════════════════════════════════════════════════════════════════════╗
║  cockpit/app.py — sovereign-agent operator cockpit                       ║
║  v0.2.14.4 · Aria-Sovereign-V1                                            ║
║                                                                            ║
║  A full-screen TUI for talking to the agent. Built on Textual.            ║
║                                                                            ║
║  Layout:                                                                   ║
║                                                                            ║
║    ┌─ sovereign-agent · cockpit ───── 0.2.14.4 · ◈ calm ─┐                ║
║    │┌─ chat ────────────────────┐┌─ live ──────────────┐│                ║
║    ││ history scrolls here       ││ events stream        ││                ║
║    ││                            ││ snapshot age         ││                ║
║    ││                            ││ continuations active ││                ║
║    │└────────────────────────────┘└──────────────────────┘│                ║
║    │┌─ input ──────────────────────────────────────────────┐│                ║
║    ││ > _                                                  ││                ║
║    │└──────────────────────────────────────────────────────┘│                ║
║    │ HALT · daemon · ledger · backup                       │                ║
║    └────────────────────────────────────────────────────────┘                ║
║                                                                            ║
║  Bindings:                                                                 ║
║    Enter      submit input                                                 ║
║    Ctrl-Q    quit cockpit (agent keeps running)                            ║
║    Ctrl-H    halt the agent (PROTOCOL-ZERO)                                ║
║    Ctrl-D    disarm PROTOCOL-ZERO                                          ║
║    Ctrl-L    clear chat pane                                               ║
║    F1        help overlay                                                  ║
║                                                                            ║
║  Execution model:                                                          ║
║    User input → spawn ``sovereign do "..."`` in a subprocess.             ║
║    Stream its stdout to the chat pane.                                    ║
║    In parallel, tail events.jsonl and forward new events to live pane.    ║
║    Status bar refreshes every 5 seconds (ledger audit, snapshot age).     ║
║                                                                            ║
║  What this doesn't do (deferred to later releases):                       ║
║    - Inline Tier 3 approval modal (use 'sov approvals' in another shell)  ║
║    - Multi-conversation tabs                                              ║
║    - Search over chat history (chat is in atoms.db; search via channels)  ║
║    - Dream-tail integration (use 'sov dream tail' in another shell)       ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import asyncio
import json
import os
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.widgets import (
    Footer, Header, Input, Label, RichLog, Static,
)


# ─── Helpers ────────────────────────────────────────────────────────────────


def _now_short() -> str:
    return datetime.now().strftime("%H:%M:%S")


def _format_age(seconds: Optional[float]) -> str:
    if seconds is None:
        return "—"
    if seconds < 60:
        return f"{seconds:.0f}s"
    if seconds < 3600:
        return f"{seconds/60:.0f}m"
    if seconds < 86400:
        return f"{seconds/3600:.1f}h"
    return f"{seconds/86400:.1f}d"


@dataclass
class CockpitStatus:
    """Single snapshot of system state for the status bar."""
    halt: bool = False
    daemon_active: bool = False
    ledger_clean: bool = True
    ledger_rows: int = 0
    snapshot_age_seconds: Optional[float] = None
    snapshot_verify_ok: bool = True
    version: str = "0.2.14.4"
    mood: str = "calm"


# ─── Help overlay ───────────────────────────────────────────────────────────


class HelpScreen(ModalScreen):
    """F1 → modal with keybindings and routing reference."""

    BINDINGS = [Binding("escape,f1,q", "app.pop_screen", "close")]

    def compose(self) -> ComposeResult:
        yield Vertical(
            Static(
                "[b]sovereign-agent cockpit · help[/b]\n\n"
                "[b]Keys[/b]\n"
                "  Enter           submit input\n"
                "  Ctrl-Q          quit cockpit (agent keeps running)\n"
                "  Ctrl-H          [red]halt[/red] (PROTOCOL-ZERO)\n"
                "  Ctrl-D          [green]disarm[/green] PROTOCOL-ZERO\n"
                "  Ctrl-L          clear chat pane\n"
                "  F1, ?           this help\n"
                "  Esc             close overlay\n\n"
                "[b]Slash commands[/b]\n"
                "  /halt           PROTOCOL-ZERO from input line\n"
                "  /disarm         clear PROTOCOL-ZERO\n"
                "  /snap [label]   take a snapshot\n"
                "  /audit          run financial audit\n"
                "  /events [N]     dump latest N events to chat\n"
                "  /lessons        recent lesson atoms\n"
                "  /clear          clear chat\n"
                "  /quit           quit\n\n"
                "[b]Otherwise[/b]\n"
                "  Anything else is routed to [cyan]sov do[/cyan] as a "
                "plain-English directive. Steps stream into the chat pane "
                "as they happen; live events appear on the right.\n\n"
                "[dim]Esc to close[/dim]",
                id="help-content",
            ),
            id="help-modal",
        )

    DEFAULT_CSS = """
    HelpScreen {
        align: center middle;
        background: $surface 60%;
    }
    #help-modal {
        width: 70;
        height: auto;
        padding: 1 2;
        border: thick $primary;
        background: $surface;
    }
    """


# ─── The cockpit ────────────────────────────────────────────────────────────


class CockpitApp(App):
    """Full-screen operator cockpit for sovereign-agent."""

    TITLE = "sovereign-agent · cockpit"
    SUB_TITLE = "0.2.14.4"

    BINDINGS = [
        Binding("ctrl+q", "quit", "quit"),
        Binding("ctrl+h", "halt", "halt", show=True),
        Binding("ctrl+d", "disarm", "disarm", show=True),
        Binding("ctrl+l", "clear_chat", "clear", show=True),
        Binding("f1,question_mark", "help", "help", show=True),
    ]

    CSS = """
    Screen {
        background: $surface;
    }
    #main {
        height: 1fr;
    }
    #chat-pane {
        width: 2fr;
        border: round $primary;
        padding: 0 1;
    }
    #live-pane {
        width: 1fr;
        border: round $secondary;
        padding: 0 1;
    }
    #chat-log {
        height: 1fr;
    }
    #events-log, #status-block {
        height: 1fr;
    }
    #input-box {
        height: 3;
        padding: 0 1;
        border: round $accent;
    }
    #status-bar {
        height: 1;
        background: $primary 20%;
        color: $text;
        padding: 0 1;
    }
    .label-warn  { color: $warning; }
    .label-ok    { color: $success; }
    .label-bad   { color: $error;   }
    .you         { color: $accent;  }
    .aria        { color: $primary; }
    .meta        { color: $text-muted; }
    """

    status: reactive[CockpitStatus] = reactive(CockpitStatus(), recompose=False)

    def __init__(self) -> None:
        super().__init__()
        self._events_log: Optional[RichLog] = None
        self._chat_log: Optional[RichLog] = None
        self._status_label: Optional[Label] = None
        self._mood_label: Optional[Label] = None
        self._events_path = self._resolve_events_path()
        self._events_offset = 0
        self._busy = False

    # ── Setup ────────────────────────────────────────────────────────

    @staticmethod
    def _resolve_events_path() -> Path:
        """Find events.jsonl using the same config resolution the agent uses."""
        from sovereign_agent.config import SETTINGS
        return SETTINGS.paths.events_jsonl

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main"):
            with Vertical(id="chat-pane"):
                yield Label("[b]◈ chat[/b]", classes="meta")
                yield RichLog(
                    id="chat-log",
                    highlight=True, markup=True, wrap=True,
                    auto_scroll=True,
                )
            with Vertical(id="live-pane"):
                yield Label("[b]◈ live[/b]", classes="meta")
                yield RichLog(
                    id="events-log",
                    highlight=True, markup=True, wrap=False,
                    auto_scroll=True, max_lines=200,
                )
        yield Input(
            placeholder="speak to aria · F1 for help · /help for commands",
            id="input-box",
        )
        yield Label("", id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        self._chat_log = self.query_one("#chat-log", RichLog)
        self._events_log = self.query_one("#events-log", RichLog)
        self._status_label = self.query_one("#status-bar", Label)

        # Welcome banner
        self._chat_log.write(
            "[b cyan]◈[/b cyan]  [b]aria[/b] · sovereign-agent v0.2.14.4"
        )
        self._chat_log.write(
            "[dim]welcome back. the kernel is whole. type anything; "
            "F1 for help.[/dim]"
        )
        self._chat_log.write("")

        # Seed live pane with current state
        self._events_log.write("[dim]── live events ──[/dim]")

        # Position the events file pointer at end-of-file so we only show
        # NEW events from now on (not the entire historical log).
        if self._events_path.exists():
            self._events_offset = self._events_path.stat().st_size

        # Background workers
        self._refresh_status_worker()
        self._tail_events_worker()

    # ── Status bar ───────────────────────────────────────────────────

    @work(exclusive=True, group="status")
    async def _refresh_status_worker(self) -> None:
        """Periodically refresh the status bar."""
        while True:
            try:
                self.status = await asyncio.to_thread(self._read_status)
                self._render_status_bar()
            except Exception as exc:  # noqa: BLE001
                # Don't let a transient read failure kill the worker.
                if self._status_label is not None:
                    self._status_label.update(
                        f"[red]status read error: {exc!r}[/red]"
                    )
            await asyncio.sleep(5)

    def _read_status(self) -> CockpitStatus:
        """Synchronous status read — runs off the event loop."""
        from sovereign_agent.config import SETTINGS
        from sovereign_agent.db import open_atoms_db
        from sovereign_agent.mem_channels.financial import FinancialChannel
        from sovereign_agent import backup as backup_mod

        s = CockpitStatus()

        # HALT
        halt_file = SETTINGS.paths.config_dir / "HALT"
        s.halt = halt_file.exists()

        # Daemon
        try:
            r = subprocess.run(
                ["systemctl", "--user", "is-active", "sovereign-agent.service"],
                capture_output=True, text=True, timeout=2,
            )
            s.daemon_active = (r.stdout.strip() == "active")
        except (subprocess.SubprocessError, FileNotFoundError):
            s.daemon_active = False

        # Ledger
        try:
            conn = open_atoms_db()
            try:
                fc = FinancialChannel(conn)
                result = fc.audit()
                s.ledger_clean = result.ok
                s.ledger_rows = result.ledger_rows
            finally:
                conn.close()
        except Exception:  # noqa: BLE001
            s.ledger_clean = False

        # Backup
        try:
            bs = backup_mod.status()
            s.snapshot_age_seconds = bs.most_recent_age_seconds
            s.snapshot_verify_ok = bool(bs.last_verify_ok) if bs.last_verify_ok is not None else True
        except Exception:  # noqa: BLE001
            pass

        return s

    def _render_status_bar(self) -> None:
        if self._status_label is None:
            return
        s = self.status

        halt = "[red b]◈HALT[/red b]" if s.halt else "[green]clear[/green]"
        daemon = "[green]●[/green]" if s.daemon_active else "[dim]○[/dim]"
        ledger = (
            f"[green]✓[/green] {s.ledger_rows}r"
            if s.ledger_clean
            else "[red]✗[/red]"
        )
        if s.snapshot_age_seconds is None:
            backup = "[yellow]no snap[/yellow]"
        else:
            mark = "[green]✓[/green]" if s.snapshot_verify_ok else "[red]✗[/red]"
            backup = f"{mark} {_format_age(s.snapshot_age_seconds)}"

        self._status_label.update(
            f"halt: {halt}  │  daemon: {daemon}  │  "
            f"ledger: {ledger}  │  backup: {backup}  │  "
            f"[dim]F1 help · Ctrl-Q quit · Ctrl-H halt[/dim]"
        )

    # ── Event tail ───────────────────────────────────────────────────

    @work(exclusive=True, group="events")
    async def _tail_events_worker(self) -> None:
        """Tail events.jsonl and forward to the live pane."""
        while True:
            try:
                if self._events_path.exists():
                    current_size = self._events_path.stat().st_size
                    if current_size < self._events_offset:
                        # File rotated; reset.
                        self._events_offset = 0
                    if current_size > self._events_offset:
                        new_lines = await asyncio.to_thread(
                            self._read_new_lines,
                        )
                        for line in new_lines:
                            self._render_event(line)
            except Exception as exc:  # noqa: BLE001
                if self._events_log is not None:
                    self._events_log.write(
                        f"[red]tail error: {exc!r}[/red]"
                    )
            await asyncio.sleep(1)

    def _read_new_lines(self) -> list[str]:
        """Synchronous read of new event lines from current offset."""
        out: list[str] = []
        with self._events_path.open("r") as f:
            f.seek(self._events_offset)
            for line in f:
                out.append(line.rstrip("\n"))
            self._events_offset = f.tell()
        return out

    def _render_event(self, raw: str) -> None:
        if self._events_log is None:
            return
        try:
            ev = json.loads(raw)
        except json.JSONDecodeError:
            self._events_log.write(raw[:80])
            return

        ts = ev.get("ts", "")[11:19]  # HH:MM:SS slice
        flag = ev.get("flag", "?")
        # Color by event kind
        if "end" in flag:
            color = "green"
        elif "start" in flag:
            color = "cyan"
        elif "halt" in flag or "fail" in flag or "error" in flag:
            color = "red"
        elif "approval" in flag:
            color = "yellow"
        else:
            color = "white"
        self._events_log.write(f"[dim]{ts}[/dim] [{color}]{flag}[/{color}]")

    # ── Input handling ───────────────────────────────────────────────

    @on(Input.Submitted, "#input-box")
    def on_input_submitted(self, event: Input.Submitted) -> None:
        text = event.value.strip()
        event.input.value = ""
        if not text:
            return
        if text.startswith("/"):
            self._handle_slash(text)
        else:
            self._dispatch_directive(text)

    def _handle_slash(self, text: str) -> None:
        cmd = text.lstrip("/").split(maxsplit=1)
        verb = cmd[0].lower()
        arg = cmd[1] if len(cmd) > 1 else ""

        if verb in ("quit", "q", "exit"):
            self.exit()
        elif verb in ("help", "h", "?"):
            self.action_help()
        elif verb == "clear":
            self.action_clear_chat()
        elif verb == "halt":
            self.action_halt()
        elif verb == "disarm":
            self.action_disarm()
        elif verb == "snap":
            label = arg or ""
            self._run_cli_async(
                ["sovereign", "backup", "snapshot"] +
                (["--label", label] if label else []),
                label="snap",
            )
        elif verb == "audit":
            self._run_cli_async(["sovereign", "financial", "audit"], label="audit")
        elif verb == "events":
            n = arg or "20"
            self._run_cli_async(["sovereign", "events", "-n", n], label="events")
        elif verb == "lessons":
            self._run_cli_async(
                ["sovereign", "channels", "show", "lessons"], label="lessons",
            )
        else:
            self._write_meta(f"unknown command: /{verb}")

    def _dispatch_directive(self, text: str) -> None:
        """Route plain English to 'sovereign do'."""
        if self._busy:
            self._write_meta("aria is still working on the previous turn; "
                             "wait a moment.")
            return
        self._write_you(text)
        self._busy = True
        self._run_directive_worker(text)

    @work(exclusive=False, group="directive")
    async def _run_directive_worker(self, text: str) -> None:
        try:
            self._write_aria_thinking()
            proc = await asyncio.create_subprocess_exec(
                "sovereign", "do", text,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            assert proc.stdout is not None
            async for line_bytes in proc.stdout:
                line = line_bytes.decode("utf-8", errors="replace").rstrip("\n")
                if line:
                    self._write_aria(line)
            await proc.wait()
            self._write_meta(
                f"[dim]turn complete · exit {proc.returncode}[/dim]"
            )
        except FileNotFoundError:
            self._write_meta("[red]sovereign binary not found on PATH[/red]")
        except Exception as exc:  # noqa: BLE001
            self._write_meta(f"[red]error: {exc!r}[/red]")
        finally:
            self._busy = False

    @work(exclusive=False, group="cli")
    async def _run_cli_async(self, argv: list[str], *, label: str) -> None:
        try:
            proc = await asyncio.create_subprocess_exec(
                *argv,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            assert proc.stdout is not None
            self._write_meta(f"[dim]── {label} ──[/dim]")
            async for line_bytes in proc.stdout:
                line = line_bytes.decode("utf-8", errors="replace").rstrip("\n")
                if line:
                    self._write_aria(line)
            await proc.wait()
        except Exception as exc:  # noqa: BLE001
            self._write_meta(f"[red]{label} failed: {exc!r}[/red]")

    # ── Actions ──────────────────────────────────────────────────────

    def action_help(self) -> None:
        self.push_screen(HelpScreen())

    def action_clear_chat(self) -> None:
        if self._chat_log is not None:
            self._chat_log.clear()
            self._write_meta("[dim]── chat cleared ──[/dim]")

    def action_halt(self) -> None:
        self._write_meta("[red]◈ tripping PROTOCOL-ZERO ...[/red]")
        self._run_cli_async(
            ["sovereign", "halt", "--reason", "cockpit Ctrl-H"],
            label="halt",
        )

    def action_disarm(self) -> None:
        self._write_meta("[green]◈ disarming PROTOCOL-ZERO ...[/green]")
        self._run_cli_async(["sovereign", "disarm"], label="disarm")

    # ── Chat rendering helpers ───────────────────────────────────────

    def _write_you(self, text: str) -> None:
        if self._chat_log is None:
            return
        self._chat_log.write(f"[b yellow][you][/b yellow] {text}")

    def _write_aria_thinking(self) -> None:
        if self._chat_log is None:
            return
        self._chat_log.write("[b cyan][aria][/b cyan] [dim]thinking ...[/dim]")

    def _write_aria(self, text: str) -> None:
        if self._chat_log is None:
            return
        self._chat_log.write(f"  {text}")

    def _write_meta(self, text: str) -> None:
        if self._chat_log is None:
            return
        self._chat_log.write(text)


# ─── Entry point ────────────────────────────────────────────────────────────


def run() -> None:
    """Launch the cockpit. Called from cli.cockpit."""
    app = CockpitApp()
    app.run()


if __name__ == "__main__":
    run()
