"""
╔══════════════════════════════════════════════════════════════════════════╗
║  cli.py — Operator surface (v0.2.5)                                      ║
║  Architecture §5 + §7a + §8a + §11 + §13                                 ║
╚══════════════════════════════════════════════════════════════════════════╝

The CLI is how YOU (the operator) talk to the agent. The agent doesn't
use it. Commands are grouped by purpose:

    Setup:        init       — bootstrap config dirs, secret key, DBs
                  doctor     — diagnose config + ollama reachability + models
                  config     — show resolved configuration
    Run:          run        — single ONESHOT task
                  busy       — drain backlog forever (or once / N times)
                  until      — drain until predicate
    Re-trigger:   plan       — pre-decompose a large task into atomic steps
                  continue   — execute ONE pending step from a continuation
                  continuations — list / show / delete continuation files
    Backlog:      backlog    — list / add / remove / show / requeue / clear
    Approvals:    approvals  — list pending Tier 3 requests
                  approve    — grant a request
                  deny       — refuse a request
    Safety:       halt       — trip PROTOCOL-ZERO
                  disarm     — clear PROTOCOL-ZERO (after review)
    Audit:        tail       — ingest events.jsonl into events.db
                  seal       — compute yesterday's Merkle root
                  verify     — verify a past seal still matches its events
                  events     — show recent events (with --follow)
                  lessons    — show recent distilled lessons

Exit codes are stable and documented:
    0  success
    1  generic runtime error
    2  usage error
    3  PROTOCOL-ZERO armed (refused start)
    4  not initialized (run `sovereign init`)
    5  ollama unreachable
    6  approval not found / already resolved
    7  budget exhausted (when applicable)
    8  continuation drained (used by `continue` and the loop driver)
    9  continuation locked by another process

Top-level flags (apply to every command):
    --version
    --json / -j         emit JSON for read commands
    --quiet / -q        suppress non-essential output
    --verbose / -v      log INFO / DEBUG to stderr
    --no-color          disable Rich color (implied when not a TTY)
    --config-dir PATH   override XDG config dir
    --data-dir PATH     override XDG data dir
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import structlog
import typer
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from . import __version__, protocol_zero
from .config import SETTINGS, Paths
from .events import init_events_db, tail_to_sqlite
from .modes import Mode, RunBudget


# ─── Exit codes (single source of truth) ────────────────────────────────────


class ExitCode:
    OK = 0
    ERROR = 1
    USAGE = 2
    HALTED = 3
    NOT_INITIALIZED = 4
    OLLAMA_UNREACHABLE = 5
    APPROVAL_NOT_FOUND = 6
    BUDGET = 7
    DRAINED = 8
    LOCKED = 9


# ─── Global state set by the top-level callback ─────────────────────────────


class _CliState:
    json_out: bool = False
    quiet: bool = False
    verbose: bool = False
    no_color: bool = False


STATE = _CliState()
console = Console()


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(level=level, stream=sys.stderr, format="%(message)s")
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.dev.ConsoleRenderer(colors=not STATE.no_color),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
    )


def _override_paths(*, config_dir: Path | None, data_dir: Path | None) -> None:
    """Mutate SETTINGS.paths in place. Same trick as conftest."""
    if config_dir is None and data_dir is None:
        return
    new_paths = Paths(
        config_dir=config_dir or SETTINGS.paths.config_dir,
        data_dir=data_dir or SETTINGS.paths.data_dir,
    )
    object.__setattr__(SETTINGS, "paths", new_paths)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"sovereign-agent {__version__}")
        raise typer.Exit(ExitCode.OK)


app = typer.Typer(
    no_args_is_help=True,
    add_completion=True,
    rich_markup_mode="rich",
    help="◈ sovereign-agent — your local 24/7 agent",
    pretty_exceptions_show_locals=False,
)


@app.callback()
def _global_options(
    version: bool = typer.Option(
        False, "--version", callback=_version_callback, is_eager=True,
        help="Show version and exit.",
    ),
    json_out: bool = typer.Option(False, "--json", "-j", help="Emit JSON for read commands."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress non-essential output."),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Log INFO/DEBUG to stderr."),
    no_color: bool = typer.Option(False, "--no-color", help="Disable color output."),
    config_dir: Path | None = typer.Option(None, "--config-dir", help="Override XDG config dir."),
    data_dir: Path | None = typer.Option(None, "--data-dir", help="Override XDG data dir."),
) -> None:
    """Global options. Apply to every subcommand."""
    STATE.json_out = json_out
    STATE.quiet = quiet
    STATE.verbose = verbose
    STATE.no_color = no_color or not sys.stdout.isatty()
    if STATE.no_color:
        global console
        console = Console(no_color=True, force_terminal=False)
    _override_paths(config_dir=config_dir, data_dir=data_dir)
    _setup_logging(verbose)


# ─── Output helpers ─────────────────────────────────────────────────────────


def _print(*args: Any, **kwargs: Any) -> None:
    if STATE.quiet:
        return
    console.print(*args, **kwargs)


def _emit_json(payload: Any) -> None:
    typer.echo(json.dumps(payload, default=str, indent=2 if sys.stdout.isatty() else None))


def _die(code: int, message: str, *, hint: str | None = None) -> None:
    if STATE.json_out:
        payload = {"ok": False, "code": code, "error": message}
        if hint:
            payload["hint"] = hint
        _emit_json(payload)
    else:
        console.print(f"[red]✗ {message}[/red]")
        if hint:
            console.print(f"[dim]hint: {hint}[/dim]")
    raise typer.Exit(code)


# ─── Pre-flight checks ──────────────────────────────────────────────────────


def _preflight_initialized() -> None:
    if not SETTINGS.paths.secret_key_file.exists():
        _die(ExitCode.NOT_INITIALIZED, "agent is not initialized",
             hint="run `sovereign init` first")


def _preflight_not_halted() -> None:
    if SETTINGS.paths.halt_flag.exists() or protocol_zero.is_armed():
        _die(ExitCode.HALTED, "PROTOCOL-ZERO is armed",
             hint="review HALT file, then `sovereign disarm`")


def _preflight_ollama_reachable(*, fatal: bool = True) -> bool:
    import socket
    from urllib.parse import urlparse

    parsed = urlparse(SETTINGS.ollama_host)
    host = parsed.hostname or "localhost"
    port = parsed.port or 11434
    try:
        with socket.create_connection((host, port), timeout=3):
            return True
    except (OSError, socket.timeout) as e:
        if fatal:
            _die(ExitCode.OLLAMA_UNREACHABLE,
                 f"ollama unreachable at {host}:{port}: {e}",
                 hint="start ollama, or set OLLAMA_HOST")
        return False


# ─── Banner ─────────────────────────────────────────────────────────────────


BANNER = """[bold cyan]
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║              ◈  S O V E R E I G N   A G E N T  ◈                     ║
║                                                                      ║
║       local · authority-tiered · audited · recoverable · yours       ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
[/bold cyan]"""


def _build_tools_for_mode(mode: Mode) -> dict:
    from .tools import (
        CopyFileTool, EditFileTool, EmbedQueryTool, ImageCaptionTool,
        ImpactScoreTool, ListDirTool, MemorySearchTool, MemoryWriteTool,
        PalaceSearchTool, ProposalWriteTool, ReadFileTool, SearchTextTool,
        WebFetchTool, WebSearchTool, WriteFileTool, internet_available,
    )
    tools = {
        "read_file": ReadFileTool(),
        "list_dir": ListDirTool(),
        "search_text": SearchTextTool(),
        "embed_query": EmbedQueryTool(),
        "image_caption": ImageCaptionTool(),
        "web_fetch": WebFetchTool(),
        "memory_search": MemorySearchTool(),
        "memory_write": MemoryWriteTool(),
        "palace_search": PalaceSearchTool(),
        "proposal_write": ProposalWriteTool(),
        "impact_score": ImpactScoreTool(),
        "write_file": WriteFileTool(mode=mode),
        "edit_file": EditFileTool(mode=mode),
        "copy_file": CopyFileTool(mode=mode),
    }
    if internet_available():
        tools["web_search"] = WebSearchTool()
    return tools


# ═══════════════════════════════════════════════════════════════════════════
#  SETUP
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def init() -> None:
    """Bootstrap config dirs, generate secret key, initialize DBs."""
    if not STATE.json_out:
        _print(BANNER)
        _print("[bold]Initializing sovereign-agent...[/bold]\n")

    SETTINGS.paths.ensure()
    from .approval import _load_or_create_secret  # noqa: WPS437
    _load_or_create_secret()

    conn_e = init_events_db()
    conn_e.close()
    from .db import open_atoms_db
    conn_a = open_atoms_db()
    conn_a.close()

    if STATE.json_out:
        _emit_json({
            "ok": True,
            "config_dir": str(SETTINGS.paths.config_dir),
            "data_dir": str(SETTINGS.paths.data_dir),
            "sandbox": str(SETTINGS.paths.sandbox_dir),
            "events": str(SETTINGS.paths.events_dir),
            "atoms_db": str(SETTINGS.paths.atoms_db),
            "continuations": str(SETTINGS.paths.continuations_dir),
            "palace_db": str(SETTINGS.paths.palace_db),
            "proposals_dir": str(SETTINGS.paths.proposals_dir),
        })
        return

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column(style="dim")
    table.add_column()
    table.add_row("config dir", str(SETTINGS.paths.config_dir))
    table.add_row("data dir", str(SETTINGS.paths.data_dir))
    table.add_row("sandbox", str(SETTINGS.paths.sandbox_dir))
    table.add_row("events", str(SETTINGS.paths.events_dir))
    table.add_row("atoms.db", str(SETTINGS.paths.atoms_db))
    table.add_row("continuations", str(SETTINGS.paths.continuations_dir))
    table.add_row("palace.db", str(SETTINGS.paths.palace_db))
    table.add_row("proposals", str(SETTINGS.paths.proposals_dir))
    table.add_row("secret key", "[green]created[/green] (mode 0600)")
    _print(Panel(table, title="◈ initialized", border_style="green"))


@app.command()
def doctor() -> None:
    """Diagnose the agent's environment: paths, models, Ollama, VRAM, locks."""
    import shutil
    import socket
    from urllib.parse import urlparse

    if not STATE.json_out:
        _print(BANNER)
        _print("[bold]Running diagnostics...[/bold]\n")

    rows: list[dict[str, str]] = []

    def add(name: str, status: str, detail: str = "") -> None:
        rows.append({"check": name, "status": status, "detail": detail})

    for label, path in [
        ("config_dir", SETTINGS.paths.config_dir),
        ("data_dir", SETTINGS.paths.data_dir),
        ("sandbox_dir", SETTINGS.paths.sandbox_dir),
        ("events_dir", SETTINGS.paths.events_dir),
        ("atoms.db", SETTINGS.paths.atoms_db),
        ("secret.key", SETTINGS.paths.secret_key_file),
        ("continuations", SETTINGS.paths.continuations_dir),
    ]:
        add(label, "PASS" if path.exists() else "WARN",
            str(path) if path.exists() else f"{path} (run `sovereign init`)")

    if SETTINGS.paths.secret_key_file.exists():
        mode = SETTINGS.paths.secret_key_file.stat().st_mode & 0o777
        if mode == 0o600:
            add("secret mode", "PASS", "0600 (owner read-only)")
        else:
            add("secret mode", "FAIL", f"mode {oct(mode)} — should be 0600")

    add("orchestrator", "PASS", SETTINGS.orchestrator_model)
    add("coder", "PASS", SETTINGS.coder_model)
    add("embedder", "PASS", SETTINGS.embed_model)
    add("reflector", "PASS", SETTINGS.reflector_model)

    parsed = urlparse(SETTINGS.ollama_host)
    host = parsed.hostname or "localhost"
    port = parsed.port or 11434
    ollama_up = False
    try:
        with socket.create_connection((host, port), timeout=2):
            add("ollama tcp", "PASS", f"{host}:{port}")
            ollama_up = True
    except (OSError, socket.timeout) as e:
        add("ollama tcp", "FAIL", f"{host}:{port} unreachable: {e}")

    if ollama_up:
        try:
            import httpx
            r = httpx.get(f"{SETTINGS.ollama_host}/api/tags", timeout=5)
            r.raise_for_status()
            installed = {m["name"] for m in r.json().get("models", [])}
            for label, name in [
                ("orchestrator model", SETTINGS.orchestrator_model),
                ("embedder model", SETTINGS.embed_model),
                ("reflector model", SETTINGS.reflector_model),
            ]:
                if name in installed or any(n.startswith(name + ":") for n in installed):
                    add(label, "PASS", "found")
                else:
                    add(label, "FAIL", f"{name!r} not installed (try `ollama pull {name}`)")

            try:
                from .ollama_client import OllamaClient

                async def _probe():
                    cli = OllamaClient()
                    return {
                        "orchestrator": await cli.supports_thinking(SETTINGS.orchestrator_model),
                        "reflector": await cli.supports_thinking(SETTINGS.reflector_model),
                    }
                caps = asyncio.run(_probe())
                for label, key in [("orch thinking", "orchestrator"), ("reflector thinking", "reflector")]:
                    add(label, "PASS" if caps[key] else "WARN",
                        "supported" if caps[key] else "NOT supported (auto-disabled)")
            except Exception as e:  # noqa: BLE001
                add("capabilities", "WARN", f"could not probe: {e}")
        except Exception as e:  # noqa: BLE001
            add("ollama models", "WARN", f"could not query: {e}")

    if shutil.which("bwrap"):
        add("bubblewrap", "PASS", shutil.which("bwrap"))
    else:
        add("bubblewrap", "FAIL", "not installed — `apt install bubblewrap`")

    if SETTINGS.paths.halt_flag.exists():
        add("protocol-zero", "WARN", "ARMED — `sovereign disarm`")
    else:
        add("protocol-zero", "PASS", "clear")

    # Internet (v0.2.7+) — informational; not a failure when off.
    from .tools import internet_available, reset_internet_cache
    reset_internet_cache()  # fresh probe each doctor run
    setting = os.environ.get("AGENT_INTERNET", "auto").lower()
    if internet_available():
        add("internet", "PASS", f"available (AGENT_INTERNET={setting})")
    else:
        add("internet", "WARN",
            f"unavailable (AGENT_INTERNET={setting}) — web_search disabled")

    try:
        from .vram import read_vram
        snap = read_vram()
        add("vram", "PASS", f"{snap.free_mb} MB free / {snap.total_mb} MB total ({snap.source})")
    except Exception as e:  # noqa: BLE001
        add("vram", "WARN", f"could not read: {e}")

    if STATE.json_out:
        n_fail = sum(1 for r in rows if r["status"] == "FAIL")
        _emit_json({"ok": n_fail == 0, "checks": rows, "fail_count": n_fail})
        return

    table = Table(title="◈ doctor", show_header=True, header_style="bold cyan")
    table.add_column("check", style="dim", width=22)
    table.add_column("status", width=8)
    table.add_column("detail", overflow="fold")
    for r in rows:
        color = {"PASS": "green", "WARN": "yellow", "FAIL": "red"}.get(r["status"], "white")
        table.add_row(r["check"], f"[{color}]{r['status']}[/{color}]", r["detail"])
    _print(table)


@app.command(name="config")
def show_config() -> None:
    """Print the resolved configuration with effective values."""
    payload = {
        "version": __version__,
        "paths": {
            "config_dir": str(SETTINGS.paths.config_dir),
            "data_dir": str(SETTINGS.paths.data_dir),
            "sandbox_dir": str(SETTINGS.paths.sandbox_dir),
            "events_dir": str(SETTINGS.paths.events_dir),
            "atoms_db": str(SETTINGS.paths.atoms_db),
            "continuations_dir": str(SETTINGS.paths.continuations_dir),
            "palace_db": str(SETTINGS.paths.palace_db),
            "proposals_dir": str(SETTINGS.paths.proposals_dir),
            "backlog_yaml": str(SETTINGS.paths.backlog_yaml),
        },
        "models": {
            "orchestrator": SETTINGS.orchestrator_model,
            "coder": SETTINGS.coder_model,
            "embedder": SETTINGS.embed_model,
            "reflector": SETTINGS.reflector_model,
            "fast": SETTINGS.fast_model,
        },
        "ollama_host": SETTINGS.ollama_host,
        "think_mode": SETTINGS.think_mode,
        "num_ctx": SETTINGS.num_ctx,
        "approval_default_expiry_seconds": SETTINGS.approval_default_expiry_seconds,
        "env_overrides": {
            k: os.environ.get(k) for k in (
                "OLLAMA_HOST", "AGENT_ORCHESTRATOR_MODEL", "AGENT_CODER_MODEL",
                "AGENT_EMBED_MODEL", "AGENT_REFLECTOR_MODEL", "AGENT_FAST_MODEL",
                "AGENT_THINK",
            ) if os.environ.get(k) is not None
        },
    }

    if STATE.json_out:
        _emit_json(payload)
        return

    table = Table(title="◈ config", show_header=False, box=None, padding=(0, 1))
    table.add_column(style="dim")
    table.add_column()
    table.add_row("version", payload["version"])
    table.add_row("ollama_host", payload["ollama_host"])
    table.add_row("think_mode", payload["think_mode"])
    table.add_row("num_ctx", str(payload["num_ctx"]))
    table.add_row("orchestrator", payload["models"]["orchestrator"])
    table.add_row("coder", payload["models"]["coder"])
    table.add_row("embedder", payload["models"]["embedder"])
    table.add_row("reflector", payload["models"]["reflector"])
    table.add_row("fast", payload["models"]["fast"])
    for k, v in payload["paths"].items():
        table.add_row(f"path.{k}", v)
    if payload["env_overrides"]:
        for k, v in payload["env_overrides"].items():
            table.add_row(f"env.{k}", v)
    _print(table)


# ═══════════════════════════════════════════════════════════════════════════
#  RUN
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def run(
    goal: str = typer.Argument(..., help="What you want the agent to accomplish"),
    mode: Mode = typer.Option(Mode.ONESHOT, "--mode"),
    max_iterations: int = typer.Option(25, "--max-iter"),
    max_wall_seconds: int = typer.Option(1800, "--max-wall"),
    max_tokens: int = typer.Option(200_000, "--max-tokens"),
    dry_run: bool = typer.Option(False, "--dry-run",
        help="Show resolved tools, mode, and budget without invoking the model."),
) -> None:
    """Run a single task through the agent loop."""
    _preflight_initialized()
    if not dry_run:
        _preflight_not_halted()
        _preflight_ollama_reachable()

    from .loop import agent_loop

    protocol_zero.install_signal_handlers()
    tools = _build_tools_for_mode(mode)
    budget = RunBudget(max_iterations=max_iterations,
                      max_wall_seconds=max_wall_seconds, max_tokens=max_tokens)

    if dry_run:
        from .authority import tools_available_in_mode
        from .modes import MODE_TIER_CEILING
        available = sorted(m.name for m in tools_available_in_mode(mode))
        payload = {
            "ok": True, "dry_run": True, "goal": goal, "mode": mode.value,
            "tier_ceiling": MODE_TIER_CEILING[mode],
            "available_tools": available,
            "budget": {
                "max_iterations": budget.max_iterations,
                "max_wall_seconds": budget.max_wall_seconds,
                "max_tokens": budget.max_tokens,
            },
        }
        if STATE.json_out:
            _emit_json(payload)
        else:
            table = Table(title=f"◈ dry-run · {mode.value}")
            table.add_column("field", style="dim")
            table.add_column("value", overflow="fold")
            table.add_row("goal", goal)
            table.add_row("mode", mode.value)
            table.add_row("tier_ceiling", str(payload["tier_ceiling"]))
            table.add_row("tools", ", ".join(available))
            table.add_row("budget.iter", str(budget.max_iterations))
            table.add_row("budget.wall", f"{budget.max_wall_seconds}s")
            table.add_row("budget.tokens", str(budget.max_tokens))
            _print(table)
        raise typer.Exit(ExitCode.OK)

    _print(f"\n◈ [bold]{mode.value}[/bold] · {goal[:80]}\n")
    result = asyncio.run(agent_loop(goal=goal, mode=mode, budget=budget, tools=tools))

    if STATE.json_out:
        _emit_json({
            "ok": result.ok, "reason": result.reason,
            "iterations": result.iterations, "tokens": result.tokens_used,
            "lesson_id": result.lesson_id, "final_message": result.final_message,
        })
    else:
        color = "green" if result.ok else "yellow"
        _print(Panel(
            f"[bold]{result.reason}[/bold]\n"
            f"iterations: {result.iterations}  ·  tokens: {result.tokens_used}\n"
            f"lesson: {result.lesson_id or '(none)'}",
            title="◈ result", border_style=color,
        ))
        if result.final_message:
            _print("\n" + result.final_message)
    raise typer.Exit(ExitCode.OK if result.ok else ExitCode.ERROR)


@app.command()
def busy(
    cooldown: float = typer.Option(5.0, "--cooldown", help="Seconds between tasks"),
    empty_sleep: float = typer.Option(30.0, "--empty-sleep", help="Sleep when backlog empty"),
    max_iter_per_task: int = typer.Option(25, "--max-iter"),
    max_wall_per_task: int = typer.Option(1800, "--max-wall"),
    once: bool = typer.Option(False, "--once", help="Drain one task then exit (cron-friendly)."),
    max_tasks: int = typer.Option(0, "--max-tasks", help="At most N tasks then exit (0=unbounded)."),
) -> None:
    """Drain the backlog. PROTOCOL-ZERO is the only stop signal in unbounded mode."""
    _preflight_initialized()
    _preflight_not_halted()
    _preflight_ollama_reachable()

    from .mode_controller import ControllerSettings, ModeController

    _print(BANNER)
    _print(Panel(
        "[bold yellow]BUSY mode[/bold yellow] — Tier 0 + Tier 1 only.\n"
        "Tier 2 and Tier 3 are not in the agent's tool list.\n"
        "Stop with: [cyan]sovereign halt[/cyan]  or  [cyan]echo > ~/.config/sovereign-agent/HALT[/cyan]",
        border_style="yellow",
    ))

    tools = _build_tools_for_mode(Mode.BUSY)
    settings = ControllerSettings(
        cooldown_seconds=cooldown, empty_backlog_sleep=empty_sleep,
        per_task_budget=RunBudget(max_iterations=max_iter_per_task,
                                  max_wall_seconds=max_wall_per_task),
    )
    controller = ModeController(tools=tools, settings=settings)
    try:
        if once:
            asyncio.run(controller._drain_iteration())
        elif max_tasks > 0:
            async def _bounded() -> None:
                count = 0
                while count < max_tasks and not protocol_zero.is_armed():
                    ran = await controller._drain_iteration()
                    if ran:
                        count += 1
                        await asyncio.sleep(cooldown)
                    else:
                        await asyncio.sleep(empty_sleep)
            asyncio.run(_bounded())
        else:
            asyncio.run(controller.run_busy())
    except KeyboardInterrupt:
        _print("\n[yellow]interrupted[/yellow]")
    _print("[green]busy mode stopped[/green]")


@app.command()
def until(
    minutes: int = typer.Option(..., "--minutes", help="Stop after this many minutes"),
    mode: Mode = typer.Option(Mode.ONESHOT, "--mode"),
) -> None:
    """Drain backlog until a time limit is reached."""
    _preflight_initialized()
    _preflight_not_halted()
    _preflight_ollama_reachable()

    from .mode_controller import ModeController

    end_ts = time.time() + minutes * 60
    tools = _build_tools_for_mode(mode)
    controller = ModeController(tools=tools)

    def _done() -> bool:
        return time.time() >= end_ts

    _print(f"\n◈ [bold]until[/bold] · stopping in {minutes} minutes\n")
    asyncio.run(controller.run_until(_done))


# ═══════════════════════════════════════════════════════════════════════════
#  RE-TRIGGER ARCHITECTURE — plan / continue / continuations
# ═══════════════════════════════════════════════════════════════════════════


plan_app = typer.Typer(help="◈ pre-decompose a large task into atomic continuation steps")


@app.command(name="plan")
def plan_cmd(
    planner: str | None = typer.Argument(None, help="Planner name (omit to list)."),
    root: Path | None = typer.Option(None, "--root", help="Root path the planner walks."),
    output: Path | None = typer.Option(None, "--output", help="Aggregation output."),
    pattern: list[str] = typer.Option([], "--pattern", help="Glob pattern. Repeatable."),
    exclude: list[str] = typer.Option(
        [], "--exclude",
        help="Glob pattern to exclude files (matched against full path). Repeatable. (v0.2.6)",
    ),
    include: list[str] = typer.Option(
        [], "--include",
        help="Glob pattern whitelist (image-inventory only). Repeatable. (v0.2.6)",
    ),
    include_no_ext: bool = typer.Option(
        False, "--include-no-extension",
        help="Also include files with no extension (LICENSE, transcripts). (v0.2.6)",
    ),
    max_files: int = typer.Option(0, "--max-files", help="Cap step count (0=unbounded)."),
    no_recursive: bool = typer.Option(False, "--no-recursive", help="Don't walk subdirs."),
    tag: str | None = typer.Option(None, "--tag", help="Tag (read-files planner)."),
    max_extract_chars: int = typer.Option(
        40_000, "--max-extract-chars",
        help="Per-file extraction cap (pdf-inventory). (v0.2.6)",
    ),
    max_file_size: int = typer.Option(
        0, "--max-file-size",
        help="Skip files larger than N bytes (0=use planner default). (v0.2.6)",
    ),
    room_id: str | None = typer.Option(
        None, "--room-id",
        help="Palace room id (palace-mine planner). (v0.2.8)",
    ),
    room_name: str | None = typer.Option(
        None, "--room-name",
        help="Palace room display name (palace-mine planner). (v0.2.8)",
    ),
    atom_type: str | None = typer.Option(
        None, "--atom-type",
        help="Filter atoms by type (palace-mine planner). (v0.2.8)",
    ),
    task_id: str | None = typer.Option(None, "--task-id", help="Override generated ULID."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show the plan, don't write."),
) -> None:
    """Run a planner. With no planner name, lists available planners."""
    from .planners import REGISTRY, get_planner
    from .planners.base import PlannerError, PlannerNotFound
    from .continuation import ContinuationStore

    if planner is None:
        if STATE.json_out:
            _emit_json({"planners": [
                {"name": p.name, "description": p.description,
                 "required_args": list(p.required_args())}
                for p in REGISTRY.values()
            ]})
            return
        table = Table(title="◈ planners", show_header=True, header_style="bold cyan")
        table.add_column("name", style="cyan")
        table.add_column("required args", style="magenta")
        table.add_column("description")
        for p in REGISTRY.values():
            table.add_row(p.name, ", ".join(p.required_args()) or "—", p.description)
        _print(table)
        _print("\n[dim]Run a planner: [/dim][cyan]sovereign plan inventory --root <dir> --output <file>[/cyan]")
        return

    try:
        planner_obj = get_planner(planner)
    except PlannerNotFound as e:
        _die(ExitCode.USAGE, str(e), hint="run `sovereign plan` to list planners")

    args = {
        "root": str(root) if root else None,
        "output": str(output) if output else None,
        "patterns": pattern or None,
        "exclude": exclude or None,
        "include": include or None,
        "include_no_extension": include_no_ext if include_no_ext else None,
        "max_files": max_files,
        "recursive": not no_recursive,
        "tag": tag,
        "max_extract_chars": max_extract_chars if max_extract_chars != 40_000 else None,
        "max_file_size_bytes": max_file_size if max_file_size > 0 else None,
        "room_id": room_id,
        "room_name": room_name,
        "atom_type": atom_type,
    }
    args = {k: v for k, v in args.items() if v is not None}

    try:
        result = planner_obj.plan(**args)
    except PlannerError as e:
        _die(ExitCode.USAGE, f"plan failed: {e}")

    if dry_run:
        payload = {
            "ok": True, "dry_run": True, "planner": planner,
            "goal": result.goal, "step_count": len(result.steps),
            "output_path": result.output_path,
            "first_steps": [{"id": s.id, "kind": s.kind, "args": s.args}
                           for s in result.steps[:5]],
        }
        if STATE.json_out:
            _emit_json(payload)
        else:
            _print(Panel(
                f"[bold]{result.goal}[/bold]\n"
                f"steps: {len(result.steps)}\n"
                f"output: {result.output_path or '(none)'}\n"
                f"notes: {result.notes}",
                title=f"◈ plan (dry-run) · {planner}", border_style="cyan",
            ))
            if result.steps:
                t = Table(title="first 5 steps", show_header=True)
                t.add_column("id", style="dim")
                t.add_column("kind")
                t.add_column("args", overflow="fold")
                for s in result.steps[:5]:
                    t.add_row(str(s.id), s.kind, json.dumps(s.args, default=str)[:120])
                _print(t)
        return

    _preflight_initialized()
    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    cont = store.create(
        goal=result.goal, planner=planner, planner_args=args,
        steps=result.steps, output_path=result.output_path,
        task_id=task_id, notes=result.notes,
    )

    if STATE.json_out:
        _emit_json({"ok": True, "task_id": cont.task_id,
                    "step_count": len(cont.steps), "goal": cont.goal,
                    "output_path": cont.output_path})
    else:
        _print(Panel(
            f"[bold]{cont.goal}[/bold]\n"
            f"task_id: [cyan]{cont.task_id}[/cyan]\n"
            f"steps: {len(cont.steps)}\n"
            f"output: {cont.output_path or '(none)'}\n\n"
            f"[dim]drive it:[/dim] [cyan]sovereign continue {cont.task_id}[/cyan]\n"
            f"[dim]or loop:[/dim]  [cyan]scripts/sovereign-continue-loop.sh {cont.task_id}[/cyan]",
            title="◈ continuation created", border_style="green",
        ))


@app.command(name="continue")
def continue_(
    task_id: str = typer.Argument(..., help="Continuation ID from `sovereign plan`"),
    max_iter: int = typer.Option(5, "--max-iter", help="Per-step iteration cap."),
    max_wall: int = typer.Option(120, "--max-wall", help="Per-step wall-time cap (seconds)."),
    max_tokens: int = typer.Option(20_000, "--max-tokens", help="Per-step token cap."),
    model_filter: str | None = typer.Option(
        None, "--model-filter",
        help="Only run steps requiring this model (orchestrator/coder/vision/none). (v0.2.6)",
    ),
) -> None:
    """Execute exactly ONE pending step from a continuation, then exit.

    Exit codes: 0 step OK · 1 step poison · 3 halted · 8 drained · 9 locked

    With ``--model-filter X``, only run a step whose ``required_model == X``.
    Other steps stay pending. Use this to batch by model affinity:

        sovereign continue <id> --model-filter orchestrator
        sovereign continue <id> --model-filter vision

    Or use the higher-level ``sovereign drain-by-model <id>`` which sequences
    phases automatically.
    """
    _preflight_initialized()
    _preflight_not_halted()

    # Pre-flight Ollama only if this continuation has steps that need a model.
    # palace-mine and metadata-inventory continuations are pure-Python; they
    # shouldn't refuse to start just because Ollama is down. v0.2.8.
    from .continuation import ContinuationStore
    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    needs_model = False
    try:
        cont_preview = store.get(task_id)
        models = cont_preview.models_needed()
        # If model_filter is set and it's 'none', or all pending models are
        # 'none', skip the Ollama check.
        if model_filter == "none":
            needs_model = False
        elif model_filter is not None:
            needs_model = model_filter != "none"
        else:
            needs_model = any(m != "none" for m in models)
    except Exception:  # noqa: BLE001
        # If we can't read the continuation, fall through to the normal path.
        needs_model = True

    if needs_model:
        _preflight_ollama_reachable()

    from .continue_runner import run_one_step
    tools = _build_tools_for_mode(Mode.ONESHOT)
    budget = RunBudget(max_iterations=max_iter, max_wall_seconds=max_wall,
                      max_tokens=max_tokens, consecutive_fail_limit=2)

    protocol_zero.install_signal_handlers()
    result = asyncio.run(run_one_step(
        task_id=task_id, tools=tools, store=store, budget=budget,
        mode=Mode.ONESHOT, model_filter=model_filter,
    ))

    payload = {
        "task_id": result.task_id, "step_id": result.step_id,
        "step_kind": result.step_kind, "outcome": result.outcome,
        "iterations": result.iterations, "tokens": result.tokens,
        "elapsed_seconds": result.elapsed_seconds,
        "required_model": result.required_model,
        "cont_status": result.cont_status, "progress": list(result.progress),
        "final_message": result.final_message,
        "model_filter": model_filter,
    }

    if result.outcome == "locked":
        if STATE.json_out:
            _emit_json({"ok": False, "code": ExitCode.LOCKED, **payload})
        else:
            _print(f"[yellow]locked[/yellow] · {task_id} held by another runner")
        raise typer.Exit(ExitCode.LOCKED)

    if result.outcome == "filtered":
        # No work for this model right now, but other models still have steps.
        # Use a distinct exit code so drain-by-model knows to advance phase.
        if STATE.json_out:
            _emit_json({"ok": True, "code": ExitCode.DRAINED, **payload})
        else:
            done, total = result.progress
            _print(
                f"[dim]filtered[/dim] · no '{model_filter}' steps · "
                f"{done}/{total} · status={result.cont_status}"
            )
        raise typer.Exit(ExitCode.DRAINED)

    if result.outcome in ("drained", "no_step"):
        if STATE.json_out:
            _emit_json({"ok": True, "code": ExitCode.DRAINED, **payload})
        else:
            done, total = result.progress
            _print(f"[green]drained[/green] · {done}/{total} · status={result.cont_status}")
        raise typer.Exit(ExitCode.DRAINED)

    if STATE.json_out:
        ok = result.outcome == "complete"
        # Surface VRAM in JSON too — operators using --json for monitoring
        # benefit from per-step VRAM data.
        payload["vram_before_mb"] = result.vram_before_mb
        payload["vram_peak_mb"] = result.vram_peak_mb
        payload["vram_after_mb"] = result.vram_after_mb
        _emit_json({"ok": ok, "code": ExitCode.OK if ok else ExitCode.ERROR, **payload})
    else:
        from .continuation import format_elapsed

        # Build VRAM suffix. Empty string when no GPU data — keeps the line
        # uncluttered on no-GPU systems and on pure-Python steps. v0.2.11+.
        vram_suffix = ""
        if result.vram_before_mb is not None and result.vram_peak_mb is not None:
            delta = result.vram_peak_mb - result.vram_before_mb
            sign = "+" if delta >= 0 else ""
            vram_suffix = (
                f" · vram={result.vram_before_mb}→{result.vram_peak_mb}MB "
                f"Δ{sign}{delta}"
            )

        done, total = result.progress
        if result.outcome == "complete":
            _print(f"[green]✓ step {result.step_id}[/green] ({result.step_kind}) · "
                  f"{done}/{total} · iter={result.iterations} tokens={result.tokens} · "
                  f"elapsed={format_elapsed(result.elapsed_seconds)}{vram_suffix}")
        else:
            _print(f"[red]✗ step {result.step_id}[/red] ({result.step_kind}) · "
                  f"{result.outcome} · {done}/{total} · "
                  f"elapsed={format_elapsed(result.elapsed_seconds)}{vram_suffix}")
    raise typer.Exit(ExitCode.OK if result.outcome == "complete" else ExitCode.ERROR)


@app.command(name="drain-by-model")
def drain_by_model_cmd(
    task_id: str = typer.Argument(..., help="Continuation ID to drain"),
    max_iter: int = typer.Option(5, "--max-iter", help="Per-step iteration cap."),
    max_wall: int = typer.Option(120, "--max-wall", help="Per-step wall-time cap (s)."),
    max_tokens: int = typer.Option(20_000, "--max-tokens", help="Per-step token cap."),
    cooldown: float = typer.Option(2.0, "--cooldown", help="Sleep between steps (s)."),
) -> None:
    """Drain a continuation in model-affinity phases. v0.2.6.

    Inspects the continuation's pending steps, groups by ``required_model``,
    and runs each model's batch contiguously. Each model loads exactly once
    instead of swapping in and out per step.

    Phase order: ``orchestrator`` first (most common, fastest to load), then
    other models alphabetically. ``required_model='none'`` steps run without
    invoking any model.

    Stops cleanly on PROTOCOL-ZERO. Halt-and-resume safe — all state is in
    the continuation file. Re-running picks up exactly where it left off.

    Exit codes: 0 fully drained · 3 halted · other = error.
    """
    _preflight_initialized()
    _preflight_not_halted()

    from .continuation import ContinuationStore
    from .continue_runner import run_one_step

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    cont = store.get(task_id)

    # Pre-flight Ollama only if any pending phase actually needs a model. v0.2.8.
    if any(m != "none" for m in cont.models_needed()):
        _preflight_ollama_reachable()

    if cont.is_drained():
        if STATE.json_out:
            _emit_json({"ok": True, "drained": True, "task_id": task_id})
        else:
            _print(f"[green]already drained[/green] · {task_id}")
        return

    phases = cont.models_needed()
    if not phases:
        if STATE.json_out:
            _emit_json({"ok": True, "drained": True, "task_id": task_id})
        else:
            _print(f"[green]nothing pending[/green] · {task_id}")
        return

    if not STATE.json_out:
        _print(Panel(
            f"[bold]{cont.goal}[/bold]\n"
            f"phases: {' → '.join(phases)}\n"
            f"total pending: {sum(len([s for s in cont.steps if s.status == 'pending' and s.required_model == m]) for m in phases)}",
            title=f"◈ drain-by-model · {task_id}",
            border_style="cyan",
        ))

    tools = _build_tools_for_mode(Mode.ONESHOT)
    budget = RunBudget(
        max_iterations=max_iter, max_wall_seconds=max_wall,
        max_tokens=max_tokens, consecutive_fail_limit=2,
    )

    protocol_zero.install_signal_handlers()

    overall_start = time.monotonic()
    phase_results = []

    for phase_idx, model in enumerate(phases, start=1):
        if protocol_zero.is_armed():
            if not STATE.json_out:
                _print("[red]HALT armed · stopping[/red]")
            raise typer.Exit(ExitCode.HALTED)

        if not STATE.json_out:
            _print(f"\n[bold cyan]◈ phase {phase_idx}/{len(phases)}: {model}[/bold cyan]")

        phase_start = time.monotonic()
        phase_steps = 0
        phase_complete = 0
        phase_poison = 0

        while True:
            if protocol_zero.is_armed():
                break

            result = asyncio.run(run_one_step(
                task_id=task_id, tools=tools, store=store, budget=budget,
                mode=Mode.ONESHOT, model_filter=model,
            ))

            if result.outcome == "locked":
                if not STATE.json_out:
                    _print(f"[yellow]locked, waiting…[/yellow]")
                time.sleep(5.0)
                continue

            if result.outcome in ("filtered", "drained", "no_step"):
                # No more steps in this phase (or continuation drained).
                break

            phase_steps += 1
            if result.outcome == "complete":
                phase_complete += 1
                if not STATE.json_out:
                    done, total = result.progress
                    vram_suffix = ""
                    if result.vram_before_mb is not None and result.vram_peak_mb is not None:
                        delta = result.vram_peak_mb - result.vram_before_mb
                        sign = "+" if delta >= 0 else ""
                        vram_suffix = (
                            f" · vram={result.vram_before_mb}→{result.vram_peak_mb}MB "
                            f"Δ{sign}{delta}"
                        )
                    _print(
                        f"  [green]✓ step {result.step_id}[/green] "
                        f"({result.step_kind}) · {done}/{total} · "
                        f"iter={result.iterations} tokens={result.tokens}{vram_suffix}"
                    )
            else:
                phase_poison += 1
                if not STATE.json_out:
                    _print(
                        f"  [red]✗ step {result.step_id}[/red] "
                        f"({result.step_kind}) · {result.outcome}"
                    )

            time.sleep(cooldown)

        phase_elapsed = time.monotonic() - phase_start
        phase_results.append({
            "model": model,
            "steps_attempted": phase_steps,
            "complete": phase_complete,
            "poison": phase_poison,
            "elapsed_seconds": round(phase_elapsed, 1),
        })

        if not STATE.json_out:
            _print(
                f"[dim]phase {phase_idx} done · {phase_complete} complete, "
                f"{phase_poison} poison, {phase_elapsed:.1f}s[/dim]"
            )

    overall_elapsed = time.monotonic() - overall_start
    final = store.get(task_id)
    done, total = final.progress

    if STATE.json_out:
        _emit_json({
            "ok": True, "task_id": task_id,
            "phases": phase_results, "final_status": final.status,
            "progress": [done, total],
            "elapsed_seconds": round(overall_elapsed, 1),
        })
    else:
        _print(Panel(
            f"final status: [bold]{final.status}[/bold]\n"
            f"progress: {done}/{total}\n"
            f"total elapsed: {overall_elapsed:.1f}s",
            title="◈ drain-by-model · complete",
            border_style="green" if final.status == "done" else "yellow",
        ))


cont_app = typer.Typer(help="◈ inspect / manage continuation files")
app.add_typer(cont_app, name="continuations")


@cont_app.command("list")
def cont_list(status: str | None = typer.Option(None, "--status")) -> None:
    """List all continuation files with progress."""
    from .continuation import ContinuationStore

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    conts = store.list_all(status=status)

    if STATE.json_out:
        _emit_json({"continuations": [
            {"task_id": c.task_id, "status": c.status, "planner": c.planner,
             "goal": c.goal, "progress": list(c.progress),
             "updated_at": c.updated_at, "output_path": c.output_path}
            for c in conts
        ]})
        return

    if not conts:
        _print("[dim](no continuations)[/dim]")
        return

    table = Table(title="◈ continuations")
    table.add_column("task_id", style="cyan")
    table.add_column("status")
    table.add_column("planner", style="magenta")
    table.add_column("progress", justify="right")
    table.add_column("goal", overflow="fold")
    for c in conts:
        done, total = c.progress
        color = {"planned": "yellow", "in_progress": "cyan", "done": "green",
                 "poisoned": "red", "halted": "red"}.get(c.status, "white")
        table.add_row(c.task_id, f"[{color}]{c.status}[/{color}]",
                     c.planner, f"{done}/{total}", c.goal[:80])
    _print(table)


@cont_app.command("show")
def cont_show(task_id: str) -> None:
    """Show a continuation in detail, including all steps."""
    from .continuation import ContinuationNotFound, ContinuationStore

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    try:
        cont = store.get(task_id)
    except ContinuationNotFound:
        _die(ExitCode.USAGE, f"continuation not found: {task_id}")

    if STATE.json_out:
        from dataclasses import asdict
        _emit_json({
            "task_id": cont.task_id, "goal": cont.goal,
            "planner": cont.planner, "planner_args": cont.planner_args,
            "status": cont.status, "progress": list(cont.progress),
            "output_path": cont.output_path, "notes": cont.notes,
            "created_at": cont.created_at, "updated_at": cont.updated_at,
            "steps": [asdict(s) for s in cont.steps],
        })
        return

    done, total = cont.progress
    by_model = cont.progress_by_model()
    elapsed_by_model = cont.elapsed_by_model()
    progress_lines = [f"status: {cont.status} · progress: {done}/{total}"]
    if len(by_model) > 1:
        per = "  ".join(f"{m}={d}/{t}" for m, (d, t) in sorted(by_model.items()))
        progress_lines.append(f"by model: {per}")
    if cont.total_elapsed_seconds > 0:
        from .continuation import format_elapsed
        progress_lines.append(f"total elapsed: {format_elapsed(cont.total_elapsed_seconds)}")
        if len(elapsed_by_model) > 1:
            per_elapsed = "  ".join(
                f"{m}={format_elapsed(s)}"
                for m, s in sorted(elapsed_by_model.items())
            )
            progress_lines.append(f"elapsed by model: {per_elapsed}")
    _print(Panel(
        f"[bold]{cont.goal}[/bold]\n"
        f"planner: {cont.planner}\n"
        + "\n".join(progress_lines) + "\n"
        f"output: {cont.output_path or '(none)'}\n"
        f"created: {cont.created_at}\n"
        f"updated: {cont.updated_at}",
        title=f"◈ {cont.task_id}", border_style="cyan",
    ))

    from .continuation import format_elapsed as _fmt_elapsed
    table = Table(title="steps", show_header=True)
    table.add_column("id", style="dim", width=4)
    table.add_column("kind", style="magenta")
    table.add_column("model", style="cyan")
    table.add_column("status")
    table.add_column("iter", justify="right")
    table.add_column("tokens", justify="right")
    table.add_column("elapsed", justify="right")
    table.add_column("args", overflow="fold")
    for s in cont.steps:
        color = {"pending": "yellow", "done": "green",
                 "poisoned": "red", "skipped": "dim"}.get(s.status, "white")
        table.add_row(str(s.id), s.kind, s.required_model,
                     f"[{color}]{s.status}[/{color}]",
                     str(s.iterations), str(s.tokens),
                     _fmt_elapsed(s.elapsed_seconds),
                     json.dumps(s.args, default=str)[:80])
    _print(table)


@cont_app.command("delete")
def cont_delete(task_id: str) -> None:
    """Delete a continuation. Refuses if a runner holds the lock."""
    from .continuation import ContinuationLocked, ContinuationStore

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    try:
        existed = store.delete(task_id)
    except ContinuationLocked:
        _die(ExitCode.LOCKED, f"continuation {task_id} is locked by a runner")

    if STATE.json_out:
        _emit_json({"ok": existed, "task_id": task_id, "deleted": existed})
    elif existed:
        _print(f"[green]deleted[/green] {task_id}")
    else:
        _print(f"[yellow]not found[/yellow] {task_id}")


# ═══════════════════════════════════════════════════════════════════════════
#  BACKLOG
# ═══════════════════════════════════════════════════════════════════════════


backlog_app = typer.Typer(help="◈ manage the task backlog")
app.add_typer(backlog_app, name="backlog")


@backlog_app.command("list")
def backlog_list(status: str | None = typer.Option(None, "--status")) -> None:
    """Show the current backlog."""
    from .mode_controller import read_backlog

    tasks = read_backlog()
    if status:
        tasks = [t for t in tasks if t.status == status]

    if STATE.json_out:
        _emit_json({"tasks": [
            {"id": t.id, "priority": t.priority, "mode": t.mode,
             "status": t.status, "goal": t.goal, "notes": t.notes}
            for t in tasks
        ]})
        return

    if not tasks:
        _print("[dim](backlog empty)[/dim]")
        return

    table = Table(title="◈ backlog")
    table.add_column("id", style="cyan")
    table.add_column("priority", style="magenta")
    table.add_column("mode")
    table.add_column("status")
    table.add_column("goal", overflow="fold")
    for t in tasks:
        status_color = {"pending": "yellow", "running": "cyan", "done": "green",
                       "poison": "red", "budget": "yellow", "halted": "red"}.get(t.status, "white")
        table.add_row(t.id[:18], t.priority, t.mode,
                     f"[{status_color}]{t.status}[/{status_color}]", t.goal[:80])
    _print(table)


@backlog_app.command("add")
def backlog_add(
    goal: str = typer.Argument(...),
    priority: str = typer.Option("medium", "--priority"),
    mode: str = typer.Option("oneshot", "--mode"),
) -> None:
    """Add a task to the backlog."""
    from .mode_controller import add_task
    task = add_task(goal=goal, priority=priority, mode=mode)
    if STATE.json_out:
        _emit_json({"ok": True, "id": task.id})
    else:
        _print(f"[green]added[/green] {task.id}")


@backlog_app.command("remove")
def backlog_remove(task_id: str) -> None:
    """Remove a task from the backlog by id."""
    from .mode_controller import remove_task
    if remove_task(task_id):
        if STATE.json_out:
            _emit_json({"ok": True, "id": task_id})
        else:
            _print(f"[green]removed[/green] {task_id}")
    else:
        if STATE.json_out:
            _emit_json({"ok": False, "id": task_id})
        else:
            _print(f"[yellow]not found[/yellow] {task_id}")


@backlog_app.command("show")
def backlog_show(task_id: str) -> None:
    """Show one task in detail."""
    from .mode_controller import read_backlog
    task = next((t for t in read_backlog() if t.id == task_id or t.id.startswith(task_id)), None)
    if task is None:
        _die(ExitCode.USAGE, f"task not found: {task_id}")

    if STATE.json_out:
        _emit_json({"id": task.id, "goal": task.goal, "priority": task.priority,
                   "mode": task.mode, "status": task.status, "notes": task.notes})
        return

    _print(Panel(
        f"[bold]{task.goal}[/bold]\n"
        f"id: {task.id}\n"
        f"priority: {task.priority}\n"
        f"mode: {task.mode}\n"
        f"status: {task.status}\n"
        f"notes: {task.notes or '(none)'}",
        title=f"◈ {task.id[:18]}",
    ))


@backlog_app.command("requeue")
def backlog_requeue(task_id: str) -> None:
    """Reset a task to 'pending' so it'll be picked up again."""
    from .mode_controller import read_backlog, write_backlog
    tasks = read_backlog()
    target = next((t for t in tasks if t.id == task_id), None)
    if target is None:
        _die(ExitCode.USAGE, f"task not found: {task_id}")
    target.status = "pending"
    target.notes = "requeued by operator"
    write_backlog(tasks)
    if STATE.json_out:
        _emit_json({"ok": True, "id": task_id})
    else:
        _print(f"[green]requeued[/green] {task_id}")


@backlog_app.command("priority")
def backlog_priority(
    task_id: str,
    priority: str = typer.Argument(..., help="critical | high | medium | low"),
) -> None:
    """Change a task's priority."""
    valid = {"critical", "high", "medium", "low"}
    if priority not in valid:
        _die(ExitCode.USAGE, f"priority must be one of {sorted(valid)}")

    from .mode_controller import read_backlog, write_backlog
    tasks = read_backlog()
    target = next((t for t in tasks if t.id == task_id), None)
    if target is None:
        _die(ExitCode.USAGE, f"task not found: {task_id}")
    target.priority = priority
    write_backlog(tasks)
    if STATE.json_out:
        _emit_json({"ok": True, "id": task_id, "priority": priority})
    else:
        _print(f"[green]priority={priority}[/green] {task_id}")


@backlog_app.command("clear")
def backlog_clear(
    status: str = typer.Option(..., "--status", help="Clear tasks with this status."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Remove all tasks with the given status."""
    from .mode_controller import read_backlog, write_backlog

    tasks = read_backlog()
    keep = [t for t in tasks if t.status != status]
    removed = len(tasks) - len(keep)
    if removed == 0:
        _print(f"[dim]no tasks with status={status!r}[/dim]")
        return
    if not yes and not STATE.json_out:
        if not typer.confirm(f"Remove {removed} task(s) with status={status!r}?"):
            _print("[dim]cancelled[/dim]")
            return
    write_backlog(keep)
    if STATE.json_out:
        _emit_json({"ok": True, "removed": removed, "status": status})
    else:
        _print(f"[green]cleared[/green] {removed} task(s) with status={status!r}")


# ═══════════════════════════════════════════════════════════════════════════
#  APPROVALS
# ═══════════════════════════════════════════════════════════════════════════


def _parse_expiry(expiry_ts: str) -> datetime | None:
    """RFC3339-ish expiry parser. Tolerates whole-second AND fractional forms.

    The v0.2.4 implementation hard-coded ``%Y-%m-%dT%H:%M:%S.%f%z`` which
    silently fails on whole-second timestamps. Falls back to fromisoformat
    which Python 3.11 accepts both forms of.
    """
    if not expiry_ts:
        return None
    s = expiry_ts.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def _scan_pending_approval_requests() -> list[dict]:
    """Find approval-needed-d events that haven't been resolved."""
    from .events import init_events_db, tail_to_sqlite

    conn = init_events_db()
    tail_to_sqlite(conn)
    rows = conn.execute(
        "SELECT event_id, ts, payload FROM events "
        "WHERE flag = 'approval-needed-d' ORDER BY ts ASC"
    ).fetchall()

    pending: list[dict] = []
    for ev_id, ts, payload_json in rows:
        try:
            payload = json.loads(payload_json)
        except json.JSONDecodeError:
            continue

        resolved = conn.execute(
            "SELECT 1 FROM events "
            "WHERE flag IN ('approval-d', 'approval-x', 'approval-denied-d') "
            "AND json_extract(payload, '$.event_id') = ? LIMIT 1",
            (ev_id,),
        ).fetchone()
        if resolved:
            continue

        expiry = _parse_expiry(payload.get("expiry_ts", ""))
        if expiry and datetime.now(timezone.utc) >= expiry:
            continue

        pending.append({
            "event_id": ev_id, "requested_at": ts,
            "tool_name": payload.get("tool_name"),
            "args_hash": payload.get("args_hash"),
            "args_preview": payload.get("args_preview"),
            "justification": payload.get("justification"),
            "expiry_ts": payload.get("expiry_ts"),
            "expiry_dt": expiry,
        })

    conn.close()
    return pending


def _format_ttl(expiry: datetime | None) -> str:
    if expiry is None:
        return "(unknown)"
    delta = expiry - datetime.now(timezone.utc)
    secs = int(delta.total_seconds())
    if secs <= 0:
        return "expired"
    if secs < 60:
        return f"{secs}s"
    if secs < 3600:
        return f"{secs // 60}m {secs % 60}s"
    return f"{secs // 3600}h {(secs % 3600) // 60}m"


@app.command()
def approvals() -> None:
    """List pending Tier 3 approval requests."""
    pending = _scan_pending_approval_requests()

    if STATE.json_out:
        _emit_json({"pending": [
            {**{k: v for k, v in p.items() if k != "expiry_dt"},
             "ttl": _format_ttl(p.get("expiry_dt"))}
            for p in pending
        ]})
        return

    if not pending:
        _print("[dim](no pending approvals)[/dim]")
        return

    for req in pending:
        ttl = _format_ttl(req.get("expiry_dt"))
        body = (
            f"[bold]tool:[/bold]      {req['tool_name']}\n"
            f"[bold]requested:[/bold] {req['requested_at']}\n"
            f"[bold]expires in:[/bold] {ttl}\n"
            f"[bold]args:[/bold]      {req['args_preview']}\n"
            f"[bold]reason:[/bold]    {req['justification']}\n\n"
            f"[dim]grant:  sovereign approve {req['event_id']}\n"
            f"deny:   sovereign deny {req['event_id']}[/dim]"
        )
        _print(Panel(body, title=f"◈ {req['event_id']}", border_style="yellow"))


@app.command()
def approve(
    event_id: str,
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Grant a Tier 3 approval. The agent picks it up on next dispatch."""
    pending = _scan_pending_approval_requests()
    match = next((p for p in pending if p["event_id"] == event_id), None)
    if match is None:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"not found or already resolved: {event_id}")

    if not yes and not STATE.json_out:
        body = (
            f"tool:      {match['tool_name']}\n"
            f"args:      {match['args_preview']}\n"
            f"reason:    {match['justification']}\n"
            f"expires:   {match['expiry_ts']}"
        )
        _print(Panel(body, title=f"◈ approve {event_id}?", border_style="yellow"))
        if not typer.confirm("Grant this approval?"):
            _print("[dim]cancelled[/dim]")
            raise typer.Exit(ExitCode.OK)

    from .approval import ApprovalRequest, write_grant
    req = ApprovalRequest(
        event_id=event_id, tool_name=match["tool_name"], args={},
        args_hash=match["args_hash"], justification=match["justification"] or "",
        expiry_ts=match["expiry_ts"],
    )
    write_grant(req)
    if STATE.json_out:
        _emit_json({"ok": True, "granted": event_id})
    else:
        _print(f"[green]✓ granted[/green] {event_id}")


@app.command()
def deny(event_id: str, reason: str = typer.Option("operator denied", "--reason")) -> None:
    """Refuse a Tier 3 approval."""
    from .approval import write_denial
    write_denial(event_id, trace_id="cli-deny", reason=reason)
    if STATE.json_out:
        _emit_json({"ok": True, "denied": event_id, "reason": reason})
    else:
        _print(f"[red]✗ denied[/red] {event_id}")


# ═══════════════════════════════════════════════════════════════════════════
#  SAFETY
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def halt(reason: str = typer.Option("operator", "--reason")) -> None:
    """Trip PROTOCOL-ZERO. The agent halts at the next iteration boundary."""
    protocol_zero.arm(reason)
    if STATE.json_out:
        _emit_json({"ok": True, "halted": True, "reason": reason})
    else:
        _print(Panel(
            f"[red]PROTOCOL-ZERO armed[/red]\nreason: {reason}\n\n"
            f"[dim]clear with: sovereign disarm[/dim]",
            border_style="red",
        ))


@app.command()
def disarm() -> None:
    """Clear PROTOCOL-ZERO. Manual ack required after operator review."""
    protocol_zero.disarm()
    if STATE.json_out:
        _emit_json({"ok": True, "disarmed": True})
    else:
        _print("[green]✓ disarmed[/green]")


# ═══════════════════════════════════════════════════════════════════════════
#  AUDIT
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def tail() -> None:
    """Ingest events.jsonl into the SQLite events projection."""
    conn = init_events_db()
    inserted = tail_to_sqlite(conn)
    conn.close()
    if STATE.json_out:
        _emit_json({"ok": True, "inserted": inserted})
    else:
        _print(f"[green]ingested[/green] {inserted} events")


@app.command()
def seal() -> None:
    """Compute yesterday's Merkle seal over events.jsonl."""
    from .seal import seal_yesterday
    root = seal_yesterday()
    if STATE.json_out:
        _emit_json({"ok": True, "root": root})
        return
    if root:
        _print(f"[green]✓ sealed[/green] yesterday: [cyan]{root}[/cyan]")
    else:
        _print("[dim]no events to seal[/dim]")


@app.command()
def verify(target_date: str = typer.Argument(..., help="YYYY-MM-DD")) -> None:
    """Verify a past seal still matches its events file."""
    from .seal import verify_seal
    try:
        d = date.fromisoformat(target_date)
    except ValueError:
        _die(ExitCode.USAGE, f"invalid date: {target_date}")

    matches, msg = verify_seal(d)
    if STATE.json_out:
        _emit_json({"ok": matches, "message": msg, "date": target_date})
    else:
        style = "green" if matches else "red"
        _print(f"[{style}]{msg}[/{style}]")
    raise typer.Exit(ExitCode.OK if matches else ExitCode.ERROR)


@app.command()
def events(
    n: int = typer.Option(20, "-n", help="How many recent events to show"),
    flag: str | None = typer.Option(None, "--flag", help="Filter by flag (e.g., 'tool-x')"),
    follow: bool = typer.Option(False, "--follow", "-f", help="tail -f mode (Ctrl-C to stop)"),
    interval: float = typer.Option(1.0, "--interval", help="Poll interval for --follow."),
) -> None:
    """Show recent events from the SQLite projection.

    With ``--follow``, polls for new events forever (Ctrl-C to stop).
    """
    if follow:
        _follow_events(flag=flag, interval=interval)
        return

    conn = init_events_db()
    tail_to_sqlite(conn)
    if flag:
        rows = conn.execute(
            "SELECT ts, flag, trace_id, payload FROM events "
            "WHERE flag = ? ORDER BY ts DESC LIMIT ?",
            (flag, n),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT ts, flag, trace_id, payload FROM events "
            "ORDER BY ts DESC LIMIT ?", (n,),
        ).fetchall()
    conn.close()

    if STATE.json_out:
        _emit_json({"events": [
            {"ts": ts, "flag": fl, "trace_id": tid, "payload": pl}
            for ts, fl, tid, pl in rows
        ]})
        return

    table = Table(title="◈ recent events" + (f" (flag={flag})" if flag else ""))
    table.add_column("ts", style="dim")
    table.add_column("flag", style="cyan")
    table.add_column("trace", style="dim")
    table.add_column("payload", overflow="fold")
    for ts, fl, tid, pl in rows:
        table.add_row(ts.split("T")[1][:12], fl, tid[:8], pl[:80])
    _print(table)


def _follow_events(*, flag: str | None, interval: float) -> None:
    """tail -f over the events table."""
    conn = init_events_db()
    tail_to_sqlite(conn)
    last_ts = ""
    row = conn.execute("SELECT MAX(ts) FROM events").fetchone()
    if row and row[0]:
        last_ts = row[0]
    if not STATE.json_out:
        _print(f"[dim]following events (interval={interval}s, Ctrl-C to stop)…[/dim]")
    try:
        while True:
            tail_to_sqlite(conn)
            if flag:
                rows = conn.execute(
                    "SELECT ts, flag, trace_id, payload FROM events "
                    "WHERE flag = ? AND ts > ? ORDER BY ts ASC LIMIT 100",
                    (flag, last_ts),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT ts, flag, trace_id, payload FROM events "
                    "WHERE ts > ? ORDER BY ts ASC LIMIT 100", (last_ts,),
                ).fetchall()
            for ts, fl, tid, pl in rows:
                if STATE.json_out:
                    _emit_json({"ts": ts, "flag": fl, "trace_id": tid, "payload": pl})
                else:
                    _print(f"[dim]{ts.split('T')[1][:12]}[/dim] [cyan]{fl}[/cyan] {tid[:8]} {pl[:120]}")
                last_ts = ts
            time.sleep(interval)
    except KeyboardInterrupt:
        if not STATE.json_out:
            _print("\n[dim]stopped[/dim]")
    finally:
        conn.close()


@app.command()
def lessons(n: int = typer.Option(10, "-n")) -> None:
    """Show recent distilled lessons from the Reflector."""
    from .db import open_atoms_db
    conn = open_atoms_db()
    rows = conn.execute(
        "SELECT ts, trigger, rule, confidence FROM lessons "
        "ORDER BY ts DESC LIMIT ?", (n,),
    ).fetchall()
    conn.close()

    if STATE.json_out:
        _emit_json({"lessons": [
            {"ts": ts, "trigger": trigger, "rule": rule, "confidence": conf}
            for ts, trigger, rule, conf in rows
        ]})
        return

    if not rows:
        _print("[dim](no lessons yet)[/dim]")
        return

    table = Table(title="◈ lessons")
    table.add_column("when", style="dim")
    table.add_column("trigger", style="yellow")
    table.add_column("confidence", justify="right")
    table.add_column("rule")
    for ts, trigger, rule, conf in rows:
        table.add_row(ts.split("T")[0], trigger[:30], f"{conf:.2f}", rule)
    _print(table)


# ═══════════════════════════════════════════════════════════════════════════
#  PALACE — Structured layer over atoms.db (v0.2.7+)
# ═══════════════════════════════════════════════════════════════════════════


palace_app = typer.Typer(help="◈ structured memory: rooms, closets, triples")
app.add_typer(palace_app, name="palace")


@palace_app.command("stats")
def palace_stats() -> None:
    """Counts of rooms, closets, entities, triples in the palace."""
    from .palace import open_palace
    p = open_palace()
    try:
        stats = p.stats()
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"ok": True, **stats})
        return

    table = Table(title="◈ palace · stats", show_header=False, box=None, padding=(0, 1))
    table.add_column(style="dim")
    table.add_column(justify="right")
    for k, v in stats.items():
        table.add_row(k, str(v))
    _print(table)


@palace_app.command("rooms")
def palace_rooms() -> None:
    """List all rooms in the palace."""
    from .palace import open_palace
    p = open_palace()
    try:
        rooms = p.list_rooms()
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"rooms": [
            {"id": r.id, "name": r.name, "description": r.description,
             "created_at": r.created_at}
            for r in rooms
        ]})
        return

    if not rooms:
        _print("[dim](no rooms)[/dim]")
        return

    table = Table(title="◈ palace · rooms")
    table.add_column("id", style="cyan")
    table.add_column("name")
    table.add_column("description", overflow="fold")
    table.add_column("created", style="dim")
    for r in rooms:
        table.add_row(r.id, r.name, r.description[:60], r.created_at.split("T")[0])
    _print(table)


@palace_app.command("create-room")
def palace_create_room(
    room_id: str = typer.Argument(..., help="Stable room id, e.g. room-research"),
    name: str = typer.Argument(..., help="Human-readable name"),
    description: str = typer.Option("", "--description"),
) -> None:
    """Create a new room in the palace."""
    from .palace import open_palace
    p = open_palace()
    try:
        room = p.create_room(room_id=room_id, name=name, description=description)
    except Exception as e:  # noqa: BLE001
        p.close()
        _die(ExitCode.ERROR, f"create-room failed: {e}")
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"ok": True, "id": room.id, "name": room.name})
    else:
        _print(f"[green]created[/green] {room.id} · {room.name}")


@palace_app.command("closets")
def palace_closets(
    room_id: str | None = typer.Option(None, "--room", help="Filter by room"),
    limit: int = typer.Option(20, "-n"),
) -> None:
    """List recent closets, optionally filtered by room."""
    from .palace import open_palace
    p = open_palace()
    try:
        closets = p.list_closets(room_id=room_id)[:limit]
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"closets": [
            {"id": c.id, "room_id": c.room_id, "topic": c.topic,
             "entities": c.entities, "atom_ids": c.atom_ids,
             "source_file": c.source_file, "created_at": c.created_at}
            for c in closets
        ]})
        return

    if not closets:
        _print("[dim](no closets)[/dim]")
        return

    table = Table(title=f"◈ palace · closets" + (f" ({room_id})" if room_id else ""))
    table.add_column("id", style="cyan", overflow="ellipsis", max_width=24)
    table.add_column("topic", overflow="fold")
    table.add_column("entities", style="magenta", overflow="fold")
    table.add_column("atoms", justify="right")
    table.add_column("source", style="dim", overflow="ellipsis", max_width=30)
    for c in closets:
        table.add_row(
            c.id, c.topic[:80],
            "; ".join(c.entities[:3]) + ("…" if len(c.entities) > 3 else ""),
            str(len(c.atom_ids)),
            c.source_file or "",
        )
    _print(table)


@palace_app.command("search")
def palace_search(
    query: str = typer.Argument(..., help="Substring search over closet topics + entities"),
    room_id: str | None = typer.Option(None, "--room"),
    limit: int = typer.Option(10, "-n"),
) -> None:
    """Keyword search over the closet index. v0.2.7 first cut.

    For semantic search, use ``sovereign palace search-semantic`` (requires
    embed_query tool). Hybrid BM25+cosine is roadmap for v0.2.8.
    """
    from .palace import open_palace
    p = open_palace()
    try:
        results = p.search_closets_keyword(query, limit=limit, room_id=room_id)
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"results": [
            {"id": c.id, "topic": c.topic, "entities": c.entities,
             "atom_ids": c.atom_ids, "room_id": c.room_id}
            for c in results
        ]})
        return

    if not results:
        _print(f"[dim](no closets matched {query!r})[/dim]")
        return

    table = Table(title=f"◈ palace · search · {query!r}")
    table.add_column("id", style="cyan", overflow="ellipsis", max_width=20)
    table.add_column("topic", overflow="fold")
    table.add_column("entities", style="magenta")
    table.add_column("atoms", justify="right")
    for c in results:
        table.add_row(c.id, c.topic[:80], "; ".join(c.entities[:3]), str(len(c.atom_ids)))
    _print(table)


@palace_app.command("subject")
def palace_subject(
    entity_id: str = typer.Argument(..., help="Entity id to query"),
    as_of: str | None = typer.Option(None, "--as-of",
        help="Point-in-time filter (RFC3339 / ISO date)"),
) -> None:
    """Show all triples about this subject. Optional point-in-time filter."""
    from .palace import open_palace
    p = open_palace()
    try:
        triples = p.query_subject(entity_id, as_of=as_of)
        ent = p.get_entity(entity_id)
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({
            "entity": {
                "id": ent.id, "name": ent.name, "type": ent.type,
            } if ent else None,
            "triples": [
                {"id": t.id, "subject": t.subject_id,
                 "predicate": t.predicate, "object_id": t.object_id,
                 "object_literal": t.object_literal,
                 "valid_from": t.valid_from, "valid_to": t.valid_to,
                 "confidence": t.confidence}
                for t in triples
            ],
        })
        return

    if ent:
        _print(Panel(
            f"[bold]{ent.name}[/bold]  ({ent.type})\n"
            f"id: {ent.id}\n"
            f"first seen: {ent.first_seen.split('T')[0]}\n"
            f"last seen:  {ent.last_seen.split('T')[0]}",
            title="◈ entity", border_style="cyan",
        ))

    if not triples:
        _print(f"[dim](no triples for {entity_id})[/dim]")
        return

    table = Table(title=f"◈ triples about {entity_id}")
    table.add_column("predicate", style="magenta")
    table.add_column("object")
    table.add_column("from", style="dim")
    table.add_column("to", style="dim")
    table.add_column("conf", justify="right")
    for t in triples:
        obj = t.object_id or t.object_literal or "?"
        table.add_row(
            t.predicate, obj[:40],
            (t.valid_from or "—").split("T")[0],
            (t.valid_to or "—").split("T")[0],
            f"{t.confidence:.2f}",
        )
    _print(table)


# ═══════════════════════════════════════════════════════════════════════════
#  PALACE UNDERSTANDING + PROPOSALS — Self-reflection loop (v0.2.9+)
# ═══════════════════════════════════════════════════════════════════════════


@palace_app.command("understanding")
def palace_understanding(
    output: Path | None = typer.Option(
        None, "--output", help="Write markdown report to this file."
    ),
) -> None:
    """Scan the palace, print or write a structured understanding report.

    Read-only. No mutations. Used to drive palace-reflect and palace-clean.
    """
    from .palace import open_palace
    from .palace_scan import (
        render_understanding_markdown,
        scan_palace,
        understanding_to_dict,
    )

    p = open_palace()
    try:
        understanding = scan_palace(p)
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"ok": True, "understanding": understanding_to_dict(understanding)})
        return

    md = render_understanding_markdown(understanding)
    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(md, encoding="utf-8")
        _print(f"[green]wrote[/green] {output}")
    else:
        _print(md)


@palace_app.command("lineage")
def palace_lineage(
    target_id: str = typer.Argument(..., help="atom_id (forward) or closet_id (reverse)"),
    reverse: bool = typer.Option(
        False, "--reverse", "-r",
        help="Walk back from a closet to its source atoms + files. Default: forward from atom.",
    ),
    output: Path | None = typer.Option(
        None, "--output",
        help="Write markdown report to this file. Default: print to stdout.",
    ),
) -> None:
    """Walk the lineage chain for an atom or closet. Read-only.

    Forward (default): atom → parents, closets, triples, child atoms.
    Reverse (--reverse): closet → contributing atoms → source files.

    Use this to trace where any piece of structured memory came from. The
    chain is built from the breadcrumbs already stored in the system —
    atom.parents, closet.atom_ids, triple.source_atom_ids, etc.

    v0.2.11+
    """
    from .lineage import (
        lineage_forward, lineage_reverse, lineage_to_dict,
        render_forward_markdown, render_reverse_markdown,
    )

    if reverse:
        result = lineage_reverse(target_id)
        if result.closet is None:
            _die(ExitCode.APPROVAL_NOT_FOUND, f"closet not found: {target_id}")
        md = render_reverse_markdown(result)
    else:
        result = lineage_forward(target_id)
        if result.atom is None:
            _die(ExitCode.APPROVAL_NOT_FOUND,
                 f"atom not found: {target_id}\n"
                 f"  Hint: did you mean --reverse for a closet_id?")
        md = render_forward_markdown(result)

    if STATE.json_out:
        _emit_json({"ok": True, "lineage": lineage_to_dict(result)})
        return

    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(md, encoding="utf-8")
        _print(f"[green]wrote[/green] {output}")
    else:
        _print(md)


proposals_app = typer.Typer(help="◈ self-reflection proposals (v0.2.9)")
app.add_typer(proposals_app, name="proposals")


@proposals_app.command("list")
def proposals_list(
    status: str | None = typer.Option(None, "--status",
        help="Filter: pending / approved / rejected / applied / failed"),
    kind: str | None = typer.Option(None, "--kind",
        help="Filter: clean / reorganize / insight / enhancement"),
) -> None:
    """List proposals, optionally filtered by status or kind."""
    from .proposals import open_store

    store = open_store()
    items = store.list_all(status=status, kind=kind)

    if STATE.json_out:
        _emit_json({"proposals": [
            {"id": p.id, "kind": p.kind, "title": p.title,
             "status": p.status, "source": p.source,
             "created_at": p.created_at,
             "approved_at": p.approved_at,
             "applied_at": p.applied_at}
            for p in items
        ]})
        return

    if not items:
        suffix = ""
        if status:
            suffix = f" with status={status}"
        if kind:
            suffix += f" kind={kind}"
        _print(f"[dim](no proposals{suffix})[/dim]")
        return

    table = Table(title="◈ proposals")
    table.add_column("id", style="cyan", overflow="ellipsis", max_width=24)
    table.add_column("kind", style="magenta")
    table.add_column("status")
    table.add_column("title", overflow="fold")
    table.add_column("created", style="dim")
    for p in items:
        color = {"pending": "yellow", "approved": "green",
                 "rejected": "dim", "applied": "blue", "failed": "red"}.get(p.status, "white")
        table.add_row(p.id, p.kind, f"[{color}]{p.status}[/{color}]",
                     p.title[:60], p.created_at.split("T")[0])
    _print(table)


@proposals_app.command("show")
def proposals_show(
    proposal_id: str = typer.Argument(..., help="Proposal id"),
) -> None:
    """Show full detail for one proposal."""
    from .proposals import ProposalNotFound, open_store

    store = open_store()
    try:
        p = store.get(proposal_id)
    except ProposalNotFound:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"proposal not found: {proposal_id}")

    if STATE.json_out:
        from dataclasses import asdict
        _emit_json({"proposal": asdict(p)})
        return

    _print(Panel(
        f"[bold]{p.title}[/bold]\n"
        f"id: {p.id}\n"
        f"kind: {p.kind} · status: {p.status}\n"
        f"source: {p.source}\n"
        f"created: {p.created_at}\n"
        + (f"approved: {p.approved_at} by {p.approved_by}\n" if p.approved_at else "")
        + (f"applied: {p.applied_at}\n" if p.applied_at else "")
        + f"\n[bold]rationale:[/bold]\n{p.rationale or '(none)'}\n"
        + f"\n[bold]action:[/bold]\n{json.dumps(p.action, indent=2)}\n"
        + (f"\n[bold]notes:[/bold]\n{p.notes}\n" if p.notes else "")
        + (f"\n[bold]result:[/bold]\n{p.result}\n" if p.result else "")
        + (f"\n[bold]rollback:[/bold]\n{json.dumps(p.rollback, indent=2)}\n"
           if p.rollback else ""),
        title=f"◈ proposal {p.id}", border_style="cyan",
    ))


@proposals_app.command("approve")
def proposals_approve(
    proposal_id: str = typer.Argument(..., help="Proposal id to approve"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Approve a proposal so palace-apply can execute it."""
    from .approval import _load_or_create_secret
    from .proposals import (
        ProposalNotApprovable, ProposalNotFound, open_store,
    )

    store = open_store()
    try:
        p = store.get(proposal_id)
    except ProposalNotFound:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"proposal not found: {proposal_id}")

    if not yes:
        _print(Panel(
            f"[bold]{p.title}[/bold]\n"
            f"kind: {p.kind}\n\n"
            f"[bold]rationale:[/bold] {p.rationale}\n\n"
            f"[bold]action:[/bold]\n{json.dumps(p.action, indent=2)}",
            title="◈ approve proposal?", border_style="yellow",
        ))
        if not typer.confirm("Approve this proposal?"):
            _print("[dim]aborted[/dim]")
            raise typer.Exit(ExitCode.OK)

    secret = _load_or_create_secret()
    try:
        approved = store.approve(proposal_id, secret=secret)
    except ProposalNotApprovable as e:
        _die(ExitCode.APPROVAL_NOT_FOUND, str(e))

    if STATE.json_out:
        _emit_json({"ok": True, "id": approved.id, "status": approved.status})
    else:
        _print(f"[green]approved[/green] {approved.id}")
        _print(f"  apply with: [bold]sovereign plan palace-apply[/bold]")


@proposals_app.command("reject")
def proposals_reject(
    proposal_id: str = typer.Argument(..., help="Proposal id to reject"),
    reason: str = typer.Option("operator rejected", "--reason"),
) -> None:
    """Reject a proposal. Cannot be undone."""
    from .proposals import (
        ProposalNotApprovable, ProposalNotFound, open_store,
    )

    store = open_store()
    try:
        p = store.reject(proposal_id, reason=reason)
    except ProposalNotFound:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"proposal not found: {proposal_id}")
    except ProposalNotApprovable as e:
        _die(ExitCode.APPROVAL_NOT_FOUND, str(e))

    if STATE.json_out:
        _emit_json({"ok": True, "id": p.id, "status": p.status})
    else:
        _print(f"[dim]rejected[/dim] {p.id} ({reason})")


impact_app = typer.Typer(help="◈ multi-scale impact measurement (MSIMS, v0.2.10)")
app.add_typer(impact_app, name="impact")


@impact_app.command("score")
def impact_score_cmd(
    action_label: str = typer.Argument(..., help="One-line summary of the action."),
    description: str = typer.Option("", "--description", "-d",
        help="Longer description for the model to score against."),
    context: str = typer.Option("", "--context", "-c",
        help="Additional context (atoms it'll affect, who's involved, etc.)."),
    drive: bool = typer.Option(True, "--drive/--no-drive",
        help="Plan + drive the continuation in one shot (default: yes)."),
) -> None:
    """Score a 3×4 Impact Vector for an action. Stores as a Knowledge Atom.

    Convenience wrapper around `sov plan impact-score` + drive loop. The
    model emits a 3×4 matrix with confidence per cell, written as an atom
    in atoms.db. Operator reviews via `sov impact show <atom-id>`.

    The scoring is JUDGMENT, not measurement. Confidence is surfaced
    prominently. The IV is information for the operator — the system
    never auto-rejects based on it.
    """
    from .planners import REGISTRY
    planner = REGISTRY["impact-score"]

    args = {
        "action_label": action_label,
        "action_description": description or action_label,
        "context": context,
    }
    try:
        plan_result = planner.plan(**args)
    except Exception as e:  # noqa: BLE001
        _die(ExitCode.USAGE, f"plan failed: {e}")

    # Persist the continuation
    from .continuation import Continuation, ContinuationStore
    from ulid import ULID
    task_id = f"cont-{ULID()}"
    cont = Continuation(
        task_id=task_id, planner=planner.name, planner_args=args,
        steps=plan_result.steps, output_path=plan_result.output_path,
        notes=plan_result.notes, goal=plan_result.goal,
    )
    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    store.put(cont)

    if STATE.json_out:
        _emit_json({
            "ok": True, "task_id": task_id,
            "step_count": len(plan_result.steps),
            "drove": drive,
        })
        if not drive:
            return
    else:
        _print(f"◈ planned · {task_id} · {len(plan_result.steps)} step(s)")
        if not drive:
            _print(f"  drive with: sov continue {task_id}")
            return

    # Drive
    from .continue_runner import run_one_step
    while True:
        try:
            result = run_one_step(task_id)
        except Exception as e:  # noqa: BLE001
            _die(ExitCode.GENERIC, f"continue failed: {e}")
        if result.outcome == "drained":
            break
        if result.outcome == "halted":
            _die(ExitCode.HALTED, "PROTOCOL-ZERO armed")
        # complete or poison: keep going

    # Find the resulting atom_id by scanning the events log for the impact_score tool result
    # Simplest: read the continuation's last event log entry — but the tool result
    # lands in events.jsonl. For now, point the operator at recent atoms.
    if STATE.json_out:
        _emit_json({"ok": True, "task_id": task_id, "drained": True,
                    "next": "find atom_id via `sov memory_search 'impact'` or check recent events"})
    else:
        _print(f"[green]done[/green] · IV emitted as atom (type=decision)")
        _print(f"  find it: `sov events --flag tool-d -n 5` then `sov impact show <atom-id>`")


@impact_app.command("show")
def impact_show_cmd(
    atom_id: str = typer.Argument(..., help="atom_id of an Impact Vector atom"),
) -> None:
    """Render an Impact Vector atom as a 3×4 matrix with confidence per cell."""
    from .impact import ImpactVector, render_iv_matrix_dict, render_iv_matrix_text
    from .db import open_atoms_db
    import json as _json

    conn = open_atoms_db()
    try:
        row = conn.execute(
            "SELECT atom_id, type, summary, content_ref, claims FROM atoms "
            "WHERE atom_id = ?",
            (atom_id,),
        ).fetchone()
    finally:
        conn.close()
    if row is None:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"atom not found: {atom_id}")
    atom_id_, atype, summary, content_ref_json, claims_json = row[0], row[1], row[2], row[3], row[4]
    if atype != "decision":
        _print(f"[yellow]warning:[/yellow] atom is type={atype!r}, expected 'decision' for IVs")

    try:
        content_ref = _json.loads(content_ref_json) if content_ref_json else {}
        claims = _json.loads(claims_json) if claims_json else []
    except _json.JSONDecodeError as e:
        _die(ExitCode.GENERIC, f"corrupt atom: {e}")

    # The IV metadata is stored in content_ref.data
    metadata = content_ref.get("data", {}) if isinstance(content_ref, dict) else {}
    atom_dict = {
        "summary": summary,
        "claims": claims,
        "metadata": metadata,
        "framing": metadata.get("framing", ""),
    }
    iv = ImpactVector.from_atom_dict(atom_dict)

    if STATE.json_out:
        _emit_json({"atom_id": atom_id_, "iv": render_iv_matrix_dict(iv)})
    else:
        _print(render_iv_matrix_text(iv))


@proposals_app.command("delete")
def proposals_delete(
    proposal_id: str = typer.Argument(..., help="Proposal id to delete"),
    yes: bool = typer.Option(False, "--yes", "-y"),
) -> None:
    """Hard-delete a proposal. Use sparingly; reject preserves audit better."""
    from .proposals import open_store
    if not yes:
        if not typer.confirm(f"Hard-delete proposal {proposal_id}? (Use 'reject' to preserve audit)"):
            _print("[dim]aborted[/dim]")
            raise typer.Exit(ExitCode.OK)
    store = open_store()
    deleted = store.delete(proposal_id)
    if STATE.json_out:
        _emit_json({"ok": True, "deleted": deleted})
    else:
        if deleted:
            _print(f"[red]deleted[/red] {proposal_id}")
        else:
            _print(f"[dim]not found[/dim] {proposal_id}")


@proposals_app.command("stage")
def proposals_stage(
    proposal_id: str = typer.Argument(..., help="code_update proposal id"),
    timeout: int = typer.Option(600, "--timeout",
        help="pytest timeout in seconds"),
) -> None:
    """Stage a code_update proposal: copy proposed file → run tests → record result.

    Required for code_update proposals before they can be approved + applied.
    The proposal's action must contain {source_path, target_relpath}.

    The pipeline:
      1. Read proposal action (source_path, target_relpath)
      2. Copy source_path into <data_dir>/staging/<proposal_id>/
      3. Temporarily apply proposed file to target, run pytest, restore original
      4. Persist test_result.json in staging dir
      5. Update proposal notes with the test summary

    Operator then reviews via `sov proposals show`. If tests passed AND the
    operator is satisfied, they `sov proposals approve <id>` and the
    palace-apply pipeline picks it up. archive_and_swap will refuse if
    test_result.ok is not True.
    """
    from .code_update import (
        StagingError, run_tests_against_staging, stage_proposal,
    )
    from .proposals import (
        ProposalNotApprovable, ProposalNotFound, open_store,
    )

    store = open_store()
    try:
        p = store.get(proposal_id)
    except ProposalNotFound:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"proposal not found: {proposal_id}")

    if p.kind != "code_update":
        _die(ExitCode.USAGE,
             f"proposal {proposal_id} is kind={p.kind!r}, not 'code_update'. "
             f"Only code_update proposals can be staged.")
    if p.status != "pending":
        _die(ExitCode.USAGE,
             f"proposal {proposal_id} is in state {p.status!r}; "
             f"only pending proposals can be staged.")

    src = p.action.get("source_path")
    rel = p.action.get("target_relpath")
    if not src or not rel:
        _die(ExitCode.USAGE,
             f"proposal {proposal_id} action missing source_path or target_relpath")

    if not STATE.json_out:
        _print(f"◈ staging {proposal_id}")
        _print(f"  source: {src}")
        _print(f"  target: {rel}")
    try:
        from pathlib import Path as _Path
        stage_proposal(
            proposal_id=proposal_id,
            source_path=_Path(src),
            target_relpath=str(rel),
            data_dir=SETTINGS.paths.data_dir,
        )
    except StagingError as e:
        _die(ExitCode.GENERIC, f"stage failed: {e}")

    if not STATE.json_out:
        _print(f"  running tests (timeout {timeout}s)…")
    result = run_tests_against_staging(
        proposal_id=proposal_id,
        data_dir=SETTINGS.paths.data_dir,
        timeout=timeout,
    )

    # Append result summary to proposal notes (so `proposals show` surfaces it)
    p_again = store.get(proposal_id)
    summary_line = (
        f"STAGE {result['ran_at']}: "
        f"ok={result['ok']} "
        f"summary={result['summary']!r} "
        f"duration={result['duration_seconds']:.1f}s"
    )
    p_again.notes = (p_again.notes + "\n" if p_again.notes else "") + summary_line
    from .proposals import _atomic_write_yaml, _to_yaml_dict
    _atomic_write_yaml(store._path(proposal_id), _to_yaml_dict(p_again))

    if STATE.json_out:
        _emit_json({"ok": result["ok"], "result": result})
    else:
        if result["ok"]:
            _print(f"  [green]✓ tests passed[/green] · {result['summary']}")
            _print(f"  next: review via `sov proposals show {proposal_id}` then approve")
        else:
            _print(f"  [red]✗ tests failed[/red] · {result['summary']}")
            _print(f"  staged file is in {SETTINGS.paths.data_dir}/staging/{proposal_id}/")
            _print(f"  the swap will REFUSE while tests are failing.")
            raise typer.Exit(ExitCode.GENERIC)


@proposals_app.command("rollback")
def proposals_rollback(
    proposal_id: str = typer.Argument(..., help="Applied proposal id to roll back"),
    yes: bool = typer.Option(False, "--yes", "-y"),
) -> None:
    """Roll back an applied proposal using its recorded rollback descriptor.

    The proposal must be in status='applied' AND have a rollback descriptor
    that we know how to execute. Currently supported:
      - code_rollback: restore the archived file
      - restore_triple: re-mark a triple as valid (currently no-op; soft-delete via valid_to is its own contract)
      - restore_closet: re-add a removed closet
      - remove_closet: delete an additive closet (insights/enhancements)
    """
    from .events import emit_event
    from .proposals import (
        ProposalNotApprovable, ProposalNotFound, open_store,
    )

    store = open_store()
    try:
        p = store.get(proposal_id)
    except ProposalNotFound:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"proposal not found: {proposal_id}")

    if p.status != "applied":
        _die(ExitCode.USAGE,
             f"proposal {proposal_id} is in state {p.status!r}, "
             f"only 'applied' proposals can be rolled back.")
    if not p.rollback:
        _die(ExitCode.USAGE,
             f"proposal {proposal_id} has no rollback descriptor; "
             f"cannot be auto-rolled-back.")

    rb_type = p.rollback.get("type")

    if not yes:
        _print(Panel(
            f"[bold]{p.title}[/bold]\n"
            f"applied at: {p.applied_at}\n"
            f"rollback type: {rb_type}\n"
            f"rollback details: {json.dumps(p.rollback, indent=2)}",
            title="◈ rollback applied proposal?", border_style="yellow",
        ))
        if not typer.confirm("Proceed with rollback?"):
            _print("[dim]aborted[/dim]")
            raise typer.Exit(ExitCode.OK)

    # Dispatch on rollback type
    result_msg: str = ""
    try:
        if rb_type == "code_rollback":
            from .code_update import rollback_from_archive
            from pathlib import Path as _Path
            r = rollback_from_archive(
                archive_dir=_Path(p.rollback["archive_dir"]),
                target_relpath=p.rollback["target_relpath"],
            )
            result_msg = f"restored {r['restored_to']} from {r['from_archive']}"
        elif rb_type == "remove_closet":
            from .palace import open_palace
            palace = open_palace()
            try:
                with palace._connect() as c:
                    c.execute("DELETE FROM closets WHERE id = ?",
                              (p.rollback["closet_id"],))
            finally:
                palace.close()
            result_msg = f"removed closet {p.rollback['closet_id']}"
        elif rb_type == "restore_closet":
            from .palace import Closet, open_palace
            palace = open_palace()
            try:
                cd = p.rollback["closet"]
                palace.add_closet(Closet(
                    id=cd["id"], room_id=cd["room_id"],
                    topic=cd["topic"], entities=cd["entities"],
                    atom_ids=cd["atom_ids"],
                    embedding=cd.get("embedding"),
                    source_file=cd.get("source_file"),
                    created_at=cd.get("created_at"),
                ))
            finally:
                palace.close()
            result_msg = f"restored closet {cd['id']}"
        elif rb_type == "restore_triple":
            # Re-validate the triple (clear valid_to). Use direct SQL since
            # palace.py doesn't expose this — invalidating is the supported op,
            # and unwinding it requires this raw access for now.
            from .palace import open_palace
            palace = open_palace()
            try:
                with palace._connect() as c:
                    c.execute("UPDATE triples SET valid_to = NULL WHERE id = ?",
                              (p.rollback["triple_id"],))
            finally:
                palace.close()
            result_msg = f"re-validated triple {p.rollback['triple_id']}"
        elif rb_type == "restore_entities":
            from .palace import open_palace
            palace = open_palace()
            try:
                with palace._connect() as c:
                    # Re-insert the entities
                    for ent in p.rollback.get("entities", []):
                        c.execute(
                            "INSERT OR REPLACE INTO entities(id, name, type, "
                            "properties_json, first_seen, last_seen) "
                            "VALUES (?,?,?,?,?,?)",
                            (ent["id"], ent["name"], ent["type"],
                             ent["properties_json"], ent["first_seen"], ent["last_seen"]),
                        )
                    # Reverse the triple remaps
                    for remap in p.rollback.get("triple_remaps", []):
                        c.execute(
                            "UPDATE triples SET subject_id = ? "
                            "WHERE id = ? AND subject_id = ?",
                            (remap["to_id"], remap["triple_id"], remap["from_id"]),
                        )
                        c.execute(
                            "UPDATE triples SET object_id = ? "
                            "WHERE id = ? AND object_id = ?",
                            (remap["to_id"], remap["triple_id"], remap["from_id"]),
                        )
            finally:
                palace.close()
            result_msg = f"unmerged {len(p.rollback.get('entities', []))} entities"
        else:
            _die(ExitCode.USAGE,
                 f"unsupported rollback type: {rb_type!r}")
    except Exception as e:  # noqa: BLE001
        _die(ExitCode.GENERIC, f"rollback failed: {type(e).__name__}: {e}")

    # Audit event — proposal stays 'applied' for trail; we add a rollback note.
    p_again = store.get(proposal_id)
    p_again.notes = (p_again.notes + "\n" if p_again.notes else "") + \
                    f"ROLLED BACK {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}: {result_msg}"
    from .proposals import _atomic_write_yaml as _w, _to_yaml_dict as _d
    _w(store._path(proposal_id), _d(p_again))
    emit_event(
        "proposal-rolled-back-d",
        plane="control",
        trace_id=f"prop:{proposal_id}",
        payload={"proposal_id": proposal_id, "rollback_type": rb_type, "result": result_msg[:200]},
    )

    if STATE.json_out:
        _emit_json({"ok": True, "result": result_msg})
    else:
        _print(f"[green]rolled back[/green] · {result_msg}")


# ════════════════════════════════════════════════════════════════════════════
#  v0.2.12 — pause/resume, dream, projects, do (plain English)
# ════════════════════════════════════════════════════════════════════════════


# ─── pause / resume primitives (continuations) ──────────────────────────────


@app.command(name="pause")
def pause_cmd(
    task_id: str = typer.Argument(
        ..., help="Continuation ID (cont-... or cycle-...)"
    ),
    reason: str = typer.Option(
        "operator pause", "--reason",
        help="Free text persisted on the continuation's notes field.",
    ),
) -> None:
    """Pause a continuation. The runner refuses to advance until ``sov resume``.

    Idempotent: pausing an already-paused continuation succeeds with no change.
    Drained continuations cannot be paused (refused with USAGE exit code).

    v0.2.12+
    """
    _preflight_initialized()
    from .continuation import (
        ContinuationLocked, ContinuationNotFound, ContinuationStore,
    )
    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    try:
        with store.lock(task_id, blocking=True, timeout_seconds=5.0) as cont:
            if cont.is_drained():
                _die(ExitCode.USAGE,
                     f"continuation {task_id} is already drained "
                     f"(status={cont.status}); pause is a no-op")
            if cont.status != "paused":
                cont.status = "paused"
                cont.notes = (cont.notes + "\n" if cont.notes else "") + \
                             f"PAUSED {_utc_now_str()}: {reason}"
    except ContinuationNotFound:
        _die(ExitCode.USAGE, f"continuation not found: {task_id}")
    except ContinuationLocked:
        _die(ExitCode.LOCKED,
             f"continuation {task_id} is held by a running step; try again")

    if STATE.json_out:
        _emit_json({"ok": True, "task_id": task_id, "status": "paused"})
    else:
        _print(f"[yellow]paused[/yellow] · {task_id} (reason: {reason})")
        _print(f"[dim]resume with:[/dim] [cyan]sov resume {task_id}[/cyan]")


@app.command(name="resume")
def resume_cmd(
    task_id: str = typer.Argument(..., help="Continuation ID to resume"),
    drive: bool = typer.Option(
        False, "--drive",
        help="After resuming, drive the continuation to completion.",
    ),
) -> None:
    """Resume a paused continuation. Optionally drive it to completion.

    Without --drive: just flips status from paused → in_progress / planned and
    returns. The operator (or an existing loop driver) picks it up.

    With --drive: invokes scripts/sovereign-continue-loop.sh inline.

    v0.2.12+
    """
    _preflight_initialized()
    from .continuation import (
        ContinuationLocked, ContinuationNotFound, ContinuationStore,
    )
    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    try:
        with store.lock(task_id, blocking=True, timeout_seconds=5.0) as cont:
            if cont.is_drained():
                _die(ExitCode.USAGE,
                     f"continuation {task_id} is already drained "
                     f"(status={cont.status}); cannot resume")
            if cont.status == "paused":
                # Recompute from steps — landing on planned / in_progress / etc.
                # update_status_from_steps preserves "paused", so we clear the
                # field first and let the recompute set the right value.
                cont.status = "in_progress"
                cont.update_status_from_steps()
                cont.notes = (cont.notes + "\n" if cont.notes else "") + \
                             f"RESUMED {_utc_now_str()}"
    except ContinuationNotFound:
        _die(ExitCode.USAGE, f"continuation not found: {task_id}")
    except ContinuationLocked:
        _die(ExitCode.LOCKED,
             f"continuation {task_id} is held by a running step; try again")

    if STATE.json_out:
        _emit_json({"ok": True, "task_id": task_id, "status": "resumed",
                    "drive": drive})
    else:
        _print(f"[green]resumed[/green] · {task_id}")
        if not drive:
            _print(f"[dim]drive it:[/dim] [cyan]sov continue {task_id}[/cyan]")

    if drive:
        # Inline driver — same shape as sov-drive but starting from an
        # already-existing continuation.
        import subprocess
        scripts = Path(__file__).resolve().parent.parent.parent / "scripts" / \
                  "sovereign-continue-loop.sh"
        if scripts.exists():
            subprocess.call([str(scripts), task_id])
        else:
            _print("[yellow]warning[/yellow] no continue-loop script found; "
                   "drive manually with `sov continue`")


def _utc_now_str() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ─── dream subcommand ───────────────────────────────────────────────────────


dream_app = typer.Typer(
    help="◈ infinite trillion-dollar software builder (v0.2.12)"
)
app.add_typer(dream_app, name="dream")


@dream_app.command("start")
def dream_start(
    goal: str = typer.Argument(
        "Build trillion-dollar software cycles, ideate→build→document, "
        "until paused.",
        help="Free-text description of what the dream is for.",
    ),
    max_files: int = typer.Option(
        2000, "--max-files",
        help="Stop after this many files have been written. 0 = unbounded.",
    ),
    max_cycles: int = typer.Option(
        0, "--max-cycles",
        help="Stop after this many cycles complete. 0 = unbounded.",
    ),
    max_seconds: int = typer.Option(
        0, "--max-seconds",
        help="Stop after this many wall-clock seconds. 0 = unbounded.",
    ),
    project: list[str] = typer.Option(
        [], "--project",
        help="Register a project the dream should be aware of. Repeatable.",
    ),
    drive: bool = typer.Option(
        False, "--drive",
        help="After creating the session, drive it (loop until paused/exhausted).",
    ),
) -> None:
    """Start a new infinite trillion-dollar builder dream session.

    Each cycle does: ideate → architect → build → document → atomize.
    Cycles run until ``--max-files`` is reached, ``--max-cycles`` is
    reached, ``--max-seconds`` is reached, or you ``sov dream pause``.
    The session has a stable ID so you can resume across sessions.

    Examples:
        sov dream start                              # 2000-file default cap
        sov dream start --max-files 0 --drive        # forever, drive immediately
        sov dream start --project genesis-seeds      # tie to a tracked project

    v0.2.12+
    """
    _preflight_initialized()
    from .dream import DreamCaps, DreamStore, ProjectRef
    store = DreamStore(SETTINGS.paths.dream_sessions_dir,
                       SETTINGS.paths.dreams_work_dir)
    caps = DreamCaps(
        max_files=max_files if max_files > 0 else (0 if max_files == 0 else 2000),
        max_cycles=max_cycles if max_cycles > 0 else None,
        max_seconds=float(max_seconds) if max_seconds > 0 else None,
    )
    # Special-case: explicit --max-files 0 means unbounded → store as None
    if max_files == 0:
        caps.max_files = None

    dream = store.create(goal=goal, caps=caps)
    for proj_name in project:
        dream.projects.append(ProjectRef(name=proj_name, root=""))
    if project:
        store.save(dream)

    if STATE.json_out:
        _emit_json({"ok": True, "dream_id": dream.dream_id,
                    "work_dir": dream.work_dir,
                    "max_files": dream.caps.max_files,
                    "max_cycles": dream.caps.max_cycles,
                    "max_seconds": dream.caps.max_seconds})
    else:
        cap_line = (
            f"max_files={dream.caps.max_files or '∞'}"
            f"  max_cycles={dream.caps.max_cycles or '∞'}"
            f"  max_seconds={dream.caps.max_seconds or '∞'}"
        )
        _print(Panel(
            f"[bold]{dream.goal}[/bold]\n"
            f"dream_id: [cyan]{dream.dream_id}[/cyan]\n"
            f"work_dir: {dream.work_dir}\n"
            f"caps: {cap_line}\n\n"
            f"[dim]advance one step:[/dim] "
            f"[cyan]sov dream advance {dream.dream_id}[/cyan]\n"
            f"[dim]drive in a loop:[/dim] "
            f"[cyan]scripts/sovereign-dream-loop.sh {dream.dream_id}[/cyan]\n"
            f"[dim]pause anytime:[/dim] "
            f"[cyan]sov dream pause {dream.dream_id}[/cyan]",
            title="◈ dream session created", border_style="green",
        ))

    if drive:
        _drive_dream_inline(dream.dream_id)


@dream_app.command("advance")
def dream_advance_cmd(
    dream_id: str = typer.Argument(..., help="Dream ID (dream-...)"),
    max_iter: int = typer.Option(5, "--max-iter"),
    max_wall: int = typer.Option(120, "--max-wall"),
    max_tokens: int = typer.Option(20_000, "--max-tokens"),
) -> None:
    """Advance a dream by exactly ONE step. Exit codes match `continue`.

    The shell driver re-invokes us until status terminal.
    """
    _preflight_initialized()
    _preflight_not_halted()

    from .dream import DreamStore
    from .dream_runner import advance_dream
    store = DreamStore(SETTINGS.paths.dream_sessions_dir,
                       SETTINGS.paths.dreams_work_dir)
    try:
        dream = store.get(dream_id)
    except Exception as e:  # noqa: BLE001
        _die(ExitCode.USAGE, f"dream not found: {e}")

    # Ollama only required for non-pure-Python steps.
    # We don't know which step yet, but the cycle runner will skip Ollama
    # checks for required_model='none' steps. Be lenient at this layer.
    needs_model = (dream.status not in ("paused", "exhausted", "halted", "completed"))
    if needs_model:
        _preflight_ollama_reachable(fatal=False)

    tools = _build_tools_for_mode(Mode.ONESHOT)
    budget = RunBudget(max_iterations=max_iter, max_wall_seconds=max_wall,
                      max_tokens=max_tokens, consecutive_fail_limit=2)

    protocol_zero.install_signal_handlers()
    result = advance_dream(
        dream_id=dream_id, tools=tools, store=store,
        budget=budget, mode=Mode.ONESHOT,
    )

    payload = {
        "dream_id": result.dream_id, "dream_status": result.dream_status,
        "cycle_number": result.cycle_number,
        "step_outcome": result.step_outcome, "step_id": result.step_id,
        "step_kind": result.step_kind, "iterations": result.iterations,
        "tokens": result.tokens, "elapsed_seconds": result.elapsed_seconds,
        "files_written_total": result.files_written_total,
        "cycles_completed": result.cycles_completed,
        "reason": result.reason,
    }

    # Map dream-level outcomes to exit codes.
    if result.step_outcome in ("dream_paused", "dream_exhausted",
                                "dream_completed", "dream_halted"):
        if STATE.json_out:
            _emit_json({"ok": True, "code": ExitCode.DRAINED, **payload})
        else:
            _print(f"[green]{result.step_outcome}[/green] · "
                   f"{result.dream_status} · {result.cycles_completed} cycles · "
                   f"{result.files_written_total} files · {result.reason}")
        raise typer.Exit(ExitCode.DRAINED)

    if result.step_outcome == "locked":
        if STATE.json_out:
            _emit_json({"ok": False, "code": ExitCode.LOCKED, **payload})
        else:
            _print(f"[yellow]locked[/yellow] · cycle held by another runner")
        raise typer.Exit(ExitCode.LOCKED)

    if result.step_outcome == "paused":
        if STATE.json_out:
            _emit_json({"ok": False, "code": ExitCode.DRAINED, **payload})
        else:
            _print(f"[yellow]cycle paused[/yellow] · {result.dream_id}")
        raise typer.Exit(ExitCode.DRAINED)

    if STATE.json_out:
        ok = result.step_outcome in ("complete", "new_cycle", "drained")
        _emit_json({"ok": ok, "code": ExitCode.OK if ok else ExitCode.ERROR, **payload})
    else:
        _print(f"[cyan]✓ dream step[/cyan] · cycle={result.cycle_number} · "
               f"{result.step_kind or '(no step)'} · "
               f"outcome={result.step_outcome} · "
               f"files={result.files_written_total}")
    raise typer.Exit(
        ExitCode.OK if result.step_outcome in ("complete", "new_cycle", "drained")
        else ExitCode.ERROR
    )


@dream_app.command("list")
def dream_list_cmd(
    status_filter: str | None = typer.Option(
        None, "--status", help="Filter by status (active/paused/exhausted/...)"
    ),
) -> None:
    """List all dream sessions."""
    _preflight_initialized()
    from .dream import DreamStore
    store = DreamStore(SETTINGS.paths.dream_sessions_dir,
                       SETTINGS.paths.dreams_work_dir)
    dreams = store.list_all(status=status_filter)

    if STATE.json_out:
        _emit_json({"dreams": [
            {"dream_id": d.dream_id, "status": d.status, "goal": d.goal,
             "cycles_completed": d.cycles_completed,
             "files_written": d.files_written,
             "max_files": d.caps.max_files,
             "created_at": d.created_at, "updated_at": d.updated_at}
            for d in dreams
        ]})
        return

    if not dreams:
        _print("[dim](no dreams yet — `sov dream start` to begin)[/dim]")
        return

    table = Table(title="◈ dream sessions", show_header=True, header_style="bold cyan")
    table.add_column("dream_id", style="cyan", no_wrap=True)
    table.add_column("status")
    table.add_column("cycles", justify="right")
    table.add_column("files", justify="right")
    table.add_column("cap")
    table.add_column("goal", overflow="fold")
    for d in dreams:
        cap_str = str(d.caps.max_files) if d.caps.max_files else "∞"
        table.add_row(
            d.dream_id, d.status,
            str(d.cycles_completed), str(d.files_written),
            cap_str, d.goal[:80],
        )
    _print(table)


@dream_app.command("show")
def dream_show_cmd(dream_id: str = typer.Argument(...)) -> None:
    """Show full state for one dream session."""
    _preflight_initialized()
    from .dream import DreamStore
    store = DreamStore(SETTINGS.paths.dream_sessions_dir,
                       SETTINGS.paths.dreams_work_dir)
    try:
        d = store.get(dream_id)
    except Exception as e:  # noqa: BLE001
        _die(ExitCode.USAGE, f"dream not found: {e}")

    if STATE.json_out:
        from .dream import _to_yaml
        _emit_json({"dream": _to_yaml(d)})
        return

    cap_line = (
        f"max_files={d.caps.max_files or '∞'}  "
        f"max_cycles={d.caps.max_cycles or '∞'}  "
        f"max_seconds={d.caps.max_seconds or '∞'}"
    )
    _print(Panel(
        f"[bold]{d.goal}[/bold]\n"
        f"status: [cyan]{d.status}[/cyan]\n"
        f"created: {d.created_at}\n"
        f"updated: {d.updated_at}\n"
        f"work_dir: {d.work_dir}\n"
        f"caps: {cap_line}\n"
        f"progress: {d.progress_summary()}\n"
        f"current cycle task: {d.current_cycle_task_id or '(none)'}",
        title=f"◈ dream {d.dream_id}", border_style="cyan",
    ))
    if d.cycles:
        t = Table(title="cycles", show_header=True, header_style="bold")
        t.add_column("#", justify="right")
        t.add_column("status")
        t.add_column("files", justify="right")
        t.add_column("title", overflow="fold")
        t.add_column("task_id", style="dim")
        for c in d.cycles[-20:]:  # last 20
            t.add_row(str(c.cycle_number), c.status, str(c.files_written),
                      c.title[:60], c.task_id)
        _print(t)


@dream_app.command("pause")
def dream_pause_cmd(dream_id: str = typer.Argument(...)) -> None:
    """Pause a dream session. The advance loop returns dream_paused next call."""
    _preflight_initialized()
    from .dream import DreamStore
    store = DreamStore(SETTINGS.paths.dream_sessions_dir,
                       SETTINGS.paths.dreams_work_dir)
    try:
        d = store.get(dream_id)
    except Exception as e:  # noqa: BLE001
        _die(ExitCode.USAGE, f"dream not found: {e}")

    if d.is_terminal():
        _die(ExitCode.USAGE,
             f"dream is already {d.status}; pause is a no-op")

    d.status = "paused"
    d.notes = (d.notes + "\n" if d.notes else "") + f"PAUSED {_utc_now_str()}"
    store.save(d)

    # Also pause the underlying current cycle if any, so a parallel
    # advance call can't sneak through.
    if d.current_cycle_task_id:
        from .continuation import (
            ContinuationLocked, ContinuationNotFound, ContinuationStore,
        )
        cstore = ContinuationStore(SETTINGS.paths.continuations_dir)
        try:
            with cstore.lock(d.current_cycle_task_id, blocking=True,
                              timeout_seconds=5.0) as cont:
                if not cont.is_drained() and cont.status != "paused":
                    cont.status = "paused"
        except (ContinuationNotFound, ContinuationLocked):
            pass

    if STATE.json_out:
        _emit_json({"ok": True, "dream_id": dream_id, "status": "paused"})
    else:
        _print(f"[yellow]paused[/yellow] · dream {dream_id}")
        _print(f"[dim]resume:[/dim] [cyan]sov dream resume {dream_id}[/cyan]")


@dream_app.command("resume")
def dream_resume_cmd(
    dream_id: str = typer.Argument(...),
    drive: bool = typer.Option(False, "--drive",
                               help="Drive in a loop after resuming."),
) -> None:
    """Resume a paused dream. With --drive, run the loop until paused/exhausted."""
    _preflight_initialized()
    from .dream import DreamStore
    store = DreamStore(SETTINGS.paths.dream_sessions_dir,
                       SETTINGS.paths.dreams_work_dir)
    try:
        d = store.get(dream_id)
    except Exception as e:  # noqa: BLE001
        _die(ExitCode.USAGE, f"dream not found: {e}")

    if d.status not in ("paused",):
        _die(ExitCode.USAGE,
             f"dream is {d.status}, not paused; nothing to resume")

    d.status = "active"
    d.notes = (d.notes + "\n" if d.notes else "") + f"RESUMED {_utc_now_str()}"
    store.save(d)

    # Wake the current cycle too.
    if d.current_cycle_task_id:
        from .continuation import (
            ContinuationLocked, ContinuationNotFound, ContinuationStore,
        )
        cstore = ContinuationStore(SETTINGS.paths.continuations_dir)
        try:
            with cstore.lock(d.current_cycle_task_id, blocking=True,
                              timeout_seconds=5.0) as cont:
                if cont.status == "paused" and not cont.is_drained():
                    cont.status = "in_progress"
                    cont.update_status_from_steps()
        except (ContinuationNotFound, ContinuationLocked):
            pass

    if STATE.json_out:
        _emit_json({"ok": True, "dream_id": dream_id, "status": "resumed",
                    "drive": drive})
    else:
        _print(f"[green]resumed[/green] · dream {dream_id}")

    if drive:
        _drive_dream_inline(dream_id)


@dream_app.command("stop")
def dream_stop_cmd(
    dream_id: str = typer.Argument(...),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Mark a dream completed. Permanent. Files on disk are preserved."""
    _preflight_initialized()
    from .dream import DreamStore
    store = DreamStore(SETTINGS.paths.dream_sessions_dir,
                       SETTINGS.paths.dreams_work_dir)
    try:
        d = store.get(dream_id)
    except Exception as e:  # noqa: BLE001
        _die(ExitCode.USAGE, f"dream not found: {e}")

    if not yes and not STATE.json_out:
        confirm = typer.confirm(
            f"Stop dream {dream_id}? "
            f"({d.cycles_completed} cycles, {d.files_written} files preserved on disk.)"
        )
        if not confirm:
            raise typer.Abort()

    d.status = "completed"
    d.notes = (d.notes + "\n" if d.notes else "") + f"STOPPED {_utc_now_str()}"
    store.save(d)

    if STATE.json_out:
        _emit_json({"ok": True, "dream_id": dream_id, "status": "completed"})
    else:
        _print(f"[green]stopped[/green] · dream {dream_id} (work_dir preserved)")


def _drive_dream_inline(dream_id: str) -> None:
    """Inline driver loop: keep calling advance until terminal.

    Lighter than the shell script but does the same thing. Emits a single
    line per advance, exits cleanly when the dream is terminal.
    """
    from .dream import DreamStore
    from .dream_runner import advance_dream
    store = DreamStore(SETTINGS.paths.dream_sessions_dir,
                       SETTINGS.paths.dreams_work_dir)
    tools = _build_tools_for_mode(Mode.ONESHOT)
    budget = RunBudget(max_iterations=5, max_wall_seconds=120,
                      max_tokens=20_000, consecutive_fail_limit=2)
    protocol_zero.install_signal_handlers()

    _print(f"[cyan]◈ driving dream {dream_id} · Ctrl-C to stop[/cyan]")
    while True:
        result = advance_dream(
            dream_id=dream_id, tools=tools, store=store,
            budget=budget, mode=Mode.ONESHOT,
        )
        if result.step_outcome in ("dream_paused", "dream_exhausted",
                                    "dream_completed", "dream_halted"):
            _print(f"[green]◈ {result.step_outcome}[/green] · "
                   f"{result.cycles_completed} cycles · "
                   f"{result.files_written_total} files · {result.reason}")
            return
        if result.step_outcome == "locked":
            time.sleep(5)
            continue
        # Brief cooldown so a fast loop on poison errors doesn't cook the CPU.
        if result.step_outcome in ("poison", "budget"):
            time.sleep(2)
        if protocol_zero.is_armed():
            _print("[red]◈ HALT armed · stopping[/red]")
            return


# ─── projects subcommand ────────────────────────────────────────────────────


projects_app = typer.Typer(help="◈ named project tracking + change detection (v0.2.12)")
app.add_typer(projects_app, name="projects")


@projects_app.command("scan")
def projects_scan_cmd(
    name: str = typer.Argument(..., help="Project name (alphanum / -_.)"),
    root: Path = typer.Argument(..., help="Directory to scan"),
    exclude: list[str] = typer.Option(
        [], "--exclude",
        help="Extra glob patterns to exclude (added to defaults). Repeatable.",
    ),
    follow_symlinks: bool = typer.Option(False, "--follow-symlinks"),
    max_files: int = typer.Option(0, "--max-files",
                                  help="Cap (0=unbounded)."),
) -> None:
    """Scan a directory and save its snapshot under <name>.

    Idempotent on the file content: re-scanning an unchanged tree replaces
    the snapshot with byte-identical data. Use ``sov projects update``
    afterwards to compute diffs against the saved snapshot.

    v0.2.12+
    """
    _preflight_initialized()
    from .projects import (
        DEFAULT_EXCLUDES, ProjectError, ProjectSnapshot, ProjectStore,
        scan_directory,
    )
    store = ProjectStore(SETTINGS.paths.projects_dir)

    root_resolved = root.expanduser().resolve()
    if not root_resolved.is_dir():
        _die(ExitCode.USAGE, f"not a directory: {root_resolved}")

    excludes = list(DEFAULT_EXCLUDES) + list(exclude)
    try:
        files = scan_directory(
            root_resolved, excludes=excludes,
            follow_symlinks=follow_symlinks, max_files=max_files,
        )
    except ProjectError as e:
        _die(ExitCode.ERROR, str(e))

    snap = ProjectSnapshot(
        name=name, root=str(root_resolved),
        excludes=excludes, files=files,
    )
    store.save(snap)

    if STATE.json_out:
        _emit_json({"ok": True, "name": name,
                    "file_count": snap.file_count,
                    "total_bytes": snap.total_bytes,
                    "root": snap.root})
    else:
        _print(Panel(
            f"name: [cyan]{name}[/cyan]\n"
            f"root: {snap.root}\n"
            f"files: {snap.file_count}\n"
            f"bytes: {snap.total_bytes:,}\n"
            f"excludes: {len(excludes)} patterns",
            title="◈ project scanned", border_style="green",
        ))


@projects_app.command("list")
def projects_list_cmd() -> None:
    """List tracked projects."""
    _preflight_initialized()
    from .projects import ProjectStore
    store = ProjectStore(SETTINGS.paths.projects_dir)
    names = store.list_names()

    if STATE.json_out:
        out = []
        for n in names:
            try:
                s = store.get(n)
                out.append({"name": n, "root": s.root,
                            "file_count": s.file_count,
                            "updated_at": s.updated_at})
            except Exception:  # noqa: BLE001
                out.append({"name": n, "error": "corrupt"})
        _emit_json({"projects": out})
        return

    if not names:
        _print("[dim](no tracked projects — `sov projects scan <name> <root>`)[/dim]")
        return

    table = Table(title="◈ projects", show_header=True, header_style="bold cyan")
    table.add_column("name", style="cyan")
    table.add_column("files", justify="right")
    table.add_column("updated_at")
    table.add_column("root")
    for n in names:
        try:
            s = store.get(n)
            table.add_row(n, str(s.file_count), s.updated_at, s.root)
        except Exception:  # noqa: BLE001
            table.add_row(n, "?", "?", "(corrupt)")
    _print(table)


@projects_app.command("show")
def projects_show_cmd(name: str = typer.Argument(...)) -> None:
    """Show snapshot summary for one project."""
    _preflight_initialized()
    from .projects import ProjectNotFound, ProjectStore
    store = ProjectStore(SETTINGS.paths.projects_dir)
    try:
        s = store.get(name)
    except ProjectNotFound:
        _die(ExitCode.USAGE, f"project not found: {name}")

    if STATE.json_out:
        _emit_json({"name": s.name, "root": s.root,
                    "file_count": s.file_count, "total_bytes": s.total_bytes,
                    "created_at": s.created_at, "updated_at": s.updated_at,
                    "excludes": s.excludes,
                    "first_files": [f.path for f in s.files[:50]]})
        return

    _print(Panel(
        f"name: [cyan]{s.name}[/cyan]\n"
        f"root: {s.root}\n"
        f"files: {s.file_count}\n"
        f"bytes: {s.total_bytes:,}\n"
        f"created: {s.created_at}\n"
        f"updated: {s.updated_at}\n"
        f"excludes: {len(s.excludes)} patterns",
        title=f"◈ project {s.name}", border_style="cyan",
    ))


@projects_app.command("update")
def projects_update_cmd(
    name: str = typer.Argument(...),
    atomize: bool = typer.Option(
        True, "--atomize/--no-atomize",
        help="Write atoms to atoms.db for added/modified/removed files. (default: on)",
    ),
    keep_old: bool = typer.Option(
        False, "--keep-old",
        help="Don't overwrite the snapshot — just report the diff.",
    ),
) -> None:
    """Re-scan a tracked project and report what changed.

    By default, also writes one atom per changed file to atoms.db so the
    dream-runner / palace-mine can see the change. With ``--no-atomize``
    just the diff is reported. With ``--keep-old`` the snapshot stays at
    the prior scan (useful for dry-runs).

    v0.2.12+
    """
    _preflight_initialized()
    from .projects import (
        ProjectNotFound, ProjectSnapshot, ProjectStore,
        atomize_diff, diff_snapshots, scan_directory,
    )
    store = ProjectStore(SETTINGS.paths.projects_dir)
    try:
        old = store.get(name)
    except ProjectNotFound:
        _die(ExitCode.USAGE,
             f"project not found: {name}\n"
             f"  Hint: run `sov projects scan {name} <root>` first.")

    root = Path(old.root)
    if not root.is_dir():
        _die(ExitCode.ERROR,
             f"project root no longer a directory: {root}")

    new_files = scan_directory(
        root, excludes=list(old.excludes),
        follow_symlinks=False, max_files=0,
    )
    new = ProjectSnapshot(
        name=name, root=str(root),
        excludes=list(old.excludes), files=new_files,
        created_at=old.created_at,
    )
    diff = diff_snapshots(old, new)

    written = 0
    if atomize and not diff.is_empty:
        try:
            written = atomize_diff(name, diff, new)
        except Exception as e:  # noqa: BLE001
            _print(f"[yellow]warn[/yellow] atomize failed: {e}")
            written = 0

    if not keep_old:
        store.save(new)

    payload = {
        "name": name, "added": diff.added, "modified": diff.modified,
        "removed": diff.removed, "unchanged_count": diff.unchanged_count,
        "atoms_written": written, "kept_old": keep_old,
    }
    if STATE.json_out:
        _emit_json({"ok": True, **payload})
        return

    _print(Panel(
        f"[bold]{diff.summary()}[/bold]\n"
        f"atoms written: {written}\n"
        f"snapshot: {'preserved (--keep-old)' if keep_old else 'replaced'}",
        title=f"◈ project update · {name}",
        border_style="green" if not diff.is_empty else "dim",
    ))
    if diff.added or diff.modified or diff.removed:
        t = Table(title="changes", show_header=True)
        t.add_column("change", style="cyan")
        t.add_column("path", overflow="fold")
        for p in diff.added[:50]:
            t.add_row("added", p)
        for p in diff.modified[:50]:
            t.add_row("modified", p)
        for p in diff.removed[:50]:
            t.add_row("removed", p)
        _print(t)


@projects_app.command("delete")
def projects_delete_cmd(
    name: str = typer.Argument(...),
    yes: bool = typer.Option(False, "--yes", "-y"),
) -> None:
    """Remove a project's snapshot. Files on disk untouched."""
    _preflight_initialized()
    from .projects import ProjectStore
    store = ProjectStore(SETTINGS.paths.projects_dir)
    if not store.exists(name):
        _die(ExitCode.USAGE, f"project not found: {name}")
    if not yes and not STATE.json_out:
        if not typer.confirm(f"Delete project snapshot '{name}'?"):
            raise typer.Abort()
    store.delete(name)
    if STATE.json_out:
        _emit_json({"ok": True, "deleted": name})
    else:
        _print(f"[green]deleted[/green] · project {name}")


# ─── plain-English `sov do` ─────────────────────────────────────────────────


@app.command(name="do")
def do_cmd(
    directive: str = typer.Argument(..., help="Plain-English directive"),
    yes: bool = typer.Option(
        False, "--yes", "-y",
        help="Skip the confirm prompt before dispatch.",
    ),
) -> None:
    """Plain-English entry point. Tell the agent what to do in a sentence.

    Examples:
        sov do "Build trillion-dollar software, max 2000 files"
        sov do "Pause my dream"
        sov do "I updated genesis-seeds"
        sov do "Inventory ~/AA-Erebo/Genesis-Seeds for markdown files"
        sov do "Show me what's happening"

    The parser is deterministic and keyword-based — see directives.py.
    Missing arguments turn into interactive prompts.

    v0.2.12+
    """
    from .directives import (
        Directive, parse_directive, render_directive_summary,
    )
    d: Directive = parse_directive(directive)

    if d.intent == "unknown":
        _die(ExitCode.USAGE,
             d.confidence_message,
             hint="Try: 'build trillion dollar software', 'pause my dream', "
                  "'inventory ~/AA-Erebo for markdown', 'show status'")

    # ── Interactive: ask any missing-data questions ─────────────────────
    if d.questions:
        _print(f"[cyan]◈ understanding directive:[/cyan] {render_directive_summary(d)}")
        if yes:
            # Non-interactive: take defaults; abort if any required Q lacks one.
            for q in d.questions:
                if q.default is not None:
                    d.kwargs[q.field] = q.default
                elif q.required:
                    _die(ExitCode.USAGE,
                         f"directive missing required field: {q.field} "
                         f"(no default; cannot continue with --yes)",
                         hint=q.prompt)
        else:
            _print(f"[dim]I need a few details — answer 'cancel' to abort.[/dim]\n")
            for q in d.questions:
                answered = _ask_question(q)
                if answered is None:
                    _print("[yellow]aborted[/yellow]")
                    raise typer.Exit(ExitCode.USAGE)
                d.kwargs[q.field] = answered
            _print()

    # ── Confirm before dispatch ─────────────────────────────────────────
    summary = render_directive_summary(d)
    if not yes and not STATE.json_out:
        _print(f"[bold]ready:[/bold] {summary}")
        if not typer.confirm("proceed?"):
            _print("[yellow]aborted[/yellow]")
            raise typer.Abort()

    _dispatch_directive(d)


def _ask_question(q) -> str | None:
    """Prompt for one piece of missing data. Returns None if operator cancels.

    Suggestions are shown inline. If a default is provided, an empty answer
    accepts it.
    """
    suggest_str = ""
    if q.suggestions:
        suggest_str = f" [dim]examples:[/dim] {', '.join(q.suggestions)}"
    default_str = f" [dim]\\[default: {q.default}][/dim]" if q.default else ""
    while True:
        _print(f"  {q.prompt}{default_str}{suggest_str}")
        try:
            answer = input("  > ").strip()
        except (EOFError, KeyboardInterrupt):
            return None
        if answer.lower() in ("cancel", "q", "quit", "abort"):
            return None
        if not answer:
            if q.default is not None:
                return q.default
            if not q.required:
                return ""
            _print("  [yellow](required — please answer or type 'cancel')[/yellow]")
            continue
        return answer


def _dispatch_directive(d) -> None:
    """Take a fully-resolved directive and run it via existing CLI entry points.

    Each branch translates the directive's kwargs into the right call. We
    re-enter the Typer commands by calling them as functions. This keeps a
    single source of truth for the command logic — `sov do` is a UX layer,
    not a parallel dispatcher.
    """
    intent = d.intent
    kw = d.kwargs

    if intent == "dream":
        max_files = int(kw.get("max_files", 2000) or 0)
        max_cycles = int(kw.get("max_cycles", 0) or 0)
        return dream_start(
            goal=kw.get("goal", "trillion-dollar dream"),
            max_files=max_files, max_cycles=max_cycles,
            max_seconds=0, project=[], drive=False,
        )
    if intent == "dream_control":
        action = kw.get("action", "")
        dream_id = kw.get("dream_id", "")
        if dream_id == "latest":
            from .dream import DreamStore
            store = DreamStore(SETTINGS.paths.dream_sessions_dir,
                               SETTINGS.paths.dreams_work_dir)
            actives = store.list_all(status="active")
            if not actives:
                _die(ExitCode.USAGE,
                     "no active dreams found; specify a dream-id explicitly")
            dream_id = actives[-1].dream_id
        if action == "pause":
            return dream_pause_cmd(dream_id=dream_id)
        if action == "resume":
            return dream_resume_cmd(dream_id=dream_id, drive=False)
        if action == "stop":
            return dream_stop_cmd(dream_id=dream_id, yes=True)
    if intent == "continue_cont":
        return resume_cmd(task_id=kw["task_id"], drive=False)
    if intent == "pause_cont":
        return pause_cmd(task_id=kw["task_id"], reason="via sov do")
    if intent == "inventory":
        return plan_cmd(
            planner="inventory",
            root=Path(kw["root"]),
            output=Path(kw["output"]),
            pattern=list(kw.get("patterns") or []),
            exclude=[], include=[], include_no_ext=False,
            max_files=0, no_recursive=False,
            tag=None, max_extract_chars=40_000, max_file_size=0,
            room_id=None, room_name=None, atom_type=None,
            task_id=None, dry_run=False,
        )
    if intent == "projects":
        action = kw.get("action", "list")
        if action == "list":
            return projects_list_cmd()
        if action == "scan":
            return projects_scan_cmd(
                name=kw["name"], root=Path(kw["root"]),
                exclude=[], follow_symlinks=False, max_files=0,
            )
        if action == "update":
            return projects_update_cmd(
                name=kw["name"], atomize=True, keep_old=False,
            )
    if intent == "status":
        # Render a one-screen summary similar to `sov-status` shell alias,
        # but in-process so it works from `sov do "status"`.
        _render_status()
        return
    if intent == "list":
        what = kw.get("what", "all")
        if what in ("dreams", "all"):
            dream_list_cmd(status_filter=None)
        if what in ("continuations", "all"):
            cont_list(status=None)
        if what in ("projects", "all"):
            projects_list_cmd()
        if what in ("planners", "all"):
            plan_cmd(
                planner=None, root=None, output=None, pattern=[],
                exclude=[], include=[], include_no_ext=False,
                max_files=0, no_recursive=False, tag=None,
                max_extract_chars=40_000, max_file_size=0,
                room_id=None, room_name=None, atom_type=None,
                task_id=None, dry_run=False,
            )
        return
    if intent == "help":
        _print(Panel(
            "[bold]sov do[/bold] — plain-English entry\n\n"
            "Try things like:\n"
            "  • 'Build trillion-dollar software, max 2000 files'\n"
            "  • 'Build trillion-dollar software forever'\n"
            "  • 'Pause my dream'\n"
            "  • 'Resume dream-01J...'\n"
            "  • 'I updated genesis-seeds'\n"
            "  • 'Scan ~/AA-Erebo/Genesis-Seeds for markdown'\n"
            "  • 'Show status'\n"
            "  • 'List dreams'\n",
            title="◈ help · sov do", border_style="cyan",
        ))
        return

    _die(ExitCode.USAGE, f"unhandled intent: {intent}")


def _render_status() -> None:
    """One-screen status summary."""
    from .continuation import ContinuationStore
    from .dream import DreamStore
    from .projects import ProjectStore
    cstore = ContinuationStore(SETTINGS.paths.continuations_dir)
    dstore = DreamStore(SETTINGS.paths.dream_sessions_dir,
                       SETTINGS.paths.dreams_work_dir)
    pstore = ProjectStore(SETTINGS.paths.projects_dir)

    conts = cstore.list_all()
    dreams = dstore.list_all()
    projects = pstore.list_names()

    active_conts = [c for c in conts if c.status in ("planned", "in_progress")]
    paused_conts = [c for c in conts if c.status == "paused"]
    active_dreams = [d for d in dreams if d.status == "active"]
    paused_dreams = [d for d in dreams if d.status == "paused"]

    if STATE.json_out:
        _emit_json({
            "continuations": {
                "total": len(conts),
                "active": len(active_conts),
                "paused": len(paused_conts),
            },
            "dreams": {
                "total": len(dreams),
                "active": len(active_dreams),
                "paused": len(paused_dreams),
            },
            "projects": {"total": len(projects), "names": projects},
        })
        return

    _print(Panel(
        f"continuations: total={len(conts)} active={len(active_conts)} paused={len(paused_conts)}\n"
        f"dreams: total={len(dreams)} active={len(active_dreams)} paused={len(paused_dreams)}\n"
        f"projects: {len(projects)}",
        title="◈ status", border_style="cyan",
    ))
    if active_dreams:
        _print(f"[cyan]active dreams:[/cyan]")
        for d in active_dreams:
            _print(f"  {d.dream_id} · {d.progress_summary()}")
    if active_conts:
        _print(f"[cyan]active continuations:[/cyan]")
        for c in active_conts[:5]:
            done, total = c.progress
            _print(f"  {c.task_id} · {done}/{total} · {c.planner}")


# ─── continuation aliases (light-touch) ─────────────────────────────────────


@cont_app.command("alias")
def cont_alias_cmd(
    task_id: str = typer.Argument(..., help="Existing continuation ID"),
    alias: str = typer.Argument(..., help="Short friendly name (alphanum/-_.)"),
) -> None:
    """Attach a friendly name to a continuation. Look it up by alias later.

    Aliases are stored in `<config_dir>/continuation-aliases.yaml`. Resolved
    everywhere a task_id is accepted via `sov do` (continue/pause/resume).

    v0.2.12+
    """
    _preflight_initialized()
    from .continuation import ContinuationNotFound, ContinuationStore
    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    try:
        store.get(task_id)
    except ContinuationNotFound:
        _die(ExitCode.USAGE, f"continuation not found: {task_id}")

    safe = all(c.isalnum() or c in "-_." for c in alias) and alias
    if not safe:
        _die(ExitCode.USAGE,
             f"alias must be alphanum / -_.; got {alias!r}")

    aliases_file = SETTINGS.paths.config_dir / "continuation-aliases.yaml"
    data: dict = {}
    if aliases_file.exists():
        try:
            data = yaml.safe_load(aliases_file.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            data = {}
    data[alias] = task_id
    aliases_file.write_text(yaml.safe_dump(data, sort_keys=True), encoding="utf-8")

    if STATE.json_out:
        _emit_json({"ok": True, "alias": alias, "task_id": task_id})
    else:
        _print(f"[green]alias[/green] · {alias} → {task_id}")


# ════════════════════════════════════════════════════════════════════════════
# v0.2.13 — top-level commands and new sub-apps
# ════════════════════════════════════════════════════════════════════════════


@app.command()
def status() -> None:
    """Show a one-glance summary of dreams, continuations, projects, palace.

    Promoted from `sov do status` to a real top-level command in v0.2.13
    because it's the most-used read action.
    """
    from .continuation import ContinuationStore
    from .dream import DreamStore
    from .projects import ProjectStore

    paths = SETTINGS.paths
    cont_store = ContinuationStore(paths.continuations_dir)
    dream_store = DreamStore(
        root=paths.data_dir / "dreams",
        work_root=paths.data_dir / "dream-sessions",
    )
    proj_store = ProjectStore(paths.data_dir / "projects")

    try:
        conts = cont_store.list_all()
    except Exception:  # noqa: BLE001
        conts = []
    try:
        dreams = dream_store.list_all()
    except Exception:  # noqa: BLE001
        dreams = []
    try:
        projects = proj_store.list_all()
    except Exception:  # noqa: BLE001
        projects = []

    cont_in_progress = sum(1 for c in conts if c.status == "in_progress")
    cont_paused = sum(1 for c in conts if c.status == "paused")
    cont_done = sum(1 for c in conts if c.status == "done")
    dream_active = sum(1 for d in dreams if d.status == "active")
    dream_paused = sum(1 for d in dreams if d.status == "paused")

    if STATE.json_out:
        _emit_json({
            "ok": True,
            "continuations": {
                "total": len(conts), "in_progress": cont_in_progress,
                "paused": cont_paused, "done": cont_done,
            },
            "dreams": {
                "total": len(dreams), "active": dream_active,
                "paused": dream_paused,
            },
            "projects": {"total": len(projects)},
        })
        return

    t = Table(show_header=False, box=None, padding=(0, 1))
    t.add_column(style="dim")
    t.add_column()
    t.add_row("continuations",
              f"{len(conts)} total · {cont_in_progress} in-progress · "
              f"{cont_paused} paused · {cont_done} done")
    t.add_row("dreams",
              f"{len(dreams)} total · {dream_active} active · "
              f"{dream_paused} paused")
    t.add_row("projects", f"{len(projects)} tracked")
    _print(Panel(t, title="◈ sovereign-agent status", border_style="cyan"))


# ─── Health sub-app ─────────────────────────────────────────────────────────


health_app = typer.Typer(
    help="◈ anti-zombie / anti-ghost detection (v0.2.13)",
)
app.add_typer(health_app, name="health")


@health_app.command("check")
def health_check_cmd(
    zombie_hours: int = typer.Option(
        6, "--zombie-hours",
        help="Stalled in_progress threshold (hours)",
    ),
    idle_window: int = typer.Option(
        3, "--idle-window",
        help="Number of recent cycles checked for idle detection",
    ),
) -> None:
    """Scan for zombies, ghosts, stale locks, and idle dream cycles."""
    from .continuation import ContinuationStore
    from .dream import DreamStore
    from .health import run_full_scan

    paths = SETTINGS.paths
    cont_store = ContinuationStore(paths.continuations_dir)
    dream_store = DreamStore(
        root=paths.data_dir / "dreams",
        work_root=paths.data_dir / "dream-sessions",
    )

    report = run_full_scan(
        cont_store, dream_store,
        zombie_threshold=zombie_hours * 3600,
        idle_window=idle_window,
    )

    if STATE.json_out:
        _emit_json({
            "ok": report.ok,
            "summary": report.summary_line(),
            "findings": [
                {
                    "edge_case_id": f.edge_case_id,
                    "severity": f.severity,
                    "target": f.target,
                    "target_kind": f.target_kind,
                    "summary": f.summary,
                }
                for f in report.findings
            ],
        })
        return

    if not report.findings:
        _print("[green]✓ no health issues detected[/green]")
        return

    t = Table(title="◈ health findings", box=None, show_lines=False)
    t.add_column("ID", style="cyan", no_wrap=True)
    t.add_column("Severity", style="yellow")
    t.add_column("Target", style="magenta")
    t.add_column("Summary")
    for f in report.findings:
        t.add_row(f.edge_case_id, f.severity, f.target, f.summary)
    _print(t)
    _print(f"\n[dim]{report.summary_line()}[/dim]")
    _print("[dim]Use `sov health repair --dry-run` to see proposed "
           "fixes.[/dim]")


@health_app.command("repair")
def health_repair_cmd(
    dry_run: bool = typer.Option(
        True, "--dry-run/--apply",
        help="Default: dry-run. Pass --apply to actually fix.",
    ),
) -> None:
    """Plan (and optionally apply) repairs for health findings."""
    from .continuation import ContinuationStore
    from .dream import DreamStore
    from .health import apply_repairs, plan_repairs, run_full_scan

    paths = SETTINGS.paths
    cont_store = ContinuationStore(paths.continuations_dir)
    dream_store = DreamStore(
        root=paths.data_dir / "dreams",
        work_root=paths.data_dir / "dream-sessions",
    )

    report = run_full_scan(cont_store, dream_store)
    actions = plan_repairs(report)

    if not actions:
        _print("[green]nothing to repair[/green]")
        return

    if STATE.json_out:
        _emit_json({
            "ok": True, "dry_run": dry_run,
            "actions": [
                {"kind": a.kind, "target": a.target,
                 "description": a.description}
                for a in actions
            ],
        })
        return

    t = Table(title=f"◈ repairs ({'dry-run' if dry_run else 'will apply'})",
              box=None)
    t.add_column("Kind", style="cyan")
    t.add_column("Target", style="magenta")
    t.add_column("Description")
    for a in actions:
        t.add_row(a.kind, a.target, a.description)
    _print(t)

    if dry_run:
        _print("\n[dim]Re-run with --apply to execute.[/dim]")
        return

    if not typer.confirm(f"Apply {len(actions)} repair(s)?"):
        _print("[yellow]aborted[/yellow]")
        return

    applied = apply_repairs(
        actions, cont_store=cont_store, dream_store=dream_store, dry_run=False,
    )
    success = sum(1 for a in applied if a.applied)
    failed = sum(1 for a in applied if not a.applied)
    _print(f"[green]applied {success}[/green] · [red]failed {failed}[/red]")
    for a in applied:
        if a.error:
            _print(f"  [red]✗[/red] {a.target}: {a.error}")


# ─── Edge-cases sub-app ─────────────────────────────────────────────────────


edge_cases_app = typer.Typer(
    help="◈ edge-case registry (v0.2.13)",
)
app.add_typer(edge_cases_app, name="edge-cases")


@edge_cases_app.command("list")
def edge_cases_list_cmd(
    subsystem: str = typer.Option(
        "", "--subsystem", "-s",
        help="Filter by id prefix (e.g. EC-DREAM, EC-VAL)",
    ),
    severity: str = typer.Option(
        "", "--severity",
        help="Filter by severity: info | warn | error | critical",
    ),
) -> None:
    """List all registered edge cases with their ids, locations, severities."""
    from .edge_cases import by_severity, by_subsystem, list_all

    if subsystem:
        entries = by_subsystem(subsystem)
    elif severity:
        entries = by_severity(severity)  # type: ignore[arg-type]
    else:
        entries = list_all()

    if STATE.json_out:
        _emit_json({
            "ok": True, "count": len(entries),
            "entries": [
                {"id": e.id, "title": e.title, "location": e.location,
                 "severity": e.severity, "introduced_in": e.introduced_in}
                for e in entries
            ],
        })
        return

    t = Table(title="◈ registered edge cases", box=None, show_lines=False)
    t.add_column("ID", style="cyan", no_wrap=True)
    t.add_column("Title")
    t.add_column("Severity", style="yellow", no_wrap=True)
    t.add_column("Where", style="dim", no_wrap=True)
    t.add_column("v", style="dim")
    for e in entries:
        t.add_row(e.id, e.title, e.severity, e.location, e.introduced_in)
    _print(t)


@edge_cases_app.command("show")
def edge_cases_show_cmd(
    edge_case_id: str = typer.Argument(..., help="e.g. EC-DREAM-001"),
) -> None:
    """Show full detail for one edge case."""
    from .edge_cases import get
    try:
        ec = get(edge_case_id.upper())
    except KeyError:
        _print(f"[red]unknown edge case: {edge_case_id}[/red]")
        _print("[dim]Use `sov edge-cases list` to see all.[/dim]")
        raise typer.Exit(code=1)

    if STATE.json_out:
        _emit_json({
            "ok": True,
            "id": ec.id, "title": ec.title, "location": ec.location,
            "description": ec.description, "fires_when": ec.fires_when,
            "recovery": ec.recovery, "severity": ec.severity,
            "introduced_in": ec.introduced_in,
        })
        return

    t = Table(show_header=False, box=None, padding=(0, 1))
    t.add_column(style="dim", no_wrap=True)
    t.add_column()
    t.add_row("id", ec.id)
    t.add_row("title", ec.title)
    t.add_row("location", ec.location)
    t.add_row("severity", f"[yellow]{ec.severity}[/yellow]")
    t.add_row("introduced", ec.introduced_in or "-")
    t.add_row("description", ec.description)
    t.add_row("fires when", ec.fires_when)
    t.add_row("recovery", ec.recovery)
    _print(Panel(t, title=f"◈ {ec.id}", border_style="cyan"))


# ─── Personas sub-app ───────────────────────────────────────────────────────


personas_app = typer.Typer(
    help="◈ persona registry (v0.2.13)",
)
app.add_typer(personas_app, name="personas")


@personas_app.command("list")
def personas_list_cmd() -> None:
    """List registered personas."""
    from .personas import REGISTRY

    if STATE.json_out:
        _emit_json({
            "ok": True,
            "personas": [
                {"name": p.name, "voice": p.voice,
                 "principles_count": len(p.principles)}
                for p in REGISTRY.values()
            ],
        })
        return

    t = Table(title="◈ registered personas", box=None)
    t.add_column("Name", style="cyan", no_wrap=True)
    t.add_column("Principles", style="dim", no_wrap=True)
    t.add_column("Voice")
    for p in REGISTRY.values():
        t.add_row(p.name, str(len(p.principles)), p.voice[:60])
    _print(t)


@personas_app.command("show")
def personas_show_cmd(
    name: str = typer.Argument(..., help="e.g. master-architect"),
) -> None:
    """Show the full rendered persona."""
    from .personas import get_persona
    try:
        p = get_persona(name)
    except KeyError:
        _print(f"[red]unknown persona: {name}[/red]")
        _print("[dim]Use `sov personas list` to see all.[/dim]")
        raise typer.Exit(code=1)

    if STATE.json_out:
        _emit_json({
            "ok": True, "name": p.name, "role": p.role,
            "principles": list(p.principles),
            "anti_patterns": list(p.anti_patterns),
            "voice": p.voice, "signature": p.signature,
            "rendered": p.render(),
        })
        return

    _print(Panel(p.render(), title=f"◈ {p.name}", border_style="cyan"))


# ─── Dream sub-app: tail + gc + branch ─────────────────────────────────────


@dream_app.command("tail")
def dream_tail_cmd(
    dream_id: str = typer.Argument(..., help="dream id to tail"),
    lines: int = typer.Option(
        50, "--lines", "-n",
        help="Lines per file to show",
    ),
) -> None:
    """Stream the latest cycle's idea.md / architecture.md / README.md."""
    from .dream import DreamStore

    paths = SETTINGS.paths
    store = DreamStore(
        root=paths.data_dir / "dreams",
        work_root=paths.data_dir / "dream-sessions",
    )
    try:
        d = store.get(dream_id)
    except Exception as e:  # noqa: BLE001
        _print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)

    if not d.cycles:
        _print(f"[dim]dream {dream_id}: no cycles yet[/dim]")
        return

    last = d.cycles[-1]
    if not last.cycle_dir:
        _print(f"[dim]cycle {last.cycle_number}: no cycle_dir on record[/dim]")
        return

    cycle_dir = Path(last.cycle_dir)
    for name in ("idea.md", "architecture.md", "README.md"):
        p = cycle_dir / name
        if not p.is_file():
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        body = "\n".join(text.splitlines()[:lines])
        _print(Panel(body, title=f"◈ cycle-{last.cycle_number:03d}/{name}",
                     border_style="cyan"))


@dream_app.command("gc")
def dream_gc_cmd(
    older_than_days: int = typer.Option(
        30, "--older-than",
        help="Delete work_dirs of terminal dreams older than N days",
    ),
    dry_run: bool = typer.Option(
        True, "--dry-run/--apply",
        help="Default: dry-run.",
    ),
) -> None:
    """Garbage-collect work_dirs of completed/exhausted/halted dreams.

    Only touches the WORK_DIR (cycle source files). The dream YAML
    record stays — atoms.db references survive too. This is purely a
    disk reclaim for source trees you're done iterating on.
    """
    from datetime import datetime, timezone, timedelta
    from .dream import DreamStore

    paths = SETTINGS.paths
    store = DreamStore(
        root=paths.data_dir / "dreams",
        work_root=paths.data_dir / "dream-sessions",
    )
    try:
        dreams = store.list_all()
    except Exception:  # noqa: BLE001
        dreams = []

    cutoff = datetime.now(timezone.utc) - timedelta(days=older_than_days)
    eligible = []
    for d in dreams:
        if d.status not in ("completed", "exhausted", "halted"):
            continue
        try:
            updated = datetime.strptime(
                d.updated_at, "%Y-%m-%dT%H:%M:%S.%fZ",
            ).replace(tzinfo=timezone.utc)
        except (ValueError, TypeError):
            continue
        if updated > cutoff:
            continue
        work_dir = Path(d.work_dir) if d.work_dir else None
        if work_dir and work_dir.exists():
            eligible.append((d, work_dir))

    if not eligible:
        _print(f"[green]nothing to GC[/green] "
               f"(no terminal dreams older than {older_than_days}d "
               f"with extant work_dirs)")
        return

    if STATE.json_out:
        _emit_json({
            "ok": True, "dry_run": dry_run,
            "eligible": [
                {"dream_id": d.dream_id, "status": d.status,
                 "work_dir": str(wd)}
                for d, wd in eligible
            ],
        })
        return

    t = Table(title=f"◈ gc candidates ({'dry-run' if dry_run else 'will delete'})",
              box=None)
    t.add_column("Dream", style="cyan")
    t.add_column("Status", style="yellow")
    t.add_column("Work dir", style="dim")
    for d, wd in eligible:
        t.add_row(d.dream_id, d.status, str(wd))
    _print(t)

    if dry_run:
        _print("\n[dim]Re-run with --apply to delete.[/dim]")
        return

    if not typer.confirm(f"Delete {len(eligible)} work_dir(s)?"):
        _print("[yellow]aborted[/yellow]")
        return

    import shutil
    deleted = 0
    for _, wd in eligible:
        try:
            shutil.rmtree(wd)
            deleted += 1
        except OSError as e:
            _print(f"  [red]✗[/red] {wd}: {e}")
    _print(f"[green]deleted {deleted}[/green]")



# ════════════════════════════════════════════════════════════════════════════
# v0.2.14 — Aria, channels, financial, horizon, appendix
# ════════════════════════════════════════════════════════════════════════════


@app.command()
def aria() -> None:
    """Show Aria-Sovereign-V1's current state — kernel, mood, inventory."""
    from .aria import load_state
    from .db import open_atoms_db
    # Make sure all channels are registered
    from . import mem_channels  # noqa: F401

    conn = open_atoms_db()
    try:
        state = load_state(conn)
    finally:
        conn.close()

    if STATE.json_out:
        _emit_json({
            "ok": True,
            "designation": state.designation,
            "tagline": state.tagline,
            "mood": state.current_mood,
            "focus": state.current_focus,
            "self_narrative": state.self_narrative,
            "active_goals": state.active_goals,
            "open_intentions": state.open_intentions,
            "tracked_projects": state.tracked_projects,
        })
        return

    _print(state.render_card())


# ─── Channels sub-app ──────────────────────────────────────────────────────


channels_app = typer.Typer(
    help="◈ modular memory channels (v0.2.14)",
)
app.add_typer(channels_app, name="channels")


@channels_app.command("list")
def channels_list_cmd() -> None:
    """List all registered memory channels."""
    from . import mem_channels  # noqa: F401
    from .channels import list_channels
    specs = list_channels()

    if STATE.json_out:
        _emit_json({
            "ok": True, "count": len(specs),
            "channels": [
                {"name": s.name, "tier": s.authority_tier,
                 "description": s.description, "voice": s.voice}
                for s in specs
            ],
        })
        return

    t = Table(title="◈ memory channels", box=None)
    t.add_column("Channel", style="cyan", no_wrap=True)
    t.add_column("Tier", style="yellow", no_wrap=True)
    t.add_column("Voice", style="dim")
    t.add_column("Purpose")
    for s in specs:
        t.add_row(s.name, str(s.authority_tier), s.voice[:40],
                  s.description[:60])
    _print(t)


@channels_app.command("show")
def channels_show_cmd(
    name: str = typer.Argument(..., help="channel name"),
) -> None:
    """Show one channel's spec and recent atoms."""
    from . import mem_channels  # noqa: F401
    from .channels import get_channel, list_channels
    from .db import open_atoms_db

    spec = next((s for s in list_channels() if s.name == name), None)
    if spec is None:
        _print(f"[red]unknown channel: {name}[/red]")
        raise typer.Exit(code=1)

    conn = open_atoms_db()
    try:
        ch = get_channel(name, conn)
        recent = ch.list_atoms(limit=10)
    finally:
        conn.close()

    if STATE.json_out:
        _emit_json({
            "ok": True, "spec": {
                "name": spec.name, "tier": spec.authority_tier,
                "description": spec.description, "voice": spec.voice,
            },
            "recent_atoms": recent,
        })
        return

    t = Table(show_header=False, box=None, padding=(0, 1))
    t.add_column(style="dim")
    t.add_column()
    t.add_row("name", spec.name)
    t.add_row("tier", str(spec.authority_tier))
    t.add_row("description", spec.description)
    t.add_row("voice", spec.voice)
    t.add_row("idempotency", "required" if spec.requires_idempotency else "optional")
    _print(Panel(t, title=f"◈ channel: {spec.name}", border_style="cyan"))

    if recent:
        rt = Table(title=f"recent atoms ({len(recent)})", box=None)
        rt.add_column("ID", style="dim", no_wrap=True)
        rt.add_column("Confidence", style="yellow", no_wrap=True)
        rt.add_column("Summary")
        for a in recent:
            rt.add_row(a["atom_id"][:24] + "…", f"{a['confidence']:.2f}",
                       a["summary"][:80])
        _print(rt)


# ─── Financial sub-app ─────────────────────────────────────────────────────


financial_app = typer.Typer(
    help="◈ per-project investment & earnings ledger (v0.2.14)",
)
app.add_typer(financial_app, name="financial")


def _open_financial_channel():
    from . import mem_channels  # noqa: F401
    from .db import open_atoms_db
    from .mem_channels.financial import FinancialChannel
    conn = open_atoms_db()
    return FinancialChannel(conn), conn


@financial_app.command("invest")
def financial_invest_cmd(
    project: str = typer.Argument(..., help="project name"),
    amount: float = typer.Argument(..., help="amount invested"),
    note: str = typer.Option("", "--note", "-n"),
    currency: str = typer.Option("USD", "--currency"),
    yes: bool = typer.Option(False, "-y", "--yes", help="skip confirmation"),
) -> None:
    """Record an INVESTMENT (Tier 3 — operator confirmation required)."""
    import uuid
    from .mem_channels.financial import CurrencyMismatchError
    if not yes and not STATE.json_out:
        _print(f"[yellow]Tier 3 action[/yellow]: investing "
               f"[bold]{amount} {currency}[/bold] in [cyan]{project}[/cyan]")
        if note:
            _print(f"  note: {note}")
        if not typer.confirm("Confirm?"):
            _print("[yellow]aborted[/yellow]")
            return

    fc, conn = _open_financial_channel()
    try:
        try:
            entry = fc.record(
                project=project, kind="invest", amount=amount,
                currency=currency, note=note,
                idempotency_id=str(uuid.uuid4()),
            )
        except CurrencyMismatchError as exc:
            if STATE.json_out:
                _emit_json({"ok": False, "error": "currency_mismatch",
                            "detail": str(exc)})
            else:
                _print(f"[red]✗ currency mismatch[/red]: {exc}")
            raise typer.Exit(code=1)
        except ValueError as exc:
            if STATE.json_out:
                _emit_json({"ok": False, "error": "invalid_input",
                            "detail": str(exc)})
            else:
                _print(f"[red]✗ invalid input[/red]: {exc}")
            raise typer.Exit(code=1)
    finally:
        conn.close()

    if STATE.json_out:
        _emit_json({"ok": True, "entry_id": entry.entry_id,
                    "project": entry.project, "amount": entry.amount})
    else:
        _print(f"[green]✓[/green] invested {entry.amount} {entry.currency} "
               f"in {entry.project} ({entry.entry_id})")


@financial_app.command("earn")
def financial_earn_cmd(
    project: str = typer.Argument(..., help="project name"),
    amount: float = typer.Argument(..., help="amount earned"),
    note: str = typer.Option("", "--note", "-n"),
    currency: str = typer.Option("USD", "--currency"),
    yes: bool = typer.Option(False, "-y", "--yes"),
) -> None:
    """Record EARNINGS (Tier 3 — operator confirmation required)."""
    import uuid
    from .mem_channels.financial import CurrencyMismatchError
    if not yes and not STATE.json_out:
        _print(f"[yellow]Tier 3 action[/yellow]: recording earnings of "
               f"[bold]{amount} {currency}[/bold] for [cyan]{project}[/cyan]")
        if note:
            _print(f"  note: {note}")
        if not typer.confirm("Confirm?"):
            _print("[yellow]aborted[/yellow]")
            return

    fc, conn = _open_financial_channel()
    try:
        try:
            entry = fc.record(
                project=project, kind="earn", amount=amount,
                currency=currency, note=note,
                idempotency_id=str(uuid.uuid4()),
            )
        except CurrencyMismatchError as exc:
            if STATE.json_out:
                _emit_json({"ok": False, "error": "currency_mismatch",
                            "detail": str(exc)})
            else:
                _print(f"[red]✗ currency mismatch[/red]: {exc}")
            raise typer.Exit(code=1)
        except ValueError as exc:
            if STATE.json_out:
                _emit_json({"ok": False, "error": "invalid_input",
                            "detail": str(exc)})
            else:
                _print(f"[red]✗ invalid input[/red]: {exc}")
            raise typer.Exit(code=1)
    finally:
        conn.close()

    if STATE.json_out:
        _emit_json({"ok": True, "entry_id": entry.entry_id,
                    "project": entry.project, "amount": entry.amount})
    else:
        _print(f"[green]✓[/green] earned {entry.amount} {entry.currency} "
               f"on {entry.project} ({entry.entry_id})")


@financial_app.command("show")
def financial_show_cmd(
    project: str = typer.Argument(..., help="project name"),
) -> None:
    """Show a project's lifetime balance and ROI."""
    fc, conn = _open_financial_channel()
    try:
        bal = fc.project_balance(project)
    finally:
        conn.close()

    if STATE.json_out:
        _emit_json({
            "ok": True, "project": bal.project,
            "invested": bal.invested, "earned": bal.earned,
            "net": bal.net,
            "roi_ratio": bal.roi_ratio,
            "currency": bal.currency,
            "entry_count": bal.entry_count,
            "first_event": bal.first_event,
            "last_event": bal.last_event,
        })
        return

    t = Table(show_header=False, box=None, padding=(0, 1))
    t.add_column(style="dim")
    t.add_column()
    t.add_row("project", bal.project)
    t.add_row("invested", f"{bal.invested:.2f} {bal.currency}")
    t.add_row("earned", f"{bal.earned:.2f} {bal.currency}")
    net_color = "green" if bal.net >= 0 else "red"
    t.add_row("net", f"[{net_color}]{bal.net:+.2f} {bal.currency}[/{net_color}]")
    if bal.roi_ratio is not None:
        roi_color = "green" if bal.roi_ratio >= 1.0 else "yellow"
        t.add_row("ROI", f"[{roi_color}]{bal.roi_ratio:.2f}x[/{roi_color}]")
    else:
        t.add_row("ROI", "[dim]undefined ($0 invested)[/dim]")
    t.add_row("entries", str(bal.entry_count))
    if bal.first_event:
        t.add_row("first event", bal.first_event)
    velocity = bal.velocity_per_day()
    if velocity is not None:
        t.add_row("velocity", f"{velocity:.2f} {bal.currency}/day")
    _print(Panel(t, title=f"◈ financial: {bal.project}", border_style="cyan"))


@financial_app.command("ranking")
def financial_ranking_cmd(
    by: str = typer.Option(
        "roi", "--by",
        help="sort key: roi | net | earned | velocity",
    ),
) -> None:
    """Rank all tracked projects by ROI / net / earned / velocity."""
    if by not in ("roi", "net", "earned", "velocity"):
        _print(f"[red]invalid --by: {by}[/red]")
        raise typer.Exit(code=1)

    fc, conn = _open_financial_channel()
    try:
        balances = fc.ranking(by=by)  # type: ignore[arg-type]
    finally:
        conn.close()

    if STATE.json_out:
        _emit_json({
            "ok": True, "by": by,
            "ranking": [
                {"project": b.project, "invested": b.invested,
                 "earned": b.earned, "net": b.net,
                 "roi_ratio": b.roi_ratio,
                 "velocity_per_day": b.velocity_per_day()}
                for b in balances
            ],
        })
        return

    t = Table(title=f"◈ projects ranked by {by}", box=None)
    t.add_column("#", style="dim", no_wrap=True)
    t.add_column("Project", style="cyan")
    t.add_column("Invested", style="yellow", justify="right")
    t.add_column("Earned", style="green", justify="right")
    t.add_column("Net", justify="right")
    t.add_column("ROI", style="magenta", justify="right")
    for i, b in enumerate(balances, 1):
        net_color = "green" if b.net >= 0 else "red"
        roi_str = f"{b.roi_ratio:.2f}x" if b.roi_ratio is not None else "—"
        t.add_row(
            str(i), b.project,
            f"{b.invested:.2f}", f"{b.earned:.2f}",
            f"[{net_color}]{b.net:+.2f}[/{net_color}]",
            roi_str,
        )
    _print(t)


@financial_app.command("audit")
def financial_audit_cmd() -> None:
    """Verify ledger integrity. Read-only invariant check.

    Reports orphaned companion atoms, dangling reverts, currency
    violations, malformed entry IDs, and bad timestamps. Exits 0 if
    clean, 1 if violations found.
    """
    fc, conn = _open_financial_channel()
    try:
        result = fc.audit()
    finally:
        conn.close()

    if STATE.json_out:
        _emit_json({
            "ok": result.ok,
            "ledger_rows": result.ledger_rows,
            "violations": result.violations,
            "orphaned_atoms": result.orphaned_atoms,
            "orphaned_reverts": result.orphaned_reverts,
            "currency_mixed_projects": result.currency_mixed_projects,
            "bad_entry_ids": result.bad_entry_ids,
            "bad_timestamps": result.bad_timestamps,
        })
        if not result.ok:
            raise typer.Exit(code=1)
        return

    color = "green" if result.ok else "red"
    _print(f"[{color}]{result.render()}[/{color}]")
    if not result.ok:
        raise typer.Exit(code=1)


# ─── Cockpit (TUI) ─────────────────────────────────────────────────────────


@app.command()
def cockpit() -> None:
    """Launch the operator cockpit — full-screen TUI for talking to the agent.

    Chat on the left, live event stream on the right, status bar at the
    bottom. Plain-English input routes through ``sovereign do``; slash
    commands handle ops (snap, halt, audit, etc). F1 inside the cockpit
    shows full help.

    The cockpit is a CLIENT of the agent — it doesn't replace the daemon.
    The systemd service keeps running the busy-drain loop in the background;
    the cockpit gives you a conversational surface on top.

    Requires textual (installed automatically with sovereign-agent>=0.2.14.4).
    """
    try:
        from .cockpit import run as run_cockpit
    except ImportError as exc:
        _print(f"[red]✗ cockpit unavailable: {exc}[/red]")
        _print("  Try: pip install --break-system-packages textual")
        raise typer.Exit(code=1)
    run_cockpit()


@app.command()
def chat() -> None:
    """Alias for `sovereign cockpit` — what you'll type 10x/day."""
    cockpit()


# ─── Backup sub-app ────────────────────────────────────────────────────────


backup_app = typer.Typer(
    help="Backup, verify, prune, and restore snapshots. Application-aware "
         "(SQLite online backup; staged audit before restore).",
    no_args_is_help=True,
)


def _format_bytes(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f}{unit}"
        n /= 1024.0
    return f"{n}B"


def _format_age(seconds: float | None) -> str:
    if seconds is None:
        return "—"
    if seconds < 60:
        return f"{seconds:.0f}s"
    if seconds < 3600:
        return f"{seconds/60:.0f}m"
    if seconds < 86400:
        return f"{seconds/3600:.1f}h"
    return f"{seconds/86400:.1f}d"


@backup_app.command("snapshot")
def backup_snapshot_cmd(
    label: str = typer.Option("", "--label", "-l",
                              help="optional retention tag (kept forever)"),
    root: str = typer.Option("", "--root",
                             help="destination root; defaults to "
                                  "~/AA-Erebo/sov-backups"),
) -> None:
    """Capture an application-consistent snapshot. Tier 2."""
    from . import backup as backup_mod
    from pathlib import Path
    backup_root = Path(root).expanduser() if root else None
    try:
        manifest = backup_mod.snapshot(backup_root=backup_root, label=label)
    except Exception as exc:  # noqa: BLE001
        if STATE.json_out:
            _emit_json({"ok": False, "error": str(exc)})
        else:
            _print(f"[red]✗ snapshot failed: {exc}[/red]")
        raise typer.Exit(code=1)

    if STATE.json_out:
        _emit_json({
            "ok": True,
            "snapshot_id": manifest.snapshot_id,
            "total_bytes": manifest.total_bytes,
            "file_count": manifest.file_count,
            "atoms_count": manifest.atoms_count,
            "ledger_count": manifest.financial_ledger_count,
            "audit_clean": manifest.audit_at_snapshot.get("ok", False),
        })
    else:
        _print(f"[green]✓[/green] snapshot · {manifest.snapshot_id}")
        _print(f"  files: {manifest.file_count}  "
               f"size: {_format_bytes(manifest.total_bytes)}  "
               f"atoms: {manifest.atoms_count}  "
               f"ledger: {manifest.financial_ledger_count}")
        if not manifest.audit_at_snapshot.get("ok", False):
            _print("[yellow]  ⚠ audit at snapshot was not clean — "
                   "snapshot still captured but flagged[/yellow]")


@backup_app.command("list")
def backup_list_cmd(
    root: str = typer.Option("", "--root"),
) -> None:
    """List all snapshots, newest-first. Tier 0."""
    from . import backup as backup_mod
    from pathlib import Path
    backup_root = Path(root).expanduser() if root else None
    snaps = backup_mod.list_snapshots(backup_root=backup_root)

    if STATE.json_out:
        _emit_json({
            "ok": True, "count": len(snaps),
            "snapshots": [
                {
                    "snapshot_id": s.snapshot_id,
                    "created_at": s.created_at,
                    "label": s.label,
                    "source_version": s.source_version,
                    "total_bytes": s.total_bytes,
                    "file_count": s.file_count,
                    "atoms_count": s.atoms_count,
                    "audit_clean": s.audit_at_snapshot.get("ok", False),
                } for s in snaps
            ],
        })
        return

    if not snaps:
        _print("[dim](no snapshots)[/dim]")
        return

    t = Table(title="◈ snapshots", box=None)
    t.add_column("ID", style="cyan", no_wrap=True)
    t.add_column("Created", style="dim", no_wrap=True)
    t.add_column("Version", no_wrap=True)
    t.add_column("Size", justify="right")
    t.add_column("Atoms", justify="right")
    t.add_column("Audit", no_wrap=True)
    t.add_column("Label", style="yellow")
    for s in snaps:
        audit_color = "green" if s.audit_at_snapshot.get("ok", False) else "red"
        audit_mark = "✓" if s.audit_at_snapshot.get("ok", False) else "✗"
        t.add_row(
            s.snapshot_id[:38],
            s.created_at[:19].replace("T", " "),
            s.source_version,
            _format_bytes(s.total_bytes),
            str(s.atoms_count),
            f"[{audit_color}]{audit_mark}[/{audit_color}]",
            s.label,
        )
    _print(t)


@backup_app.command("verify")
def backup_verify_cmd(
    snapshot_id: str = typer.Argument("", help="snapshot id (prefix OK); "
                                                "omit to verify all"),
    all_snaps: bool = typer.Option(False, "--all"),
    root: str = typer.Option("", "--root"),
    skip_audit: bool = typer.Option(False, "--skip-audit",
                                     help="hash check only; no atoms.db audit"),
) -> None:
    """Re-hash a snapshot and check the manifest. Tier 0."""
    from . import backup as backup_mod
    from pathlib import Path
    backup_root = Path(root).expanduser() if root else None

    if all_snaps or not snapshot_id:
        snaps = backup_mod.list_snapshots(backup_root=backup_root)
        if not snaps:
            _print("[dim](no snapshots to verify)[/dim]")
            return
        results = [
            backup_mod.verify(s.snapshot_id, backup_root=backup_root,
                              run_audit=not skip_audit)
            for s in snaps
        ]
        n_ok = sum(1 for r in results if r.ok)
        if STATE.json_out:
            _emit_json({
                "ok": all(r.ok for r in results),
                "verified": len(results),
                "passed": n_ok,
                "failed": len(results) - n_ok,
                "results": [
                    {
                        "snapshot_id": r.snapshot_id, "ok": r.ok,
                        "manifest_hash_ok": r.manifest_hash_ok,
                        "mismatched": r.mismatched_files,
                        "missing": r.missing_files,
                        "extra": r.extra_files,
                        "audit_clean": r.audit_clean,
                    } for r in results
                ],
            })
            if n_ok != len(results):
                raise typer.Exit(code=1)
            return
        for r in results:
            mark = "[green]✓[/green]" if r.ok else "[red]✗[/red]"
            _print(f"  {mark} {r.snapshot_id[:38]}")
            if not r.ok:
                if not r.manifest_hash_ok:
                    _print("      [red]manifest hash mismatch[/red]")
                if r.mismatched_files:
                    _print(f"      [red]mismatched files: "
                           f"{len(r.mismatched_files)}[/red]")
                if r.missing_files:
                    _print(f"      [red]missing files: "
                           f"{len(r.missing_files)}[/red]")
                if not r.audit_clean:
                    _print(f"      [red]staged audit failed: "
                           f"{r.audit_violations[:3]}[/red]")
        _print(f"\n[bold]{n_ok}/{len(results)} snapshots verified clean[/bold]")
        if n_ok != len(results):
            raise typer.Exit(code=1)
        return

    # Single snapshot
    r = backup_mod.verify(snapshot_id, backup_root=backup_root,
                          run_audit=not skip_audit)
    if STATE.json_out:
        _emit_json({
            "ok": r.ok, "snapshot_id": r.snapshot_id,
            "manifest_hash_ok": r.manifest_hash_ok,
            "mismatched": r.mismatched_files,
            "missing": r.missing_files,
            "extra": r.extra_files,
            "audit_clean": r.audit_clean,
            "audit_violations": r.audit_violations,
        })
        if not r.ok:
            raise typer.Exit(code=1)
        return

    if r.ok:
        _print(f"[green]✓ snapshot {r.snapshot_id} verified clean[/green]  "
               f"({r.file_count_found} files)")
    else:
        _print(f"[red]✗ snapshot {r.snapshot_id} FAILED verification[/red]")
        if r.error:
            _print(f"  error: {r.error}")
        if not r.manifest_hash_ok:
            _print("  manifest hash mismatch (tampered or partial write)")
        if r.mismatched_files:
            _print(f"  mismatched: {r.mismatched_files[:5]}")
        if r.missing_files:
            _print(f"  missing: {r.missing_files[:5]}")
        if not r.audit_clean:
            _print(f"  staged audit violations: {r.audit_violations[:5]}")
        raise typer.Exit(code=1)


@backup_app.command("prune")
def backup_prune_cmd(
    dry_run: bool = typer.Option(False, "--dry-run"),
    root: str = typer.Option("", "--root"),
    yes: bool = typer.Option(False, "-y", "--yes"),
) -> None:
    """Apply retention policy: keep all <24h, daily, weekly, monthly,
    plus all labeled snapshots. Always preserves the newest. Tier 2."""
    from . import backup as backup_mod
    from pathlib import Path
    backup_root = Path(root).expanduser() if root else None

    # Dry-run preview first
    preview = backup_mod.prune(backup_root=backup_root, dry_run=True)
    if not preview.removed:
        if STATE.json_out:
            _emit_json({"ok": True, "removed": [], "kept": preview.kept,
                        "bytes_freed": 0, "dry_run": dry_run})
        else:
            _print(f"[dim](nothing to prune; "
                   f"keeping {len(preview.kept)} snapshots)[/dim]")
        return

    if dry_run:
        if STATE.json_out:
            _emit_json({"ok": True, "dry_run": True,
                        "would_remove": preview.removed,
                        "would_keep": preview.kept,
                        "bytes_to_free": preview.bytes_freed})
        else:
            _print(f"[yellow]would remove {len(preview.removed)} snapshots[/yellow] "
                   f"({_format_bytes(preview.bytes_freed)} freed):")
            for sid in preview.removed:
                _print(f"  - {sid}")
        return

    if not yes and not STATE.json_out:
        _print(f"[yellow]about to prune {len(preview.removed)} snapshots[/yellow] "
               f"({_format_bytes(preview.bytes_freed)})")
        if not typer.confirm("Proceed?"):
            _print("[yellow]aborted[/yellow]")
            return

    result = backup_mod.prune(backup_root=backup_root, dry_run=False)
    if STATE.json_out:
        _emit_json({"ok": True, "removed": result.removed,
                    "kept": result.kept,
                    "bytes_freed": result.bytes_freed,
                    "dry_run": False})
    else:
        _print(f"[green]✓[/green] pruned {len(result.removed)} snapshots "
               f"({_format_bytes(result.bytes_freed)} freed); "
               f"{len(result.kept)} kept")


@backup_app.command("restore")
def backup_restore_cmd(
    snapshot_id: str = typer.Argument(..., help="snapshot id (prefix OK)"),
    root: str = typer.Option("", "--root"),
    yes: bool = typer.Option(False, "-y", "--yes",
                              help="skip the Tier 3 confirmation prompt"),
) -> None:
    """Restore from a snapshot. TIER 3 — irreversible swap. The current
    live state is auto-snapshotted with label ``pre-restore-...`` first
    so you can roll the restore itself back."""
    from . import backup as backup_mod
    from pathlib import Path
    backup_root = Path(root).expanduser() if root else None

    # Resolve and show what's being restored.
    try:
        _, manifest = backup_mod._resolve_snapshot(
            snapshot_id, backup_root=backup_root,
        )
    except backup_mod.BackupError as exc:
        _print(f"[red]✗ {exc}[/red]")
        raise typer.Exit(code=1)

    if not yes and not STATE.json_out:
        _print(f"[red]Tier 3 RESTORE[/red]")
        _print(f"  snapshot:    {manifest.snapshot_id}")
        _print(f"  created:     {manifest.created_at}")
        _print(f"  source ver:  {manifest.source_version}")
        _print(f"  atoms:       {manifest.atoms_count}")
        _print(f"  ledger rows: {manifest.financial_ledger_count}")
        _print(f"  audit clean: {manifest.audit_at_snapshot.get('ok', False)}")
        _print()
        _print("This will SWAP your live data dir with the snapshot.")
        _print("Your current live state will be auto-snapshotted first.")
        if not typer.confirm("Proceed?"):
            _print("[yellow]aborted[/yellow]")
            return

    try:
        result = backup_mod.restore(
            snapshot_id, backup_root=backup_root, confirmed=True,
        )
    except backup_mod.RestoreRefusedError as exc:
        if STATE.json_out:
            _emit_json({"ok": False, "error": "refused", "detail": str(exc)})
        else:
            _print(f"[red]✗ restore refused[/red]: {exc}")
        raise typer.Exit(code=1)
    except backup_mod.BackupError as exc:
        if STATE.json_out:
            _emit_json({"ok": False, "error": "backup_error",
                        "detail": str(exc)})
        else:
            _print(f"[red]✗ {exc}[/red]")
        raise typer.Exit(code=1)

    if STATE.json_out:
        _emit_json({
            "ok": True,
            "restored_snapshot_id": result.snapshot_id,
            "pre_restore_snapshot_id": result.pre_restore_snapshot_id,
            "restored_at": result.restored_at,
        })
    else:
        _print(f"[green]✓[/green] restored from {result.snapshot_id}")
        _print(f"  pre-restore snapshot of prior live state: "
               f"[cyan]{result.pre_restore_snapshot_id}[/cyan]")
        _print("  [yellow]restart any running sovereign processes "
               "to pick up the new state[/yellow]")


@backup_app.command("status")
def backup_status_cmd(
    root: str = typer.Option("", "--root"),
) -> None:
    """Single-screen view of the backup state. Tier 0."""
    from . import backup as backup_mod
    from pathlib import Path
    backup_root = Path(root).expanduser() if root else None
    s = backup_mod.status(backup_root=backup_root)

    if STATE.json_out:
        _emit_json({
            "ok": True,
            "backup_root": s.backup_root,
            "snapshot_count": s.snapshot_count,
            "total_bytes": s.total_bytes,
            "most_recent_snapshot_id": s.most_recent_snapshot_id,
            "most_recent_age_seconds": s.most_recent_age_seconds,
            "oldest_snapshot_id": s.oldest_snapshot_id,
            "last_verify_ok": s.last_verify_ok,
        })
        return

    _print("═══ backup status ═══")
    _print(f"  root:        {s.backup_root}")
    _print(f"  snapshots:   {s.snapshot_count}")
    _print(f"  total size:  {_format_bytes(s.total_bytes)}")
    if s.most_recent_snapshot_id:
        age_color = (
            "green" if s.most_recent_age_seconds and
            s.most_recent_age_seconds < 86400 * 7 else "yellow"
        )
        _print(f"  most recent: {s.most_recent_snapshot_id}")
        _print(f"  age:         "
               f"[{age_color}]{_format_age(s.most_recent_age_seconds)}[/{age_color}]")
        verify_color = "green" if s.last_verify_ok else "red"
        verify_mark = "✓" if s.last_verify_ok else "✗"
        _print(f"  verify:      "
               f"[{verify_color}]{verify_mark}[/{verify_color}]")
    else:
        _print("  [yellow]no snapshots yet — run 'sovereign backup snapshot'"
               "[/yellow]")


app.add_typer(backup_app, name="backup")


# ─── Horizon sub-app ───────────────────────────────────────────────────────


@app.command()
def horizon(
    label: str = typer.Argument(..., help="short title"),
    decision: str = typer.Option(..., "--decision", "-d",
                                  help="what is being decided"),
    three_month: str = typer.Option("", "--3m"),
    twelve_month: str = typer.Option("", "--12m"),
    three_year: str = typer.Option("", "--3y"),
    seventh: str = typer.Option("", "--7g",
                                 help="7th-generation concern"),
    best_path: str = typer.Option("", "--best-path"),
    save: bool = typer.Option(False, "--save",
                               help="save through appendix system"),
) -> None:
    """Generate a MOS Horizon Scan markdown."""
    from .horizon import HorizonInputs, render, save_through_appendix

    inputs = HorizonInputs(
        label=label, decision=decision,
        three_month=three_month, twelve_month=twelve_month,
        three_year=three_year, seventh_generation=seventh,
        best_forward_path=best_path,
    )

    if save:
        from .db import open_atoms_db
        from . import mem_channels  # noqa: F401
        appendix_dir = SETTINGS.paths.data_dir / "appendix"
        conn = open_atoms_db()
        try:
            doc = save_through_appendix(
                conn, appendix_dir=appendix_dir, inputs=inputs,
            )
        finally:
            conn.close()
        if STATE.json_out:
            _emit_json({"ok": True, "doc_id": doc.doc_id,
                        "file_path": doc.file_path})
        else:
            _print(f"[green]✓[/green] saved horizon scan: {doc.file_path}")
        return

    text = render(inputs)
    if STATE.json_out:
        _emit_json({"ok": True, "markdown": text})
    else:
        _print(text)


# ─── Appendix sub-app ──────────────────────────────────────────────────────


appendix_app = typer.Typer(
    help="◈ markdown documents attached to atoms (v0.2.14)",
)
app.add_typer(appendix_app, name="appendix")


@appendix_app.command("list")
def appendix_list_cmd(
    kind: str = typer.Option("", "--kind",
                              help="filter: plan|note|insight|intuition|horizon"),
    limit: int = typer.Option(20, "--limit", "-n"),
) -> None:
    """List recent appendix documents."""
    from . import mem_channels  # noqa: F401
    from .appendix import list_recent
    from .db import open_atoms_db

    conn = open_atoms_db()
    try:
        from .appendix import ensure_appendix_schema
        ensure_appendix_schema(conn)
        docs = list_recent(conn, kind=kind or None, limit=limit)
    finally:
        conn.close()

    if STATE.json_out:
        _emit_json({"ok": True, "count": len(docs),
                    "docs": [d.__dict__ for d in docs]})
        return

    if not docs:
        _print("[dim]no appendix documents yet[/dim]")
        return

    t = Table(title="◈ appendix documents", box=None)
    t.add_column("ID", style="dim", no_wrap=True)
    t.add_column("Kind", style="cyan", no_wrap=True)
    t.add_column("Title")
    t.add_column("Created", style="dim", no_wrap=True)
    for d in docs:
        t.add_row(d.doc_id[:18] + "…", d.kind, d.title[:50],
                  d.created_at[:19])
    _print(t)


@appendix_app.command("show")
def appendix_show_cmd(
    doc_id: str = typer.Argument(..., help="appendix doc id"),
) -> None:
    """Show one appendix document's body."""
    from . import mem_channels  # noqa: F401
    from .appendix import ensure_appendix_schema, get_doc, read_body
    from .db import open_atoms_db

    conn = open_atoms_db()
    try:
        ensure_appendix_schema(conn)
        doc = get_doc(conn, doc_id)
        if doc is None:
            _print(f"[red]not found: {doc_id}[/red]")
            raise typer.Exit(code=1)
        body = read_body(doc)
    finally:
        conn.close()

    if STATE.json_out:
        _emit_json({"ok": True, "doc": doc.__dict__, "body": body})
        return

    _print(Panel(
        body or "[dim](body file not found)[/dim]",
        title=f"◈ {doc.kind}: {doc.title}",
        border_style="cyan",
    ))


@appendix_app.command("add")
def appendix_add_cmd(
    title: str = typer.Argument(..., help="document title"),
    kind: str = typer.Option("note", "--kind",
                              help="plan|note|insight|intuition|horizon|other"),
    body_file: str = typer.Option("", "--body-file",
                                   help="read body from this file"),
    body: str = typer.Option("", "--body", help="body text inline"),
    atom_id: str = typer.Option("", "--atom-id",
                                 help="attach to this atom"),
) -> None:
    """Create a new appendix document."""
    from . import mem_channels  # noqa: F401
    from .appendix import write_doc
    from .db import open_atoms_db

    if body_file:
        body = Path(body_file).read_text(encoding="utf-8")
    if not body:
        _print("[red]must supply --body or --body-file[/red]")
        raise typer.Exit(code=1)

    appendix_dir = SETTINGS.paths.data_dir / "appendix"
    conn = open_atoms_db()
    try:
        doc = write_doc(
            conn, appendix_dir=appendix_dir, kind=kind, title=title,
            body=body, atom_id=atom_id or None, created_by="operator",
        )
    finally:
        conn.close()

    if STATE.json_out:
        _emit_json({"ok": True, "doc_id": doc.doc_id,
                    "file_path": doc.file_path})
    else:
        _print(f"[green]✓[/green] {doc.kind}: {doc.title}  →  {doc.file_path}")


if __name__ == "__main__":
    app()
