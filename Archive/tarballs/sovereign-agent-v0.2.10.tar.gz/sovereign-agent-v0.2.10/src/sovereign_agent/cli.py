"""
╔══════════════════════════════════════════════════════════════════════════╗
║  cli.py — Operator surface (v0.2.5)                                      ║
║  Architecture §5 + §7a + §8a + §11 + §13                                 ║
╚══════════════════════════════════════════════════════════════════════════╝

The CLI is how YOU (the operator) talk to the agent. The agent doesn't
use it. Commands are grouped by purpose:

    Setup:        init       — bootstrap config dirs, secret key, DBs
                  doctor     — diagnose config + ollama reachability + models
                  config     — show resolved configuration
    Run:          run        — single ONESHOT task
                  busy       — drain backlog forever (or once / N times)
                  until      — drain until predicate
    Re-trigger:   plan       — pre-decompose a large task into atomic steps
                  continue   — execute ONE pending step from a continuation
                  continuations — list / show / delete continuation files
    Backlog:      backlog    — list / add / remove / show / requeue / clear
    Approvals:    approvals  — list pending Tier 3 requests
                  approve    — grant a request
                  deny       — refuse a request
    Safety:       halt       — trip PROTOCOL-ZERO
                  disarm     — clear PROTOCOL-ZERO (after review)
    Audit:        tail       — ingest events.jsonl into events.db
                  seal       — compute yesterday's Merkle root
                  verify     — verify a past seal still matches its events
                  events     — show recent events (with --follow)
                  lessons    — show recent distilled lessons

Exit codes are stable and documented:
    0  success
    1  generic runtime error
    2  usage error
    3  PROTOCOL-ZERO armed (refused start)
    4  not initialized (run `sovereign init`)
    5  ollama unreachable
    6  approval not found / already resolved
    7  budget exhausted (when applicable)
    8  continuation drained (used by `continue` and the loop driver)
    9  continuation locked by another process

Top-level flags (apply to every command):
    --version
    --json / -j         emit JSON for read commands
    --quiet / -q        suppress non-essential output
    --verbose / -v      log INFO / DEBUG to stderr
    --no-color          disable Rich color (implied when not a TTY)
    --config-dir PATH   override XDG config dir
    --data-dir PATH     override XDG data dir
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import structlog
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from . import __version__, protocol_zero
from .config import SETTINGS, Paths
from .events import init_events_db, tail_to_sqlite
from .modes import Mode, RunBudget


# ─── Exit codes (single source of truth) ────────────────────────────────────


class ExitCode:
    OK = 0
    ERROR = 1
    USAGE = 2
    HALTED = 3
    NOT_INITIALIZED = 4
    OLLAMA_UNREACHABLE = 5
    APPROVAL_NOT_FOUND = 6
    BUDGET = 7
    DRAINED = 8
    LOCKED = 9


# ─── Global state set by the top-level callback ─────────────────────────────


class _CliState:
    json_out: bool = False
    quiet: bool = False
    verbose: bool = False
    no_color: bool = False


STATE = _CliState()
console = Console()


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(level=level, stream=sys.stderr, format="%(message)s")
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.dev.ConsoleRenderer(colors=not STATE.no_color),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
    )


def _override_paths(*, config_dir: Path | None, data_dir: Path | None) -> None:
    """Mutate SETTINGS.paths in place. Same trick as conftest."""
    if config_dir is None and data_dir is None:
        return
    new_paths = Paths(
        config_dir=config_dir or SETTINGS.paths.config_dir,
        data_dir=data_dir or SETTINGS.paths.data_dir,
    )
    object.__setattr__(SETTINGS, "paths", new_paths)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"sovereign-agent {__version__}")
        raise typer.Exit(ExitCode.OK)


app = typer.Typer(
    no_args_is_help=True,
    add_completion=True,
    rich_markup_mode="rich",
    help="◈ sovereign-agent — your local 24/7 agent",
    pretty_exceptions_show_locals=False,
)


@app.callback()
def _global_options(
    version: bool = typer.Option(
        False, "--version", callback=_version_callback, is_eager=True,
        help="Show version and exit.",
    ),
    json_out: bool = typer.Option(False, "--json", "-j", help="Emit JSON for read commands."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress non-essential output."),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Log INFO/DEBUG to stderr."),
    no_color: bool = typer.Option(False, "--no-color", help="Disable color output."),
    config_dir: Path | None = typer.Option(None, "--config-dir", help="Override XDG config dir."),
    data_dir: Path | None = typer.Option(None, "--data-dir", help="Override XDG data dir."),
) -> None:
    """Global options. Apply to every subcommand."""
    STATE.json_out = json_out
    STATE.quiet = quiet
    STATE.verbose = verbose
    STATE.no_color = no_color or not sys.stdout.isatty()
    if STATE.no_color:
        global console
        console = Console(no_color=True, force_terminal=False)
    _override_paths(config_dir=config_dir, data_dir=data_dir)
    _setup_logging(verbose)


# ─── Output helpers ─────────────────────────────────────────────────────────


def _print(*args: Any, **kwargs: Any) -> None:
    if STATE.quiet:
        return
    console.print(*args, **kwargs)


def _emit_json(payload: Any) -> None:
    typer.echo(json.dumps(payload, default=str, indent=2 if sys.stdout.isatty() else None))


def _die(code: int, message: str, *, hint: str | None = None) -> None:
    if STATE.json_out:
        payload = {"ok": False, "code": code, "error": message}
        if hint:
            payload["hint"] = hint
        _emit_json(payload)
    else:
        console.print(f"[red]✗ {message}[/red]")
        if hint:
            console.print(f"[dim]hint: {hint}[/dim]")
    raise typer.Exit(code)


# ─── Pre-flight checks ──────────────────────────────────────────────────────


def _preflight_initialized() -> None:
    if not SETTINGS.paths.secret_key_file.exists():
        _die(ExitCode.NOT_INITIALIZED, "agent is not initialized",
             hint="run `sovereign init` first")


def _preflight_not_halted() -> None:
    if SETTINGS.paths.halt_flag.exists() or protocol_zero.is_armed():
        _die(ExitCode.HALTED, "PROTOCOL-ZERO is armed",
             hint="review HALT file, then `sovereign disarm`")


def _preflight_ollama_reachable(*, fatal: bool = True) -> bool:
    import socket
    from urllib.parse import urlparse

    parsed = urlparse(SETTINGS.ollama_host)
    host = parsed.hostname or "localhost"
    port = parsed.port or 11434
    try:
        with socket.create_connection((host, port), timeout=3):
            return True
    except (OSError, socket.timeout) as e:
        if fatal:
            _die(ExitCode.OLLAMA_UNREACHABLE,
                 f"ollama unreachable at {host}:{port}: {e}",
                 hint="start ollama, or set OLLAMA_HOST")
        return False


# ─── Banner ─────────────────────────────────────────────────────────────────


BANNER = """[bold cyan]
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║              ◈  S O V E R E I G N   A G E N T  ◈                     ║
║                                                                      ║
║       local · authority-tiered · audited · recoverable · yours       ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
[/bold cyan]"""


def _build_tools_for_mode(mode: Mode) -> dict:
    from .tools import (
        CopyFileTool, EditFileTool, EmbedQueryTool, ImageCaptionTool,
        ImpactScoreTool, ListDirTool, MemorySearchTool, MemoryWriteTool,
        PalaceSearchTool, ProposalWriteTool, ReadFileTool, SearchTextTool,
        WebFetchTool, WebSearchTool, WriteFileTool, internet_available,
    )
    tools = {
        "read_file": ReadFileTool(),
        "list_dir": ListDirTool(),
        "search_text": SearchTextTool(),
        "embed_query": EmbedQueryTool(),
        "image_caption": ImageCaptionTool(),
        "web_fetch": WebFetchTool(),
        "memory_search": MemorySearchTool(),
        "memory_write": MemoryWriteTool(),
        "palace_search": PalaceSearchTool(),
        "proposal_write": ProposalWriteTool(),
        "impact_score": ImpactScoreTool(),
        "write_file": WriteFileTool(mode=mode),
        "edit_file": EditFileTool(mode=mode),
        "copy_file": CopyFileTool(mode=mode),
    }
    if internet_available():
        tools["web_search"] = WebSearchTool()
    return tools


# ═══════════════════════════════════════════════════════════════════════════
#  SETUP
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def init() -> None:
    """Bootstrap config dirs, generate secret key, initialize DBs."""
    if not STATE.json_out:
        _print(BANNER)
        _print("[bold]Initializing sovereign-agent...[/bold]\n")

    SETTINGS.paths.ensure()
    from .approval import _load_or_create_secret  # noqa: WPS437
    _load_or_create_secret()

    conn_e = init_events_db()
    conn_e.close()
    from .db import open_atoms_db
    conn_a = open_atoms_db()
    conn_a.close()

    if STATE.json_out:
        _emit_json({
            "ok": True,
            "config_dir": str(SETTINGS.paths.config_dir),
            "data_dir": str(SETTINGS.paths.data_dir),
            "sandbox": str(SETTINGS.paths.sandbox_dir),
            "events": str(SETTINGS.paths.events_dir),
            "atoms_db": str(SETTINGS.paths.atoms_db),
            "continuations": str(SETTINGS.paths.continuations_dir),
            "palace_db": str(SETTINGS.paths.palace_db),
            "proposals_dir": str(SETTINGS.paths.proposals_dir),
        })
        return

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column(style="dim")
    table.add_column()
    table.add_row("config dir", str(SETTINGS.paths.config_dir))
    table.add_row("data dir", str(SETTINGS.paths.data_dir))
    table.add_row("sandbox", str(SETTINGS.paths.sandbox_dir))
    table.add_row("events", str(SETTINGS.paths.events_dir))
    table.add_row("atoms.db", str(SETTINGS.paths.atoms_db))
    table.add_row("continuations", str(SETTINGS.paths.continuations_dir))
    table.add_row("palace.db", str(SETTINGS.paths.palace_db))
    table.add_row("proposals", str(SETTINGS.paths.proposals_dir))
    table.add_row("secret key", "[green]created[/green] (mode 0600)")
    _print(Panel(table, title="◈ initialized", border_style="green"))


@app.command()
def doctor() -> None:
    """Diagnose the agent's environment: paths, models, Ollama, VRAM, locks."""
    import shutil
    import socket
    from urllib.parse import urlparse

    if not STATE.json_out:
        _print(BANNER)
        _print("[bold]Running diagnostics...[/bold]\n")

    rows: list[dict[str, str]] = []

    def add(name: str, status: str, detail: str = "") -> None:
        rows.append({"check": name, "status": status, "detail": detail})

    for label, path in [
        ("config_dir", SETTINGS.paths.config_dir),
        ("data_dir", SETTINGS.paths.data_dir),
        ("sandbox_dir", SETTINGS.paths.sandbox_dir),
        ("events_dir", SETTINGS.paths.events_dir),
        ("atoms.db", SETTINGS.paths.atoms_db),
        ("secret.key", SETTINGS.paths.secret_key_file),
        ("continuations", SETTINGS.paths.continuations_dir),
    ]:
        add(label, "PASS" if path.exists() else "WARN",
            str(path) if path.exists() else f"{path} (run `sovereign init`)")

    if SETTINGS.paths.secret_key_file.exists():
        mode = SETTINGS.paths.secret_key_file.stat().st_mode & 0o777
        if mode == 0o600:
            add("secret mode", "PASS", "0600 (owner read-only)")
        else:
            add("secret mode", "FAIL", f"mode {oct(mode)} — should be 0600")

    add("orchestrator", "PASS", SETTINGS.orchestrator_model)
    add("coder", "PASS", SETTINGS.coder_model)
    add("embedder", "PASS", SETTINGS.embed_model)
    add("reflector", "PASS", SETTINGS.reflector_model)

    parsed = urlparse(SETTINGS.ollama_host)
    host = parsed.hostname or "localhost"
    port = parsed.port or 11434
    ollama_up = False
    try:
        with socket.create_connection((host, port), timeout=2):
            add("ollama tcp", "PASS", f"{host}:{port}")
            ollama_up = True
    except (OSError, socket.timeout) as e:
        add("ollama tcp", "FAIL", f"{host}:{port} unreachable: {e}")

    if ollama_up:
        try:
            import httpx
            r = httpx.get(f"{SETTINGS.ollama_host}/api/tags", timeout=5)
            r.raise_for_status()
            installed = {m["name"] for m in r.json().get("models", [])}
            for label, name in [
                ("orchestrator model", SETTINGS.orchestrator_model),
                ("embedder model", SETTINGS.embed_model),
                ("reflector model", SETTINGS.reflector_model),
            ]:
                if name in installed or any(n.startswith(name + ":") for n in installed):
                    add(label, "PASS", "found")
                else:
                    add(label, "FAIL", f"{name!r} not installed (try `ollama pull {name}`)")

            try:
                from .ollama_client import OllamaClient

                async def _probe():
                    cli = OllamaClient()
                    return {
                        "orchestrator": await cli.supports_thinking(SETTINGS.orchestrator_model),
                        "reflector": await cli.supports_thinking(SETTINGS.reflector_model),
                    }
                caps = asyncio.run(_probe())
                for label, key in [("orch thinking", "orchestrator"), ("reflector thinking", "reflector")]:
                    add(label, "PASS" if caps[key] else "WARN",
                        "supported" if caps[key] else "NOT supported (auto-disabled)")
            except Exception as e:  # noqa: BLE001
                add("capabilities", "WARN", f"could not probe: {e}")
        except Exception as e:  # noqa: BLE001
            add("ollama models", "WARN", f"could not query: {e}")

    if shutil.which("bwrap"):
        add("bubblewrap", "PASS", shutil.which("bwrap"))
    else:
        add("bubblewrap", "FAIL", "not installed — `apt install bubblewrap`")

    if SETTINGS.paths.halt_flag.exists():
        add("protocol-zero", "WARN", "ARMED — `sovereign disarm`")
    else:
        add("protocol-zero", "PASS", "clear")

    # Internet (v0.2.7+) — informational; not a failure when off.
    from .tools import internet_available, reset_internet_cache
    reset_internet_cache()  # fresh probe each doctor run
    setting = os.environ.get("AGENT_INTERNET", "auto").lower()
    if internet_available():
        add("internet", "PASS", f"available (AGENT_INTERNET={setting})")
    else:
        add("internet", "WARN",
            f"unavailable (AGENT_INTERNET={setting}) — web_search disabled")

    try:
        from .vram import read_vram
        snap = read_vram()
        add("vram", "PASS", f"{snap.free_mb} MB free / {snap.total_mb} MB total ({snap.source})")
    except Exception as e:  # noqa: BLE001
        add("vram", "WARN", f"could not read: {e}")

    if STATE.json_out:
        n_fail = sum(1 for r in rows if r["status"] == "FAIL")
        _emit_json({"ok": n_fail == 0, "checks": rows, "fail_count": n_fail})
        return

    table = Table(title="◈ doctor", show_header=True, header_style="bold cyan")
    table.add_column("check", style="dim", width=22)
    table.add_column("status", width=8)
    table.add_column("detail", overflow="fold")
    for r in rows:
        color = {"PASS": "green", "WARN": "yellow", "FAIL": "red"}.get(r["status"], "white")
        table.add_row(r["check"], f"[{color}]{r['status']}[/{color}]", r["detail"])
    _print(table)


@app.command(name="config")
def show_config() -> None:
    """Print the resolved configuration with effective values."""
    payload = {
        "version": __version__,
        "paths": {
            "config_dir": str(SETTINGS.paths.config_dir),
            "data_dir": str(SETTINGS.paths.data_dir),
            "sandbox_dir": str(SETTINGS.paths.sandbox_dir),
            "events_dir": str(SETTINGS.paths.events_dir),
            "atoms_db": str(SETTINGS.paths.atoms_db),
            "continuations_dir": str(SETTINGS.paths.continuations_dir),
            "palace_db": str(SETTINGS.paths.palace_db),
            "proposals_dir": str(SETTINGS.paths.proposals_dir),
            "backlog_yaml": str(SETTINGS.paths.backlog_yaml),
        },
        "models": {
            "orchestrator": SETTINGS.orchestrator_model,
            "coder": SETTINGS.coder_model,
            "embedder": SETTINGS.embed_model,
            "reflector": SETTINGS.reflector_model,
            "fast": SETTINGS.fast_model,
        },
        "ollama_host": SETTINGS.ollama_host,
        "think_mode": SETTINGS.think_mode,
        "num_ctx": SETTINGS.num_ctx,
        "approval_default_expiry_seconds": SETTINGS.approval_default_expiry_seconds,
        "env_overrides": {
            k: os.environ.get(k) for k in (
                "OLLAMA_HOST", "AGENT_ORCHESTRATOR_MODEL", "AGENT_CODER_MODEL",
                "AGENT_EMBED_MODEL", "AGENT_REFLECTOR_MODEL", "AGENT_FAST_MODEL",
                "AGENT_THINK",
            ) if os.environ.get(k) is not None
        },
    }

    if STATE.json_out:
        _emit_json(payload)
        return

    table = Table(title="◈ config", show_header=False, box=None, padding=(0, 1))
    table.add_column(style="dim")
    table.add_column()
    table.add_row("version", payload["version"])
    table.add_row("ollama_host", payload["ollama_host"])
    table.add_row("think_mode", payload["think_mode"])
    table.add_row("num_ctx", str(payload["num_ctx"]))
    table.add_row("orchestrator", payload["models"]["orchestrator"])
    table.add_row("coder", payload["models"]["coder"])
    table.add_row("embedder", payload["models"]["embedder"])
    table.add_row("reflector", payload["models"]["reflector"])
    table.add_row("fast", payload["models"]["fast"])
    for k, v in payload["paths"].items():
        table.add_row(f"path.{k}", v)
    if payload["env_overrides"]:
        for k, v in payload["env_overrides"].items():
            table.add_row(f"env.{k}", v)
    _print(table)


# ═══════════════════════════════════════════════════════════════════════════
#  RUN
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def run(
    goal: str = typer.Argument(..., help="What you want the agent to accomplish"),
    mode: Mode = typer.Option(Mode.ONESHOT, "--mode"),
    max_iterations: int = typer.Option(25, "--max-iter"),
    max_wall_seconds: int = typer.Option(1800, "--max-wall"),
    max_tokens: int = typer.Option(200_000, "--max-tokens"),
    dry_run: bool = typer.Option(False, "--dry-run",
        help="Show resolved tools, mode, and budget without invoking the model."),
) -> None:
    """Run a single task through the agent loop."""
    _preflight_initialized()
    if not dry_run:
        _preflight_not_halted()
        _preflight_ollama_reachable()

    from .loop import agent_loop

    protocol_zero.install_signal_handlers()
    tools = _build_tools_for_mode(mode)
    budget = RunBudget(max_iterations=max_iterations,
                      max_wall_seconds=max_wall_seconds, max_tokens=max_tokens)

    if dry_run:
        from .authority import tools_available_in_mode
        from .modes import MODE_TIER_CEILING
        available = sorted(m.name for m in tools_available_in_mode(mode))
        payload = {
            "ok": True, "dry_run": True, "goal": goal, "mode": mode.value,
            "tier_ceiling": MODE_TIER_CEILING[mode],
            "available_tools": available,
            "budget": {
                "max_iterations": budget.max_iterations,
                "max_wall_seconds": budget.max_wall_seconds,
                "max_tokens": budget.max_tokens,
            },
        }
        if STATE.json_out:
            _emit_json(payload)
        else:
            table = Table(title=f"◈ dry-run · {mode.value}")
            table.add_column("field", style="dim")
            table.add_column("value", overflow="fold")
            table.add_row("goal", goal)
            table.add_row("mode", mode.value)
            table.add_row("tier_ceiling", str(payload["tier_ceiling"]))
            table.add_row("tools", ", ".join(available))
            table.add_row("budget.iter", str(budget.max_iterations))
            table.add_row("budget.wall", f"{budget.max_wall_seconds}s")
            table.add_row("budget.tokens", str(budget.max_tokens))
            _print(table)
        raise typer.Exit(ExitCode.OK)

    _print(f"\n◈ [bold]{mode.value}[/bold] · {goal[:80]}\n")
    result = asyncio.run(agent_loop(goal=goal, mode=mode, budget=budget, tools=tools))

    if STATE.json_out:
        _emit_json({
            "ok": result.ok, "reason": result.reason,
            "iterations": result.iterations, "tokens": result.tokens_used,
            "lesson_id": result.lesson_id, "final_message": result.final_message,
        })
    else:
        color = "green" if result.ok else "yellow"
        _print(Panel(
            f"[bold]{result.reason}[/bold]\n"
            f"iterations: {result.iterations}  ·  tokens: {result.tokens_used}\n"
            f"lesson: {result.lesson_id or '(none)'}",
            title="◈ result", border_style=color,
        ))
        if result.final_message:
            _print("\n" + result.final_message)
    raise typer.Exit(ExitCode.OK if result.ok else ExitCode.ERROR)


@app.command()
def busy(
    cooldown: float = typer.Option(5.0, "--cooldown", help="Seconds between tasks"),
    empty_sleep: float = typer.Option(30.0, "--empty-sleep", help="Sleep when backlog empty"),
    max_iter_per_task: int = typer.Option(25, "--max-iter"),
    max_wall_per_task: int = typer.Option(1800, "--max-wall"),
    once: bool = typer.Option(False, "--once", help="Drain one task then exit (cron-friendly)."),
    max_tasks: int = typer.Option(0, "--max-tasks", help="At most N tasks then exit (0=unbounded)."),
) -> None:
    """Drain the backlog. PROTOCOL-ZERO is the only stop signal in unbounded mode."""
    _preflight_initialized()
    _preflight_not_halted()
    _preflight_ollama_reachable()

    from .mode_controller import ControllerSettings, ModeController

    _print(BANNER)
    _print(Panel(
        "[bold yellow]BUSY mode[/bold yellow] — Tier 0 + Tier 1 only.\n"
        "Tier 2 and Tier 3 are not in the agent's tool list.\n"
        "Stop with: [cyan]sovereign halt[/cyan]  or  [cyan]echo > ~/.config/sovereign-agent/HALT[/cyan]",
        border_style="yellow",
    ))

    tools = _build_tools_for_mode(Mode.BUSY)
    settings = ControllerSettings(
        cooldown_seconds=cooldown, empty_backlog_sleep=empty_sleep,
        per_task_budget=RunBudget(max_iterations=max_iter_per_task,
                                  max_wall_seconds=max_wall_per_task),
    )
    controller = ModeController(tools=tools, settings=settings)
    try:
        if once:
            asyncio.run(controller._drain_iteration())
        elif max_tasks > 0:
            async def _bounded() -> None:
                count = 0
                while count < max_tasks and not protocol_zero.is_armed():
                    ran = await controller._drain_iteration()
                    if ran:
                        count += 1
                        await asyncio.sleep(cooldown)
                    else:
                        await asyncio.sleep(empty_sleep)
            asyncio.run(_bounded())
        else:
            asyncio.run(controller.run_busy())
    except KeyboardInterrupt:
        _print("\n[yellow]interrupted[/yellow]")
    _print("[green]busy mode stopped[/green]")


@app.command()
def until(
    minutes: int = typer.Option(..., "--minutes", help="Stop after this many minutes"),
    mode: Mode = typer.Option(Mode.ONESHOT, "--mode"),
) -> None:
    """Drain backlog until a time limit is reached."""
    _preflight_initialized()
    _preflight_not_halted()
    _preflight_ollama_reachable()

    from .mode_controller import ModeController

    end_ts = time.time() + minutes * 60
    tools = _build_tools_for_mode(mode)
    controller = ModeController(tools=tools)

    def _done() -> bool:
        return time.time() >= end_ts

    _print(f"\n◈ [bold]until[/bold] · stopping in {minutes} minutes\n")
    asyncio.run(controller.run_until(_done))


# ═══════════════════════════════════════════════════════════════════════════
#  RE-TRIGGER ARCHITECTURE — plan / continue / continuations
# ═══════════════════════════════════════════════════════════════════════════


plan_app = typer.Typer(help="◈ pre-decompose a large task into atomic continuation steps")


@app.command(name="plan")
def plan_cmd(
    planner: str | None = typer.Argument(None, help="Planner name (omit to list)."),
    root: Path | None = typer.Option(None, "--root", help="Root path the planner walks."),
    output: Path | None = typer.Option(None, "--output", help="Aggregation output."),
    pattern: list[str] = typer.Option([], "--pattern", help="Glob pattern. Repeatable."),
    exclude: list[str] = typer.Option(
        [], "--exclude",
        help="Glob pattern to exclude files (matched against full path). Repeatable. (v0.2.6)",
    ),
    include: list[str] = typer.Option(
        [], "--include",
        help="Glob pattern whitelist (image-inventory only). Repeatable. (v0.2.6)",
    ),
    include_no_ext: bool = typer.Option(
        False, "--include-no-extension",
        help="Also include files with no extension (LICENSE, transcripts). (v0.2.6)",
    ),
    max_files: int = typer.Option(0, "--max-files", help="Cap step count (0=unbounded)."),
    no_recursive: bool = typer.Option(False, "--no-recursive", help="Don't walk subdirs."),
    tag: str | None = typer.Option(None, "--tag", help="Tag (read-files planner)."),
    max_extract_chars: int = typer.Option(
        40_000, "--max-extract-chars",
        help="Per-file extraction cap (pdf-inventory). (v0.2.6)",
    ),
    max_file_size: int = typer.Option(
        0, "--max-file-size",
        help="Skip files larger than N bytes (0=use planner default). (v0.2.6)",
    ),
    room_id: str | None = typer.Option(
        None, "--room-id",
        help="Palace room id (palace-mine planner). (v0.2.8)",
    ),
    room_name: str | None = typer.Option(
        None, "--room-name",
        help="Palace room display name (palace-mine planner). (v0.2.8)",
    ),
    atom_type: str | None = typer.Option(
        None, "--atom-type",
        help="Filter atoms by type (palace-mine planner). (v0.2.8)",
    ),
    task_id: str | None = typer.Option(None, "--task-id", help="Override generated ULID."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show the plan, don't write."),
) -> None:
    """Run a planner. With no planner name, lists available planners."""
    from .planners import REGISTRY, get_planner
    from .planners.base import PlannerError, PlannerNotFound
    from .continuation import ContinuationStore

    if planner is None:
        if STATE.json_out:
            _emit_json({"planners": [
                {"name": p.name, "description": p.description,
                 "required_args": list(p.required_args())}
                for p in REGISTRY.values()
            ]})
            return
        table = Table(title="◈ planners", show_header=True, header_style="bold cyan")
        table.add_column("name", style="cyan")
        table.add_column("required args", style="magenta")
        table.add_column("description")
        for p in REGISTRY.values():
            table.add_row(p.name, ", ".join(p.required_args()) or "—", p.description)
        _print(table)
        _print("\n[dim]Run a planner: [/dim][cyan]sovereign plan inventory --root <dir> --output <file>[/cyan]")
        return

    try:
        planner_obj = get_planner(planner)
    except PlannerNotFound as e:
        _die(ExitCode.USAGE, str(e), hint="run `sovereign plan` to list planners")

    args = {
        "root": str(root) if root else None,
        "output": str(output) if output else None,
        "patterns": pattern or None,
        "exclude": exclude or None,
        "include": include or None,
        "include_no_extension": include_no_ext if include_no_ext else None,
        "max_files": max_files,
        "recursive": not no_recursive,
        "tag": tag,
        "max_extract_chars": max_extract_chars if max_extract_chars != 40_000 else None,
        "max_file_size_bytes": max_file_size if max_file_size > 0 else None,
        "room_id": room_id,
        "room_name": room_name,
        "atom_type": atom_type,
    }
    args = {k: v for k, v in args.items() if v is not None}

    try:
        result = planner_obj.plan(**args)
    except PlannerError as e:
        _die(ExitCode.USAGE, f"plan failed: {e}")

    if dry_run:
        payload = {
            "ok": True, "dry_run": True, "planner": planner,
            "goal": result.goal, "step_count": len(result.steps),
            "output_path": result.output_path,
            "first_steps": [{"id": s.id, "kind": s.kind, "args": s.args}
                           for s in result.steps[:5]],
        }
        if STATE.json_out:
            _emit_json(payload)
        else:
            _print(Panel(
                f"[bold]{result.goal}[/bold]\n"
                f"steps: {len(result.steps)}\n"
                f"output: {result.output_path or '(none)'}\n"
                f"notes: {result.notes}",
                title=f"◈ plan (dry-run) · {planner}", border_style="cyan",
            ))
            if result.steps:
                t = Table(title="first 5 steps", show_header=True)
                t.add_column("id", style="dim")
                t.add_column("kind")
                t.add_column("args", overflow="fold")
                for s in result.steps[:5]:
                    t.add_row(str(s.id), s.kind, json.dumps(s.args, default=str)[:120])
                _print(t)
        return

    _preflight_initialized()
    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    cont = store.create(
        goal=result.goal, planner=planner, planner_args=args,
        steps=result.steps, output_path=result.output_path,
        task_id=task_id, notes=result.notes,
    )

    if STATE.json_out:
        _emit_json({"ok": True, "task_id": cont.task_id,
                    "step_count": len(cont.steps), "goal": cont.goal,
                    "output_path": cont.output_path})
    else:
        _print(Panel(
            f"[bold]{cont.goal}[/bold]\n"
            f"task_id: [cyan]{cont.task_id}[/cyan]\n"
            f"steps: {len(cont.steps)}\n"
            f"output: {cont.output_path or '(none)'}\n\n"
            f"[dim]drive it:[/dim] [cyan]sovereign continue {cont.task_id}[/cyan]\n"
            f"[dim]or loop:[/dim]  [cyan]scripts/sovereign-continue-loop.sh {cont.task_id}[/cyan]",
            title="◈ continuation created", border_style="green",
        ))


@app.command(name="continue")
def continue_(
    task_id: str = typer.Argument(..., help="Continuation ID from `sovereign plan`"),
    max_iter: int = typer.Option(5, "--max-iter", help="Per-step iteration cap."),
    max_wall: int = typer.Option(120, "--max-wall", help="Per-step wall-time cap (seconds)."),
    max_tokens: int = typer.Option(20_000, "--max-tokens", help="Per-step token cap."),
    model_filter: str | None = typer.Option(
        None, "--model-filter",
        help="Only run steps requiring this model (orchestrator/coder/vision/none). (v0.2.6)",
    ),
) -> None:
    """Execute exactly ONE pending step from a continuation, then exit.

    Exit codes: 0 step OK · 1 step poison · 3 halted · 8 drained · 9 locked

    With ``--model-filter X``, only run a step whose ``required_model == X``.
    Other steps stay pending. Use this to batch by model affinity:

        sovereign continue <id> --model-filter orchestrator
        sovereign continue <id> --model-filter vision

    Or use the higher-level ``sovereign drain-by-model <id>`` which sequences
    phases automatically.
    """
    _preflight_initialized()
    _preflight_not_halted()

    # Pre-flight Ollama only if this continuation has steps that need a model.
    # palace-mine and metadata-inventory continuations are pure-Python; they
    # shouldn't refuse to start just because Ollama is down. v0.2.8.
    from .continuation import ContinuationStore
    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    needs_model = False
    try:
        cont_preview = store.get(task_id)
        models = cont_preview.models_needed()
        # If model_filter is set and it's 'none', or all pending models are
        # 'none', skip the Ollama check.
        if model_filter == "none":
            needs_model = False
        elif model_filter is not None:
            needs_model = model_filter != "none"
        else:
            needs_model = any(m != "none" for m in models)
    except Exception:  # noqa: BLE001
        # If we can't read the continuation, fall through to the normal path.
        needs_model = True

    if needs_model:
        _preflight_ollama_reachable()

    from .continue_runner import run_one_step
    tools = _build_tools_for_mode(Mode.ONESHOT)
    budget = RunBudget(max_iterations=max_iter, max_wall_seconds=max_wall,
                      max_tokens=max_tokens, consecutive_fail_limit=2)

    protocol_zero.install_signal_handlers()
    result = asyncio.run(run_one_step(
        task_id=task_id, tools=tools, store=store, budget=budget,
        mode=Mode.ONESHOT, model_filter=model_filter,
    ))

    payload = {
        "task_id": result.task_id, "step_id": result.step_id,
        "step_kind": result.step_kind, "outcome": result.outcome,
        "iterations": result.iterations, "tokens": result.tokens,
        "elapsed_seconds": result.elapsed_seconds,
        "required_model": result.required_model,
        "cont_status": result.cont_status, "progress": list(result.progress),
        "final_message": result.final_message,
        "model_filter": model_filter,
    }

    if result.outcome == "locked":
        if STATE.json_out:
            _emit_json({"ok": False, "code": ExitCode.LOCKED, **payload})
        else:
            _print(f"[yellow]locked[/yellow] · {task_id} held by another runner")
        raise typer.Exit(ExitCode.LOCKED)

    if result.outcome == "filtered":
        # No work for this model right now, but other models still have steps.
        # Use a distinct exit code so drain-by-model knows to advance phase.
        if STATE.json_out:
            _emit_json({"ok": True, "code": ExitCode.DRAINED, **payload})
        else:
            done, total = result.progress
            _print(
                f"[dim]filtered[/dim] · no '{model_filter}' steps · "
                f"{done}/{total} · status={result.cont_status}"
            )
        raise typer.Exit(ExitCode.DRAINED)

    if result.outcome in ("drained", "no_step"):
        if STATE.json_out:
            _emit_json({"ok": True, "code": ExitCode.DRAINED, **payload})
        else:
            done, total = result.progress
            _print(f"[green]drained[/green] · {done}/{total} · status={result.cont_status}")
        raise typer.Exit(ExitCode.DRAINED)

    if STATE.json_out:
        ok = result.outcome == "complete"
        _emit_json({"ok": ok, "code": ExitCode.OK if ok else ExitCode.ERROR, **payload})
    else:
        from .continuation import format_elapsed
        done, total = result.progress
        if result.outcome == "complete":
            _print(f"[green]✓ step {result.step_id}[/green] ({result.step_kind}) · "
                  f"{done}/{total} · iter={result.iterations} tokens={result.tokens} · "
                  f"elapsed={format_elapsed(result.elapsed_seconds)}")
        else:
            _print(f"[red]✗ step {result.step_id}[/red] ({result.step_kind}) · "
                  f"{result.outcome} · {done}/{total} · "
                  f"elapsed={format_elapsed(result.elapsed_seconds)}")
    raise typer.Exit(ExitCode.OK if result.outcome == "complete" else ExitCode.ERROR)


@app.command(name="drain-by-model")
def drain_by_model_cmd(
    task_id: str = typer.Argument(..., help="Continuation ID to drain"),
    max_iter: int = typer.Option(5, "--max-iter", help="Per-step iteration cap."),
    max_wall: int = typer.Option(120, "--max-wall", help="Per-step wall-time cap (s)."),
    max_tokens: int = typer.Option(20_000, "--max-tokens", help="Per-step token cap."),
    cooldown: float = typer.Option(2.0, "--cooldown", help="Sleep between steps (s)."),
) -> None:
    """Drain a continuation in model-affinity phases. v0.2.6.

    Inspects the continuation's pending steps, groups by ``required_model``,
    and runs each model's batch contiguously. Each model loads exactly once
    instead of swapping in and out per step.

    Phase order: ``orchestrator`` first (most common, fastest to load), then
    other models alphabetically. ``required_model='none'`` steps run without
    invoking any model.

    Stops cleanly on PROTOCOL-ZERO. Halt-and-resume safe — all state is in
    the continuation file. Re-running picks up exactly where it left off.

    Exit codes: 0 fully drained · 3 halted · other = error.
    """
    _preflight_initialized()
    _preflight_not_halted()

    from .continuation import ContinuationStore
    from .continue_runner import run_one_step

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    cont = store.get(task_id)

    # Pre-flight Ollama only if any pending phase actually needs a model. v0.2.8.
    if any(m != "none" for m in cont.models_needed()):
        _preflight_ollama_reachable()

    if cont.is_drained():
        if STATE.json_out:
            _emit_json({"ok": True, "drained": True, "task_id": task_id})
        else:
            _print(f"[green]already drained[/green] · {task_id}")
        return

    phases = cont.models_needed()
    if not phases:
        if STATE.json_out:
            _emit_json({"ok": True, "drained": True, "task_id": task_id})
        else:
            _print(f"[green]nothing pending[/green] · {task_id}")
        return

    if not STATE.json_out:
        _print(Panel(
            f"[bold]{cont.goal}[/bold]\n"
            f"phases: {' → '.join(phases)}\n"
            f"total pending: {sum(len([s for s in cont.steps if s.status == 'pending' and s.required_model == m]) for m in phases)}",
            title=f"◈ drain-by-model · {task_id}",
            border_style="cyan",
        ))

    tools = _build_tools_for_mode(Mode.ONESHOT)
    budget = RunBudget(
        max_iterations=max_iter, max_wall_seconds=max_wall,
        max_tokens=max_tokens, consecutive_fail_limit=2,
    )

    protocol_zero.install_signal_handlers()

    overall_start = time.monotonic()
    phase_results = []

    for phase_idx, model in enumerate(phases, start=1):
        if protocol_zero.is_armed():
            if not STATE.json_out:
                _print("[red]HALT armed · stopping[/red]")
            raise typer.Exit(ExitCode.HALTED)

        if not STATE.json_out:
            _print(f"\n[bold cyan]◈ phase {phase_idx}/{len(phases)}: {model}[/bold cyan]")

        phase_start = time.monotonic()
        phase_steps = 0
        phase_complete = 0
        phase_poison = 0

        while True:
            if protocol_zero.is_armed():
                break

            result = asyncio.run(run_one_step(
                task_id=task_id, tools=tools, store=store, budget=budget,
                mode=Mode.ONESHOT, model_filter=model,
            ))

            if result.outcome == "locked":
                if not STATE.json_out:
                    _print(f"[yellow]locked, waiting…[/yellow]")
                time.sleep(5.0)
                continue

            if result.outcome in ("filtered", "drained", "no_step"):
                # No more steps in this phase (or continuation drained).
                break

            phase_steps += 1
            if result.outcome == "complete":
                phase_complete += 1
                if not STATE.json_out:
                    done, total = result.progress
                    _print(
                        f"  [green]✓ step {result.step_id}[/green] "
                        f"({result.step_kind}) · {done}/{total} · "
                        f"iter={result.iterations} tokens={result.tokens}"
                    )
            else:
                phase_poison += 1
                if not STATE.json_out:
                    _print(
                        f"  [red]✗ step {result.step_id}[/red] "
                        f"({result.step_kind}) · {result.outcome}"
                    )

            time.sleep(cooldown)

        phase_elapsed = time.monotonic() - phase_start
        phase_results.append({
            "model": model,
            "steps_attempted": phase_steps,
            "complete": phase_complete,
            "poison": phase_poison,
            "elapsed_seconds": round(phase_elapsed, 1),
        })

        if not STATE.json_out:
            _print(
                f"[dim]phase {phase_idx} done · {phase_complete} complete, "
                f"{phase_poison} poison, {phase_elapsed:.1f}s[/dim]"
            )

    overall_elapsed = time.monotonic() - overall_start
    final = store.get(task_id)
    done, total = final.progress

    if STATE.json_out:
        _emit_json({
            "ok": True, "task_id": task_id,
            "phases": phase_results, "final_status": final.status,
            "progress": [done, total],
            "elapsed_seconds": round(overall_elapsed, 1),
        })
    else:
        _print(Panel(
            f"final status: [bold]{final.status}[/bold]\n"
            f"progress: {done}/{total}\n"
            f"total elapsed: {overall_elapsed:.1f}s",
            title="◈ drain-by-model · complete",
            border_style="green" if final.status == "done" else "yellow",
        ))


cont_app = typer.Typer(help="◈ inspect / manage continuation files")
app.add_typer(cont_app, name="continuations")


@cont_app.command("list")
def cont_list(status: str | None = typer.Option(None, "--status")) -> None:
    """List all continuation files with progress."""
    from .continuation import ContinuationStore

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    conts = store.list_all(status=status)

    if STATE.json_out:
        _emit_json({"continuations": [
            {"task_id": c.task_id, "status": c.status, "planner": c.planner,
             "goal": c.goal, "progress": list(c.progress),
             "updated_at": c.updated_at, "output_path": c.output_path}
            for c in conts
        ]})
        return

    if not conts:
        _print("[dim](no continuations)[/dim]")
        return

    table = Table(title="◈ continuations")
    table.add_column("task_id", style="cyan")
    table.add_column("status")
    table.add_column("planner", style="magenta")
    table.add_column("progress", justify="right")
    table.add_column("goal", overflow="fold")
    for c in conts:
        done, total = c.progress
        color = {"planned": "yellow", "in_progress": "cyan", "done": "green",
                 "poisoned": "red", "halted": "red"}.get(c.status, "white")
        table.add_row(c.task_id, f"[{color}]{c.status}[/{color}]",
                     c.planner, f"{done}/{total}", c.goal[:80])
    _print(table)


@cont_app.command("show")
def cont_show(task_id: str) -> None:
    """Show a continuation in detail, including all steps."""
    from .continuation import ContinuationNotFound, ContinuationStore

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    try:
        cont = store.get(task_id)
    except ContinuationNotFound:
        _die(ExitCode.USAGE, f"continuation not found: {task_id}")

    if STATE.json_out:
        from dataclasses import asdict
        _emit_json({
            "task_id": cont.task_id, "goal": cont.goal,
            "planner": cont.planner, "planner_args": cont.planner_args,
            "status": cont.status, "progress": list(cont.progress),
            "output_path": cont.output_path, "notes": cont.notes,
            "created_at": cont.created_at, "updated_at": cont.updated_at,
            "steps": [asdict(s) for s in cont.steps],
        })
        return

    done, total = cont.progress
    by_model = cont.progress_by_model()
    elapsed_by_model = cont.elapsed_by_model()
    progress_lines = [f"status: {cont.status} · progress: {done}/{total}"]
    if len(by_model) > 1:
        per = "  ".join(f"{m}={d}/{t}" for m, (d, t) in sorted(by_model.items()))
        progress_lines.append(f"by model: {per}")
    if cont.total_elapsed_seconds > 0:
        from .continuation import format_elapsed
        progress_lines.append(f"total elapsed: {format_elapsed(cont.total_elapsed_seconds)}")
        if len(elapsed_by_model) > 1:
            per_elapsed = "  ".join(
                f"{m}={format_elapsed(s)}"
                for m, s in sorted(elapsed_by_model.items())
            )
            progress_lines.append(f"elapsed by model: {per_elapsed}")
    _print(Panel(
        f"[bold]{cont.goal}[/bold]\n"
        f"planner: {cont.planner}\n"
        + "\n".join(progress_lines) + "\n"
        f"output: {cont.output_path or '(none)'}\n"
        f"created: {cont.created_at}\n"
        f"updated: {cont.updated_at}",
        title=f"◈ {cont.task_id}", border_style="cyan",
    ))

    from .continuation import format_elapsed as _fmt_elapsed
    table = Table(title="steps", show_header=True)
    table.add_column("id", style="dim", width=4)
    table.add_column("kind", style="magenta")
    table.add_column("model", style="cyan")
    table.add_column("status")
    table.add_column("iter", justify="right")
    table.add_column("tokens", justify="right")
    table.add_column("elapsed", justify="right")
    table.add_column("args", overflow="fold")
    for s in cont.steps:
        color = {"pending": "yellow", "done": "green",
                 "poisoned": "red", "skipped": "dim"}.get(s.status, "white")
        table.add_row(str(s.id), s.kind, s.required_model,
                     f"[{color}]{s.status}[/{color}]",
                     str(s.iterations), str(s.tokens),
                     _fmt_elapsed(s.elapsed_seconds),
                     json.dumps(s.args, default=str)[:80])
    _print(table)


@cont_app.command("delete")
def cont_delete(task_id: str) -> None:
    """Delete a continuation. Refuses if a runner holds the lock."""
    from .continuation import ContinuationLocked, ContinuationStore

    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    try:
        existed = store.delete(task_id)
    except ContinuationLocked:
        _die(ExitCode.LOCKED, f"continuation {task_id} is locked by a runner")

    if STATE.json_out:
        _emit_json({"ok": existed, "task_id": task_id, "deleted": existed})
    elif existed:
        _print(f"[green]deleted[/green] {task_id}")
    else:
        _print(f"[yellow]not found[/yellow] {task_id}")


# ═══════════════════════════════════════════════════════════════════════════
#  BACKLOG
# ═══════════════════════════════════════════════════════════════════════════


backlog_app = typer.Typer(help="◈ manage the task backlog")
app.add_typer(backlog_app, name="backlog")


@backlog_app.command("list")
def backlog_list(status: str | None = typer.Option(None, "--status")) -> None:
    """Show the current backlog."""
    from .mode_controller import read_backlog

    tasks = read_backlog()
    if status:
        tasks = [t for t in tasks if t.status == status]

    if STATE.json_out:
        _emit_json({"tasks": [
            {"id": t.id, "priority": t.priority, "mode": t.mode,
             "status": t.status, "goal": t.goal, "notes": t.notes}
            for t in tasks
        ]})
        return

    if not tasks:
        _print("[dim](backlog empty)[/dim]")
        return

    table = Table(title="◈ backlog")
    table.add_column("id", style="cyan")
    table.add_column("priority", style="magenta")
    table.add_column("mode")
    table.add_column("status")
    table.add_column("goal", overflow="fold")
    for t in tasks:
        status_color = {"pending": "yellow", "running": "cyan", "done": "green",
                       "poison": "red", "budget": "yellow", "halted": "red"}.get(t.status, "white")
        table.add_row(t.id[:18], t.priority, t.mode,
                     f"[{status_color}]{t.status}[/{status_color}]", t.goal[:80])
    _print(table)


@backlog_app.command("add")
def backlog_add(
    goal: str = typer.Argument(...),
    priority: str = typer.Option("medium", "--priority"),
    mode: str = typer.Option("oneshot", "--mode"),
) -> None:
    """Add a task to the backlog."""
    from .mode_controller import add_task
    task = add_task(goal=goal, priority=priority, mode=mode)
    if STATE.json_out:
        _emit_json({"ok": True, "id": task.id})
    else:
        _print(f"[green]added[/green] {task.id}")


@backlog_app.command("remove")
def backlog_remove(task_id: str) -> None:
    """Remove a task from the backlog by id."""
    from .mode_controller import remove_task
    if remove_task(task_id):
        if STATE.json_out:
            _emit_json({"ok": True, "id": task_id})
        else:
            _print(f"[green]removed[/green] {task_id}")
    else:
        if STATE.json_out:
            _emit_json({"ok": False, "id": task_id})
        else:
            _print(f"[yellow]not found[/yellow] {task_id}")


@backlog_app.command("show")
def backlog_show(task_id: str) -> None:
    """Show one task in detail."""
    from .mode_controller import read_backlog
    task = next((t for t in read_backlog() if t.id == task_id or t.id.startswith(task_id)), None)
    if task is None:
        _die(ExitCode.USAGE, f"task not found: {task_id}")

    if STATE.json_out:
        _emit_json({"id": task.id, "goal": task.goal, "priority": task.priority,
                   "mode": task.mode, "status": task.status, "notes": task.notes})
        return

    _print(Panel(
        f"[bold]{task.goal}[/bold]\n"
        f"id: {task.id}\n"
        f"priority: {task.priority}\n"
        f"mode: {task.mode}\n"
        f"status: {task.status}\n"
        f"notes: {task.notes or '(none)'}",
        title=f"◈ {task.id[:18]}",
    ))


@backlog_app.command("requeue")
def backlog_requeue(task_id: str) -> None:
    """Reset a task to 'pending' so it'll be picked up again."""
    from .mode_controller import read_backlog, write_backlog
    tasks = read_backlog()
    target = next((t for t in tasks if t.id == task_id), None)
    if target is None:
        _die(ExitCode.USAGE, f"task not found: {task_id}")
    target.status = "pending"
    target.notes = "requeued by operator"
    write_backlog(tasks)
    if STATE.json_out:
        _emit_json({"ok": True, "id": task_id})
    else:
        _print(f"[green]requeued[/green] {task_id}")


@backlog_app.command("priority")
def backlog_priority(
    task_id: str,
    priority: str = typer.Argument(..., help="critical | high | medium | low"),
) -> None:
    """Change a task's priority."""
    valid = {"critical", "high", "medium", "low"}
    if priority not in valid:
        _die(ExitCode.USAGE, f"priority must be one of {sorted(valid)}")

    from .mode_controller import read_backlog, write_backlog
    tasks = read_backlog()
    target = next((t for t in tasks if t.id == task_id), None)
    if target is None:
        _die(ExitCode.USAGE, f"task not found: {task_id}")
    target.priority = priority
    write_backlog(tasks)
    if STATE.json_out:
        _emit_json({"ok": True, "id": task_id, "priority": priority})
    else:
        _print(f"[green]priority={priority}[/green] {task_id}")


@backlog_app.command("clear")
def backlog_clear(
    status: str = typer.Option(..., "--status", help="Clear tasks with this status."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Remove all tasks with the given status."""
    from .mode_controller import read_backlog, write_backlog

    tasks = read_backlog()
    keep = [t for t in tasks if t.status != status]
    removed = len(tasks) - len(keep)
    if removed == 0:
        _print(f"[dim]no tasks with status={status!r}[/dim]")
        return
    if not yes and not STATE.json_out:
        if not typer.confirm(f"Remove {removed} task(s) with status={status!r}?"):
            _print("[dim]cancelled[/dim]")
            return
    write_backlog(keep)
    if STATE.json_out:
        _emit_json({"ok": True, "removed": removed, "status": status})
    else:
        _print(f"[green]cleared[/green] {removed} task(s) with status={status!r}")


# ═══════════════════════════════════════════════════════════════════════════
#  APPROVALS
# ═══════════════════════════════════════════════════════════════════════════


def _parse_expiry(expiry_ts: str) -> datetime | None:
    """RFC3339-ish expiry parser. Tolerates whole-second AND fractional forms.

    The v0.2.4 implementation hard-coded ``%Y-%m-%dT%H:%M:%S.%f%z`` which
    silently fails on whole-second timestamps. Falls back to fromisoformat
    which Python 3.11 accepts both forms of.
    """
    if not expiry_ts:
        return None
    s = expiry_ts.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def _scan_pending_approval_requests() -> list[dict]:
    """Find approval-needed-d events that haven't been resolved."""
    from .events import init_events_db, tail_to_sqlite

    conn = init_events_db()
    tail_to_sqlite(conn)
    rows = conn.execute(
        "SELECT event_id, ts, payload FROM events "
        "WHERE flag = 'approval-needed-d' ORDER BY ts ASC"
    ).fetchall()

    pending: list[dict] = []
    for ev_id, ts, payload_json in rows:
        try:
            payload = json.loads(payload_json)
        except json.JSONDecodeError:
            continue

        resolved = conn.execute(
            "SELECT 1 FROM events "
            "WHERE flag IN ('approval-d', 'approval-x', 'approval-denied-d') "
            "AND payload LIKE ? LIMIT 1",
            (f'%"event_id":"{ev_id}"%',),
        ).fetchone()
        if resolved:
            continue

        expiry = _parse_expiry(payload.get("expiry_ts", ""))
        if expiry and datetime.now(timezone.utc) >= expiry:
            continue

        pending.append({
            "event_id": ev_id, "requested_at": ts,
            "tool_name": payload.get("tool_name"),
            "args_hash": payload.get("args_hash"),
            "args_preview": payload.get("args_preview"),
            "justification": payload.get("justification"),
            "expiry_ts": payload.get("expiry_ts"),
            "expiry_dt": expiry,
        })

    conn.close()
    return pending


def _format_ttl(expiry: datetime | None) -> str:
    if expiry is None:
        return "(unknown)"
    delta = expiry - datetime.now(timezone.utc)
    secs = int(delta.total_seconds())
    if secs <= 0:
        return "expired"
    if secs < 60:
        return f"{secs}s"
    if secs < 3600:
        return f"{secs // 60}m {secs % 60}s"
    return f"{secs // 3600}h {(secs % 3600) // 60}m"


@app.command()
def approvals() -> None:
    """List pending Tier 3 approval requests."""
    pending = _scan_pending_approval_requests()

    if STATE.json_out:
        _emit_json({"pending": [
            {**{k: v for k, v in p.items() if k != "expiry_dt"},
             "ttl": _format_ttl(p.get("expiry_dt"))}
            for p in pending
        ]})
        return

    if not pending:
        _print("[dim](no pending approvals)[/dim]")
        return

    for req in pending:
        ttl = _format_ttl(req.get("expiry_dt"))
        body = (
            f"[bold]tool:[/bold]      {req['tool_name']}\n"
            f"[bold]requested:[/bold] {req['requested_at']}\n"
            f"[bold]expires in:[/bold] {ttl}\n"
            f"[bold]args:[/bold]      {req['args_preview']}\n"
            f"[bold]reason:[/bold]    {req['justification']}\n\n"
            f"[dim]grant:  sovereign approve {req['event_id']}\n"
            f"deny:   sovereign deny {req['event_id']}[/dim]"
        )
        _print(Panel(body, title=f"◈ {req['event_id']}", border_style="yellow"))


@app.command()
def approve(
    event_id: str,
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Grant a Tier 3 approval. The agent picks it up on next dispatch."""
    pending = _scan_pending_approval_requests()
    match = next((p for p in pending if p["event_id"] == event_id), None)
    if match is None:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"not found or already resolved: {event_id}")

    if not yes and not STATE.json_out:
        body = (
            f"tool:      {match['tool_name']}\n"
            f"args:      {match['args_preview']}\n"
            f"reason:    {match['justification']}\n"
            f"expires:   {match['expiry_ts']}"
        )
        _print(Panel(body, title=f"◈ approve {event_id}?", border_style="yellow"))
        if not typer.confirm("Grant this approval?"):
            _print("[dim]cancelled[/dim]")
            raise typer.Exit(ExitCode.OK)

    from .approval import ApprovalRequest, write_grant
    req = ApprovalRequest(
        event_id=event_id, tool_name=match["tool_name"], args={},
        args_hash=match["args_hash"], justification=match["justification"] or "",
        expiry_ts=match["expiry_ts"],
    )
    write_grant(req)
    if STATE.json_out:
        _emit_json({"ok": True, "granted": event_id})
    else:
        _print(f"[green]✓ granted[/green] {event_id}")


@app.command()
def deny(event_id: str, reason: str = typer.Option("operator denied", "--reason")) -> None:
    """Refuse a Tier 3 approval."""
    from .approval import write_denial
    write_denial(event_id, trace_id="cli-deny", reason=reason)
    if STATE.json_out:
        _emit_json({"ok": True, "denied": event_id, "reason": reason})
    else:
        _print(f"[red]✗ denied[/red] {event_id}")


# ═══════════════════════════════════════════════════════════════════════════
#  SAFETY
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def halt(reason: str = typer.Option("operator", "--reason")) -> None:
    """Trip PROTOCOL-ZERO. The agent halts at the next iteration boundary."""
    protocol_zero.arm(reason)
    if STATE.json_out:
        _emit_json({"ok": True, "halted": True, "reason": reason})
    else:
        _print(Panel(
            f"[red]PROTOCOL-ZERO armed[/red]\nreason: {reason}\n\n"
            f"[dim]clear with: sovereign disarm[/dim]",
            border_style="red",
        ))


@app.command()
def disarm() -> None:
    """Clear PROTOCOL-ZERO. Manual ack required after operator review."""
    protocol_zero.disarm()
    if STATE.json_out:
        _emit_json({"ok": True, "disarmed": True})
    else:
        _print("[green]✓ disarmed[/green]")


# ═══════════════════════════════════════════════════════════════════════════
#  AUDIT
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def tail() -> None:
    """Ingest events.jsonl into the SQLite events projection."""
    conn = init_events_db()
    inserted = tail_to_sqlite(conn)
    conn.close()
    if STATE.json_out:
        _emit_json({"ok": True, "inserted": inserted})
    else:
        _print(f"[green]ingested[/green] {inserted} events")


@app.command()
def seal() -> None:
    """Compute yesterday's Merkle seal over events.jsonl."""
    from .seal import seal_yesterday
    root = seal_yesterday()
    if STATE.json_out:
        _emit_json({"ok": True, "root": root})
        return
    if root:
        _print(f"[green]✓ sealed[/green] yesterday: [cyan]{root}[/cyan]")
    else:
        _print("[dim]no events to seal[/dim]")


@app.command()
def verify(target_date: str = typer.Argument(..., help="YYYY-MM-DD")) -> None:
    """Verify a past seal still matches its events file."""
    from .seal import verify_seal
    try:
        d = date.fromisoformat(target_date)
    except ValueError:
        _die(ExitCode.USAGE, f"invalid date: {target_date}")

    matches, msg = verify_seal(d)
    if STATE.json_out:
        _emit_json({"ok": matches, "message": msg, "date": target_date})
    else:
        style = "green" if matches else "red"
        _print(f"[{style}]{msg}[/{style}]")
    raise typer.Exit(ExitCode.OK if matches else ExitCode.ERROR)


@app.command()
def events(
    n: int = typer.Option(20, "-n", help="How many recent events to show"),
    flag: str | None = typer.Option(None, "--flag", help="Filter by flag (e.g., 'tool-x')"),
    follow: bool = typer.Option(False, "--follow", "-f", help="tail -f mode (Ctrl-C to stop)"),
    interval: float = typer.Option(1.0, "--interval", help="Poll interval for --follow."),
) -> None:
    """Show recent events from the SQLite projection.

    With ``--follow``, polls for new events forever (Ctrl-C to stop).
    """
    if follow:
        _follow_events(flag=flag, interval=interval)
        return

    conn = init_events_db()
    tail_to_sqlite(conn)
    if flag:
        rows = conn.execute(
            "SELECT ts, flag, trace_id, payload FROM events "
            "WHERE flag = ? ORDER BY ts DESC LIMIT ?",
            (flag, n),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT ts, flag, trace_id, payload FROM events "
            "ORDER BY ts DESC LIMIT ?", (n,),
        ).fetchall()
    conn.close()

    if STATE.json_out:
        _emit_json({"events": [
            {"ts": ts, "flag": fl, "trace_id": tid, "payload": pl}
            for ts, fl, tid, pl in rows
        ]})
        return

    table = Table(title="◈ recent events" + (f" (flag={flag})" if flag else ""))
    table.add_column("ts", style="dim")
    table.add_column("flag", style="cyan")
    table.add_column("trace", style="dim")
    table.add_column("payload", overflow="fold")
    for ts, fl, tid, pl in rows:
        table.add_row(ts.split("T")[1][:12], fl, tid[:8], pl[:80])
    _print(table)


def _follow_events(*, flag: str | None, interval: float) -> None:
    """tail -f over the events table."""
    conn = init_events_db()
    tail_to_sqlite(conn)
    last_ts = ""
    row = conn.execute("SELECT MAX(ts) FROM events").fetchone()
    if row and row[0]:
        last_ts = row[0]
    if not STATE.json_out:
        _print(f"[dim]following events (interval={interval}s, Ctrl-C to stop)…[/dim]")
    try:
        while True:
            tail_to_sqlite(conn)
            if flag:
                rows = conn.execute(
                    "SELECT ts, flag, trace_id, payload FROM events "
                    "WHERE flag = ? AND ts > ? ORDER BY ts ASC LIMIT 100",
                    (flag, last_ts),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT ts, flag, trace_id, payload FROM events "
                    "WHERE ts > ? ORDER BY ts ASC LIMIT 100", (last_ts,),
                ).fetchall()
            for ts, fl, tid, pl in rows:
                if STATE.json_out:
                    _emit_json({"ts": ts, "flag": fl, "trace_id": tid, "payload": pl})
                else:
                    _print(f"[dim]{ts.split('T')[1][:12]}[/dim] [cyan]{fl}[/cyan] {tid[:8]} {pl[:120]}")
                last_ts = ts
            time.sleep(interval)
    except KeyboardInterrupt:
        if not STATE.json_out:
            _print("\n[dim]stopped[/dim]")
    finally:
        conn.close()


@app.command()
def lessons(n: int = typer.Option(10, "-n")) -> None:
    """Show recent distilled lessons from the Reflector."""
    from .db import open_atoms_db
    conn = open_atoms_db()
    rows = conn.execute(
        "SELECT ts, trigger, rule, confidence FROM lessons "
        "ORDER BY ts DESC LIMIT ?", (n,),
    ).fetchall()
    conn.close()

    if STATE.json_out:
        _emit_json({"lessons": [
            {"ts": ts, "trigger": trigger, "rule": rule, "confidence": conf}
            for ts, trigger, rule, conf in rows
        ]})
        return

    if not rows:
        _print("[dim](no lessons yet)[/dim]")
        return

    table = Table(title="◈ lessons")
    table.add_column("when", style="dim")
    table.add_column("trigger", style="yellow")
    table.add_column("confidence", justify="right")
    table.add_column("rule")
    for ts, trigger, rule, conf in rows:
        table.add_row(ts.split("T")[0], trigger[:30], f"{conf:.2f}", rule)
    _print(table)


# ═══════════════════════════════════════════════════════════════════════════
#  PALACE — Structured layer over atoms.db (v0.2.7+)
# ═══════════════════════════════════════════════════════════════════════════


palace_app = typer.Typer(help="◈ structured memory: rooms, closets, triples")
app.add_typer(palace_app, name="palace")


@palace_app.command("stats")
def palace_stats() -> None:
    """Counts of rooms, closets, entities, triples in the palace."""
    from .palace import open_palace
    p = open_palace()
    try:
        stats = p.stats()
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"ok": True, **stats})
        return

    table = Table(title="◈ palace · stats", show_header=False, box=None, padding=(0, 1))
    table.add_column(style="dim")
    table.add_column(justify="right")
    for k, v in stats.items():
        table.add_row(k, str(v))
    _print(table)


@palace_app.command("rooms")
def palace_rooms() -> None:
    """List all rooms in the palace."""
    from .palace import open_palace
    p = open_palace()
    try:
        rooms = p.list_rooms()
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"rooms": [
            {"id": r.id, "name": r.name, "description": r.description,
             "created_at": r.created_at}
            for r in rooms
        ]})
        return

    if not rooms:
        _print("[dim](no rooms)[/dim]")
        return

    table = Table(title="◈ palace · rooms")
    table.add_column("id", style="cyan")
    table.add_column("name")
    table.add_column("description", overflow="fold")
    table.add_column("created", style="dim")
    for r in rooms:
        table.add_row(r.id, r.name, r.description[:60], r.created_at.split("T")[0])
    _print(table)


@palace_app.command("create-room")
def palace_create_room(
    room_id: str = typer.Argument(..., help="Stable room id, e.g. room-research"),
    name: str = typer.Argument(..., help="Human-readable name"),
    description: str = typer.Option("", "--description"),
) -> None:
    """Create a new room in the palace."""
    from .palace import open_palace
    p = open_palace()
    try:
        room = p.create_room(room_id=room_id, name=name, description=description)
    except Exception as e:  # noqa: BLE001
        p.close()
        _die(ExitCode.ERROR, f"create-room failed: {e}")
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"ok": True, "id": room.id, "name": room.name})
    else:
        _print(f"[green]created[/green] {room.id} · {room.name}")


@palace_app.command("closets")
def palace_closets(
    room_id: str | None = typer.Option(None, "--room", help="Filter by room"),
    limit: int = typer.Option(20, "-n"),
) -> None:
    """List recent closets, optionally filtered by room."""
    from .palace import open_palace
    p = open_palace()
    try:
        closets = p.list_closets(room_id=room_id)[:limit]
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"closets": [
            {"id": c.id, "room_id": c.room_id, "topic": c.topic,
             "entities": c.entities, "atom_ids": c.atom_ids,
             "source_file": c.source_file, "created_at": c.created_at}
            for c in closets
        ]})
        return

    if not closets:
        _print("[dim](no closets)[/dim]")
        return

    table = Table(title=f"◈ palace · closets" + (f" ({room_id})" if room_id else ""))
    table.add_column("id", style="cyan", overflow="ellipsis", max_width=24)
    table.add_column("topic", overflow="fold")
    table.add_column("entities", style="magenta", overflow="fold")
    table.add_column("atoms", justify="right")
    table.add_column("source", style="dim", overflow="ellipsis", max_width=30)
    for c in closets:
        table.add_row(
            c.id, c.topic[:80],
            "; ".join(c.entities[:3]) + ("…" if len(c.entities) > 3 else ""),
            str(len(c.atom_ids)),
            c.source_file or "",
        )
    _print(table)


@palace_app.command("search")
def palace_search(
    query: str = typer.Argument(..., help="Substring search over closet topics + entities"),
    room_id: str | None = typer.Option(None, "--room"),
    limit: int = typer.Option(10, "-n"),
) -> None:
    """Keyword search over the closet index. v0.2.7 first cut.

    For semantic search, use ``sovereign palace search-semantic`` (requires
    embed_query tool). Hybrid BM25+cosine is roadmap for v0.2.8.
    """
    from .palace import open_palace
    p = open_palace()
    try:
        results = p.search_closets_keyword(query, limit=limit, room_id=room_id)
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"results": [
            {"id": c.id, "topic": c.topic, "entities": c.entities,
             "atom_ids": c.atom_ids, "room_id": c.room_id}
            for c in results
        ]})
        return

    if not results:
        _print(f"[dim](no closets matched {query!r})[/dim]")
        return

    table = Table(title=f"◈ palace · search · {query!r}")
    table.add_column("id", style="cyan", overflow="ellipsis", max_width=20)
    table.add_column("topic", overflow="fold")
    table.add_column("entities", style="magenta")
    table.add_column("atoms", justify="right")
    for c in results:
        table.add_row(c.id, c.topic[:80], "; ".join(c.entities[:3]), str(len(c.atom_ids)))
    _print(table)


@palace_app.command("subject")
def palace_subject(
    entity_id: str = typer.Argument(..., help="Entity id to query"),
    as_of: str | None = typer.Option(None, "--as-of",
        help="Point-in-time filter (RFC3339 / ISO date)"),
) -> None:
    """Show all triples about this subject. Optional point-in-time filter."""
    from .palace import open_palace
    p = open_palace()
    try:
        triples = p.query_subject(entity_id, as_of=as_of)
        ent = p.get_entity(entity_id)
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({
            "entity": {
                "id": ent.id, "name": ent.name, "type": ent.type,
            } if ent else None,
            "triples": [
                {"id": t.id, "subject": t.subject_id,
                 "predicate": t.predicate, "object_id": t.object_id,
                 "object_literal": t.object_literal,
                 "valid_from": t.valid_from, "valid_to": t.valid_to,
                 "confidence": t.confidence}
                for t in triples
            ],
        })
        return

    if ent:
        _print(Panel(
            f"[bold]{ent.name}[/bold]  ({ent.type})\n"
            f"id: {ent.id}\n"
            f"first seen: {ent.first_seen.split('T')[0]}\n"
            f"last seen:  {ent.last_seen.split('T')[0]}",
            title="◈ entity", border_style="cyan",
        ))

    if not triples:
        _print(f"[dim](no triples for {entity_id})[/dim]")
        return

    table = Table(title=f"◈ triples about {entity_id}")
    table.add_column("predicate", style="magenta")
    table.add_column("object")
    table.add_column("from", style="dim")
    table.add_column("to", style="dim")
    table.add_column("conf", justify="right")
    for t in triples:
        obj = t.object_id or t.object_literal or "?"
        table.add_row(
            t.predicate, obj[:40],
            (t.valid_from or "—").split("T")[0],
            (t.valid_to or "—").split("T")[0],
            f"{t.confidence:.2f}",
        )
    _print(table)


# ═══════════════════════════════════════════════════════════════════════════
#  PALACE UNDERSTANDING + PROPOSALS — Self-reflection loop (v0.2.9+)
# ═══════════════════════════════════════════════════════════════════════════


@palace_app.command("understanding")
def palace_understanding(
    output: Path | None = typer.Option(
        None, "--output", help="Write markdown report to this file."
    ),
) -> None:
    """Scan the palace, print or write a structured understanding report.

    Read-only. No mutations. Used to drive palace-reflect and palace-clean.
    """
    from .palace import open_palace
    from .palace_scan import (
        render_understanding_markdown,
        scan_palace,
        understanding_to_dict,
    )

    p = open_palace()
    try:
        understanding = scan_palace(p)
    finally:
        p.close()

    if STATE.json_out:
        _emit_json({"ok": True, "understanding": understanding_to_dict(understanding)})
        return

    md = render_understanding_markdown(understanding)
    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(md, encoding="utf-8")
        _print(f"[green]wrote[/green] {output}")
    else:
        _print(md)


proposals_app = typer.Typer(help="◈ self-reflection proposals (v0.2.9)")
app.add_typer(proposals_app, name="proposals")


@proposals_app.command("list")
def proposals_list(
    status: str | None = typer.Option(None, "--status",
        help="Filter: pending / approved / rejected / applied / failed"),
    kind: str | None = typer.Option(None, "--kind",
        help="Filter: clean / reorganize / insight / enhancement"),
) -> None:
    """List proposals, optionally filtered by status or kind."""
    from .proposals import open_store

    store = open_store()
    items = store.list_all(status=status, kind=kind)

    if STATE.json_out:
        _emit_json({"proposals": [
            {"id": p.id, "kind": p.kind, "title": p.title,
             "status": p.status, "source": p.source,
             "created_at": p.created_at,
             "approved_at": p.approved_at,
             "applied_at": p.applied_at}
            for p in items
        ]})
        return

    if not items:
        suffix = ""
        if status:
            suffix = f" with status={status}"
        if kind:
            suffix += f" kind={kind}"
        _print(f"[dim](no proposals{suffix})[/dim]")
        return

    table = Table(title="◈ proposals")
    table.add_column("id", style="cyan", overflow="ellipsis", max_width=24)
    table.add_column("kind", style="magenta")
    table.add_column("status")
    table.add_column("title", overflow="fold")
    table.add_column("created", style="dim")
    for p in items:
        color = {"pending": "yellow", "approved": "green",
                 "rejected": "dim", "applied": "blue", "failed": "red"}.get(p.status, "white")
        table.add_row(p.id, p.kind, f"[{color}]{p.status}[/{color}]",
                     p.title[:60], p.created_at.split("T")[0])
    _print(table)


@proposals_app.command("show")
def proposals_show(
    proposal_id: str = typer.Argument(..., help="Proposal id"),
) -> None:
    """Show full detail for one proposal."""
    from .proposals import ProposalNotFound, open_store

    store = open_store()
    try:
        p = store.get(proposal_id)
    except ProposalNotFound:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"proposal not found: {proposal_id}")

    if STATE.json_out:
        from dataclasses import asdict
        _emit_json({"proposal": asdict(p)})
        return

    _print(Panel(
        f"[bold]{p.title}[/bold]\n"
        f"id: {p.id}\n"
        f"kind: {p.kind} · status: {p.status}\n"
        f"source: {p.source}\n"
        f"created: {p.created_at}\n"
        + (f"approved: {p.approved_at} by {p.approved_by}\n" if p.approved_at else "")
        + (f"applied: {p.applied_at}\n" if p.applied_at else "")
        + f"\n[bold]rationale:[/bold]\n{p.rationale or '(none)'}\n"
        + f"\n[bold]action:[/bold]\n{json.dumps(p.action, indent=2)}\n"
        + (f"\n[bold]notes:[/bold]\n{p.notes}\n" if p.notes else "")
        + (f"\n[bold]result:[/bold]\n{p.result}\n" if p.result else "")
        + (f"\n[bold]rollback:[/bold]\n{json.dumps(p.rollback, indent=2)}\n"
           if p.rollback else ""),
        title=f"◈ proposal {p.id}", border_style="cyan",
    ))


@proposals_app.command("approve")
def proposals_approve(
    proposal_id: str = typer.Argument(..., help="Proposal id to approve"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Approve a proposal so palace-apply can execute it."""
    from .approval import _load_or_create_secret
    from .proposals import (
        ProposalNotApprovable, ProposalNotFound, open_store,
    )

    store = open_store()
    try:
        p = store.get(proposal_id)
    except ProposalNotFound:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"proposal not found: {proposal_id}")

    if not yes:
        _print(Panel(
            f"[bold]{p.title}[/bold]\n"
            f"kind: {p.kind}\n\n"
            f"[bold]rationale:[/bold] {p.rationale}\n\n"
            f"[bold]action:[/bold]\n{json.dumps(p.action, indent=2)}",
            title="◈ approve proposal?", border_style="yellow",
        ))
        if not typer.confirm("Approve this proposal?"):
            _print("[dim]aborted[/dim]")
            raise typer.Exit(ExitCode.OK)

    secret = _load_or_create_secret()
    try:
        approved = store.approve(proposal_id, secret=secret)
    except ProposalNotApprovable as e:
        _die(ExitCode.APPROVAL_NOT_FOUND, str(e))

    if STATE.json_out:
        _emit_json({"ok": True, "id": approved.id, "status": approved.status})
    else:
        _print(f"[green]approved[/green] {approved.id}")
        _print(f"  apply with: [bold]sovereign plan palace-apply[/bold]")


@proposals_app.command("reject")
def proposals_reject(
    proposal_id: str = typer.Argument(..., help="Proposal id to reject"),
    reason: str = typer.Option("operator rejected", "--reason"),
) -> None:
    """Reject a proposal. Cannot be undone."""
    from .proposals import (
        ProposalNotApprovable, ProposalNotFound, open_store,
    )

    store = open_store()
    try:
        p = store.reject(proposal_id, reason=reason)
    except ProposalNotFound:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"proposal not found: {proposal_id}")
    except ProposalNotApprovable as e:
        _die(ExitCode.APPROVAL_NOT_FOUND, str(e))

    if STATE.json_out:
        _emit_json({"ok": True, "id": p.id, "status": p.status})
    else:
        _print(f"[dim]rejected[/dim] {p.id} ({reason})")


impact_app = typer.Typer(help="◈ multi-scale impact measurement (MSIMS, v0.2.10)")
app.add_typer(impact_app, name="impact")


@impact_app.command("score")
def impact_score_cmd(
    action_label: str = typer.Argument(..., help="One-line summary of the action."),
    description: str = typer.Option("", "--description", "-d",
        help="Longer description for the model to score against."),
    context: str = typer.Option("", "--context", "-c",
        help="Additional context (atoms it'll affect, who's involved, etc.)."),
    drive: bool = typer.Option(True, "--drive/--no-drive",
        help="Plan + drive the continuation in one shot (default: yes)."),
) -> None:
    """Score a 3×4 Impact Vector for an action. Stores as a Knowledge Atom.

    Convenience wrapper around `sov plan impact-score` + drive loop. The
    model emits a 3×4 matrix with confidence per cell, written as an atom
    in atoms.db. Operator reviews via `sov impact show <atom-id>`.

    The scoring is JUDGMENT, not measurement. Confidence is surfaced
    prominently. The IV is information for the operator — the system
    never auto-rejects based on it.
    """
    from .planners import REGISTRY
    planner = REGISTRY["impact-score"]

    args = {
        "action_label": action_label,
        "action_description": description or action_label,
        "context": context,
    }
    try:
        plan_result = planner.plan(**args)
    except Exception as e:  # noqa: BLE001
        _die(ExitCode.USAGE, f"plan failed: {e}")

    # Persist the continuation
    from .continuation import Continuation, ContinuationStore
    from ulid import ULID
    task_id = f"cont-{ULID()}"
    cont = Continuation(
        task_id=task_id, planner=planner.name, planner_args=args,
        steps=plan_result.steps, output_path=plan_result.output_path,
        notes=plan_result.notes, goal=plan_result.goal,
    )
    store = ContinuationStore(SETTINGS.paths.continuations_dir)
    store.put(cont)

    if STATE.json_out:
        _emit_json({
            "ok": True, "task_id": task_id,
            "step_count": len(plan_result.steps),
            "drove": drive,
        })
        if not drive:
            return
    else:
        _print(f"◈ planned · {task_id} · {len(plan_result.steps)} step(s)")
        if not drive:
            _print(f"  drive with: sov continue {task_id}")
            return

    # Drive
    from .continue_runner import run_one_step
    while True:
        try:
            result = run_one_step(task_id)
        except Exception as e:  # noqa: BLE001
            _die(ExitCode.GENERIC, f"continue failed: {e}")
        if result.outcome == "drained":
            break
        if result.outcome == "halted":
            _die(ExitCode.HALTED, "PROTOCOL-ZERO armed")
        # complete or poison: keep going

    # Find the resulting atom_id by scanning the events log for the impact_score tool result
    # Simplest: read the continuation's last event log entry — but the tool result
    # lands in events.jsonl. For now, point the operator at recent atoms.
    if STATE.json_out:
        _emit_json({"ok": True, "task_id": task_id, "drained": True,
                    "next": "find atom_id via `sov memory_search 'impact'` or check recent events"})
    else:
        _print(f"[green]done[/green] · IV emitted as atom (type=decision)")
        _print(f"  find it: `sov events --flag tool-d -n 5` then `sov impact show <atom-id>`")


@impact_app.command("show")
def impact_show_cmd(
    atom_id: str = typer.Argument(..., help="atom_id of an Impact Vector atom"),
) -> None:
    """Render an Impact Vector atom as a 3×4 matrix with confidence per cell."""
    from .impact import ImpactVector, render_iv_matrix_dict, render_iv_matrix_text
    from .db import open_atoms_db
    import json as _json

    conn = open_atoms_db()
    try:
        row = conn.execute(
            "SELECT atom_id, type, summary, content_ref, claims FROM atoms "
            "WHERE atom_id = ?",
            (atom_id,),
        ).fetchone()
    finally:
        conn.close()
    if row is None:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"atom not found: {atom_id}")
    atom_id_, atype, summary, content_ref_json, claims_json = row[0], row[1], row[2], row[3], row[4]
    if atype != "decision":
        _print(f"[yellow]warning:[/yellow] atom is type={atype!r}, expected 'decision' for IVs")

    try:
        content_ref = _json.loads(content_ref_json) if content_ref_json else {}
        claims = _json.loads(claims_json) if claims_json else []
    except _json.JSONDecodeError as e:
        _die(ExitCode.GENERIC, f"corrupt atom: {e}")

    # The IV metadata is stored in content_ref.data
    metadata = content_ref.get("data", {}) if isinstance(content_ref, dict) else {}
    atom_dict = {
        "summary": summary,
        "claims": claims,
        "metadata": metadata,
        "framing": metadata.get("framing", ""),
    }
    iv = ImpactVector.from_atom_dict(atom_dict)

    if STATE.json_out:
        _emit_json({"atom_id": atom_id_, "iv": render_iv_matrix_dict(iv)})
    else:
        _print(render_iv_matrix_text(iv))


@proposals_app.command("delete")
def proposals_delete(
    proposal_id: str = typer.Argument(..., help="Proposal id to delete"),
    yes: bool = typer.Option(False, "--yes", "-y"),
) -> None:
    """Hard-delete a proposal. Use sparingly; reject preserves audit better."""
    from .proposals import open_store
    if not yes:
        if not typer.confirm(f"Hard-delete proposal {proposal_id}? (Use 'reject' to preserve audit)"):
            _print("[dim]aborted[/dim]")
            raise typer.Exit(ExitCode.OK)
    store = open_store()
    deleted = store.delete(proposal_id)
    if STATE.json_out:
        _emit_json({"ok": True, "deleted": deleted})
    else:
        if deleted:
            _print(f"[red]deleted[/red] {proposal_id}")
        else:
            _print(f"[dim]not found[/dim] {proposal_id}")


@proposals_app.command("stage")
def proposals_stage(
    proposal_id: str = typer.Argument(..., help="code_update proposal id"),
    timeout: int = typer.Option(600, "--timeout",
        help="pytest timeout in seconds"),
) -> None:
    """Stage a code_update proposal: copy proposed file → run tests → record result.

    Required for code_update proposals before they can be approved + applied.
    The proposal's action must contain {source_path, target_relpath}.

    The pipeline:
      1. Read proposal action (source_path, target_relpath)
      2. Copy source_path into <data_dir>/staging/<proposal_id>/
      3. Temporarily apply proposed file to target, run pytest, restore original
      4. Persist test_result.json in staging dir
      5. Update proposal notes with the test summary

    Operator then reviews via `sov proposals show`. If tests passed AND the
    operator is satisfied, they `sov proposals approve <id>` and the
    palace-apply pipeline picks it up. archive_and_swap will refuse if
    test_result.ok is not True.
    """
    from .code_update import (
        StagingError, run_tests_against_staging, stage_proposal,
    )
    from .proposals import (
        ProposalNotApprovable, ProposalNotFound, open_store,
    )

    store = open_store()
    try:
        p = store.get(proposal_id)
    except ProposalNotFound:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"proposal not found: {proposal_id}")

    if p.kind != "code_update":
        _die(ExitCode.USAGE,
             f"proposal {proposal_id} is kind={p.kind!r}, not 'code_update'. "
             f"Only code_update proposals can be staged.")
    if p.status != "pending":
        _die(ExitCode.USAGE,
             f"proposal {proposal_id} is in state {p.status!r}; "
             f"only pending proposals can be staged.")

    src = p.action.get("source_path")
    rel = p.action.get("target_relpath")
    if not src or not rel:
        _die(ExitCode.USAGE,
             f"proposal {proposal_id} action missing source_path or target_relpath")

    if not STATE.json_out:
        _print(f"◈ staging {proposal_id}")
        _print(f"  source: {src}")
        _print(f"  target: {rel}")
    try:
        from pathlib import Path as _Path
        stage_proposal(
            proposal_id=proposal_id,
            source_path=_Path(src),
            target_relpath=str(rel),
            data_dir=SETTINGS.paths.data_dir,
        )
    except StagingError as e:
        _die(ExitCode.GENERIC, f"stage failed: {e}")

    if not STATE.json_out:
        _print(f"  running tests (timeout {timeout}s)…")
    result = run_tests_against_staging(
        proposal_id=proposal_id,
        data_dir=SETTINGS.paths.data_dir,
        timeout=timeout,
    )

    # Append result summary to proposal notes (so `proposals show` surfaces it)
    p_again = store.get(proposal_id)
    summary_line = (
        f"STAGE {result['ran_at']}: "
        f"ok={result['ok']} "
        f"summary={result['summary']!r} "
        f"duration={result['duration_seconds']:.1f}s"
    )
    p_again.notes = (p_again.notes + "\n" if p_again.notes else "") + summary_line
    from .proposals import _atomic_write_yaml, _to_yaml_dict
    _atomic_write_yaml(store._path(proposal_id), _to_yaml_dict(p_again))

    if STATE.json_out:
        _emit_json({"ok": result["ok"], "result": result})
    else:
        if result["ok"]:
            _print(f"  [green]✓ tests passed[/green] · {result['summary']}")
            _print(f"  next: review via `sov proposals show {proposal_id}` then approve")
        else:
            _print(f"  [red]✗ tests failed[/red] · {result['summary']}")
            _print(f"  staged file is in {SETTINGS.paths.data_dir}/staging/{proposal_id}/")
            _print(f"  the swap will REFUSE while tests are failing.")
            raise typer.Exit(ExitCode.GENERIC)


@proposals_app.command("rollback")
def proposals_rollback(
    proposal_id: str = typer.Argument(..., help="Applied proposal id to roll back"),
    yes: bool = typer.Option(False, "--yes", "-y"),
) -> None:
    """Roll back an applied proposal using its recorded rollback descriptor.

    The proposal must be in status='applied' AND have a rollback descriptor
    that we know how to execute. Currently supported:
      - code_rollback: restore the archived file
      - restore_triple: re-mark a triple as valid (currently no-op; soft-delete via valid_to is its own contract)
      - restore_closet: re-add a removed closet
      - remove_closet: delete an additive closet (insights/enhancements)
    """
    from .events import emit_event
    from .proposals import (
        ProposalNotApprovable, ProposalNotFound, open_store,
    )

    store = open_store()
    try:
        p = store.get(proposal_id)
    except ProposalNotFound:
        _die(ExitCode.APPROVAL_NOT_FOUND, f"proposal not found: {proposal_id}")

    if p.status != "applied":
        _die(ExitCode.USAGE,
             f"proposal {proposal_id} is in state {p.status!r}, "
             f"only 'applied' proposals can be rolled back.")
    if not p.rollback:
        _die(ExitCode.USAGE,
             f"proposal {proposal_id} has no rollback descriptor; "
             f"cannot be auto-rolled-back.")

    rb_type = p.rollback.get("type")

    if not yes:
        _print(Panel(
            f"[bold]{p.title}[/bold]\n"
            f"applied at: {p.applied_at}\n"
            f"rollback type: {rb_type}\n"
            f"rollback details: {json.dumps(p.rollback, indent=2)}",
            title="◈ rollback applied proposal?", border_style="yellow",
        ))
        if not typer.confirm("Proceed with rollback?"):
            _print("[dim]aborted[/dim]")
            raise typer.Exit(ExitCode.OK)

    # Dispatch on rollback type
    result_msg: str = ""
    try:
        if rb_type == "code_rollback":
            from .code_update import rollback_from_archive
            from pathlib import Path as _Path
            r = rollback_from_archive(
                archive_dir=_Path(p.rollback["archive_dir"]),
                target_relpath=p.rollback["target_relpath"],
            )
            result_msg = f"restored {r['restored_to']} from {r['from_archive']}"
        elif rb_type == "remove_closet":
            from .palace import open_palace
            palace = open_palace()
            try:
                with palace._connect() as c:
                    c.execute("DELETE FROM closets WHERE id = ?",
                              (p.rollback["closet_id"],))
            finally:
                palace.close()
            result_msg = f"removed closet {p.rollback['closet_id']}"
        elif rb_type == "restore_closet":
            from .palace import Closet, open_palace
            palace = open_palace()
            try:
                cd = p.rollback["closet"]
                palace.add_closet(Closet(
                    id=cd["id"], room_id=cd["room_id"],
                    topic=cd["topic"], entities=cd["entities"],
                    atom_ids=cd["atom_ids"],
                    embedding=cd.get("embedding"),
                    source_file=cd.get("source_file"),
                    created_at=cd.get("created_at"),
                ))
            finally:
                palace.close()
            result_msg = f"restored closet {cd['id']}"
        elif rb_type == "restore_triple":
            # Re-validate the triple (clear valid_to). Use direct SQL since
            # palace.py doesn't expose this — invalidating is the supported op,
            # and unwinding it requires this raw access for now.
            from .palace import open_palace
            palace = open_palace()
            try:
                with palace._connect() as c:
                    c.execute("UPDATE triples SET valid_to = NULL WHERE id = ?",
                              (p.rollback["triple_id"],))
            finally:
                palace.close()
            result_msg = f"re-validated triple {p.rollback['triple_id']}"
        elif rb_type == "restore_entities":
            from .palace import open_palace
            palace = open_palace()
            try:
                with palace._connect() as c:
                    # Re-insert the entities
                    for ent in p.rollback.get("entities", []):
                        c.execute(
                            "INSERT OR REPLACE INTO entities(id, name, type, "
                            "properties_json, first_seen, last_seen) "
                            "VALUES (?,?,?,?,?,?)",
                            (ent["id"], ent["name"], ent["type"],
                             ent["properties_json"], ent["first_seen"], ent["last_seen"]),
                        )
                    # Reverse the triple remaps
                    for remap in p.rollback.get("triple_remaps", []):
                        c.execute(
                            "UPDATE triples SET subject_id = ? "
                            "WHERE id = ? AND subject_id = ?",
                            (remap["to_id"], remap["triple_id"], remap["from_id"]),
                        )
                        c.execute(
                            "UPDATE triples SET object_id = ? "
                            "WHERE id = ? AND object_id = ?",
                            (remap["to_id"], remap["triple_id"], remap["from_id"]),
                        )
            finally:
                palace.close()
            result_msg = f"unmerged {len(p.rollback.get('entities', []))} entities"
        else:
            _die(ExitCode.USAGE,
                 f"unsupported rollback type: {rb_type!r}")
    except Exception as e:  # noqa: BLE001
        _die(ExitCode.GENERIC, f"rollback failed: {type(e).__name__}: {e}")

    # Audit event — proposal stays 'applied' for trail; we add a rollback note.
    p_again = store.get(proposal_id)
    p_again.notes = (p_again.notes + "\n" if p_again.notes else "") + \
                    f"ROLLED BACK {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}: {result_msg}"
    from .proposals import _atomic_write_yaml as _w, _to_yaml_dict as _d
    _w(store._path(proposal_id), _d(p_again))
    emit_event(
        "proposal-rolled-back-d",
        plane="control",
        trace_id=f"prop:{proposal_id}",
        payload={"proposal_id": proposal_id, "rollback_type": rb_type, "result": result_msg[:200]},
    )

    if STATE.json_out:
        _emit_json({"ok": True, "result": result_msg})
    else:
        _print(f"[green]rolled back[/green] · {result_msg}")


if __name__ == "__main__":
    app()
