# ╔══════════════════════════════════════════════════════════════════════╗
# ║  sovereign-agent operator aliases                                    ║
# ║                                                                      ║
# ║  Source from your shell rc:                                          ║
# ║    echo 'source ~/AA-Erebo/sovereign-agent-v0.2.9/scripts/aliases.sh' >> ~/.bashrc  ║
# ║                                                                      ║
# ║  Or copy the lines you want into ~/.bashrc directly.                 ║
# ╚══════════════════════════════════════════════════════════════════════╝

# ─── 1. Short alias for the binary ─────────────────────────────────────
# The most-typed thing. `sov` instead of `sovereign`.
alias sov='sovereign'

# ─── 2. Plan-and-drive in one shot ─────────────────────────────────────
# Usage: sov-drive <planner> [planner args...]
#   sov-drive palace-clean
#   sov-drive inventory --root ~/AA-Erebo/Genesis-Seeds --output /tmp/inv.txt --pattern '*.md'
#
# What it does:
#   1. Runs `sovereign plan <planner> ...` and captures the task_id
#   2. Drives the continuation with `sovereign continue` until drained
#   3. Honors AGENT_INTERNET, COOLDOWN_SECONDS env vars
#
# Stops cleanly on PROTOCOL-ZERO. Halt with Ctrl-C; resume by re-running
# sov-drive with the SAME planner+args (continuation lookup is idempotent
# in practice — it'll create a fresh continuation, but pending steps in
# the old one are still queryable via `sov continuations list`).
sov-drive() {
    if [ $# -lt 1 ]; then
        echo "usage: sov-drive <planner> [args...]" >&2
        echo "       sov-drive palace-clean" >&2
        echo "       sov-drive inventory --root <path> --output <file> --pattern '*.md'" >&2
        return 2
    fi
    local plan_output
    plan_output=$(sovereign --json plan "$@" 2>&1) || {
        echo "$plan_output" >&2
        return 1
    }
    local task_id
    task_id=$(echo "$plan_output" | python3 -c "import sys,json; print(json.load(sys.stdin).get('task_id',''))")
    if [ -z "$task_id" ]; then
        echo "could not extract task_id from plan output" >&2
        echo "$plan_output" >&2
        return 1
    fi
    echo "◈ planned · $task_id"
    local cooldown="${COOLDOWN_SECONDS:-2}"
    local steps=0
    while true; do
        local rc
        sovereign continue "$task_id"
        rc=$?
        case "$rc" in
            0) steps=$((steps + 1)); sleep "$cooldown" ;;
            8) echo "◈ drained · $task_id · $steps steps"; return 0 ;;
            9) sleep 5 ;;  # locked, back off
            3) echo "◈ HALT armed · stopping" >&2; return 3 ;;
            *) echo "◈ continue failed (rc=$rc); retrying in $cooldown s" >&2; sleep "$cooldown" ;;
        esac
    done
}

# ─── 3. Bulk approve / reject pending proposals ────────────────────────
# Usage: sov-approve-all              # approve all pending, with confirm
#        sov-approve-all --kind clean # only the clean kind
#
# Useful after a `sov-drive palace-clean` run when you've reviewed the
# pending proposals and want to authorize the obvious ones in one shot.
# Always shows you the count and asks for confirmation.
sov-approve-all() {
    local kind_filter=""
    if [ "$1" = "--kind" ] && [ -n "$2" ]; then
        kind_filter="--kind $2"
        shift 2
    fi
    local pending_json
    pending_json=$(sovereign --json proposals list --status pending $kind_filter 2>&1)
    local count
    count=$(echo "$pending_json" | python3 -c "import sys,json; print(len(json.load(sys.stdin).get('proposals',[])))")
    if [ "$count" = "0" ]; then
        echo "(no pending proposals)"
        return 0
    fi
    echo "$pending_json" | python3 -c "
import sys, json
d = json.load(sys.stdin)
for p in d['proposals']:
    print(f\"  [{p['kind']}] {p['id']}: {p['title']}\")
"
    echo
    read -r -p "Approve all $count pending proposals? [y/N] " yn
    case "$yn" in
        [Yy]*)
            echo "$pending_json" | python3 -c "
import sys, json
d = json.load(sys.stdin)
for p in d['proposals']:
    print(p['id'])
" | while read -r pid; do
                sovereign proposals approve "$pid" --yes >/dev/null && echo "  ✓ $pid"
            done
            ;;
        *) echo "  aborted" ;;
    esac
}

# ─── Bonus: quick palace status ────────────────────────────────────────
# Usage: sov-status
# Shows palace stats + pending proposal count in one view.
sov-status() {
    echo "═══ palace ═══"
    sovereign --json palace stats | python3 -c "
import sys, json
d = json.load(sys.stdin)
for k in ('rooms','closets','entities','triples','active_triples'):
    print(f'  {k}: {d.get(k,0)}')
"
    echo "═══ proposals ═══"
    for status in pending approved applied rejected failed; do
        n=$(sovereign --json proposals list --status "$status" 2>/dev/null | python3 -c "import sys,json; print(len(json.load(sys.stdin).get('proposals',[])))")
        echo "  $status: $n"
    done
    echo "═══ continuations ═══"
    sovereign --json continuations list 2>/dev/null | python3 -c "
import sys, json
d = json.load(sys.stdin)
for c in d.get('continuations',[])[:5]:
    p = c.get('progress',[0,0])
    print(f\"  [{c.get('status','?')}] {c.get('task_id','?')[:30]}  {p[0]}/{p[1]}  {c.get('planner','?')}\")
"
}
