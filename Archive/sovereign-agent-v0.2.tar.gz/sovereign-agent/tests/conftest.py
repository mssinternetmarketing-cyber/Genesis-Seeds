"""Test fixtures.

Each test gets its own SETTINGS pointing at a tmp dir, so production data
is never touched and tests can run in parallel. The reload dance is needed
because ``SETTINGS`` is a module-level singleton constructed at import time;
to retarget it we must re-import config AFTER setting env vars.
"""
from __future__ import annotations

import importlib
import sys
from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def isolated_paths(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Redirect XDG_CONFIG_HOME and XDG_DATA_HOME into the test's tmp dir.

    Order matters: env vars first, then reload config (which builds
    SETTINGS), then reload modules that captured the old SETTINGS at their
    own import time. Skip any module whose reload would be circular.
    """
    config = tmp_path / "config"
    data = tmp_path / "data"
    config.mkdir()
    data.mkdir()
    monkeypatch.setenv("XDG_CONFIG_HOME", str(config))
    monkeypatch.setenv("XDG_DATA_HOME", str(data))

    # Reload config first — that rebuilds SETTINGS against the new env
    import sovereign_agent.config as cfg

    importlib.reload(cfg)

    # Modules that pull SETTINGS at module level need a reload too.
    # Order: leaf modules first, then ones that depend on them.
    reload_order = [
        "sovereign_agent.events",
        "sovereign_agent.protocol_zero",
        "sovereign_agent.pathguard",
        "sovereign_agent.authority",
        "sovereign_agent.approval",
        "sovereign_agent.sandbox",
        "sovereign_agent.code_gate",
        "sovereign_agent.vram",
        "sovereign_agent.db",
        "sovereign_agent.memory.atom",
        "sovereign_agent.memory.retrieval",
        "sovereign_agent.memory",
        "sovereign_agent.seal",
    ]
    for mod_name in reload_order:
        if mod_name in sys.modules:
            try:
                importlib.reload(sys.modules[mod_name])
            except Exception:  # noqa: BLE001 — best-effort
                pass
    yield
