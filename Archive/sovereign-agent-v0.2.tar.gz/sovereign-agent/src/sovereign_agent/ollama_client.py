"""Ollama client wrapper with think_mode-aware dispatch.

Architecture §6 (agent loop) + §V fragile assumption 2a/2b: thinking-mode
behavior on tool-calling is empirically validated separately from no-think.
Default policy is `plan_only`: thinking on for the planner call, off for
tool-dispatch calls.
"""
from __future__ import annotations

from enum import StrEnum
from typing import Any

import ollama

from .config import SETTINGS


class CallKind(StrEnum):
    PLAN = "plan"          # decompose a goal into next-action — thinking helps
    DISPATCH = "dispatch"  # produce a tool call against the available list — no-think safer
    REFLECT = "reflect"    # post-task lesson capture — thinking helps


def _think_for(call_kind: CallKind) -> bool:
    policy = SETTINGS.think_mode
    if policy == "always":
        return True
    if policy == "never":
        return False
    # plan_only (default)
    return call_kind in (CallKind.PLAN, CallKind.REFLECT)


class OllamaClient:
    """Thin wrapper. Async-friendly via ollama.AsyncClient.

    Tool-call interface mirrors ollama-python; we adapt it to our Tool ABC.
    """

    def __init__(self, host: str | None = None) -> None:
        self.host = host or SETTINGS.ollama_host
        self._aclient = ollama.AsyncClient(host=self.host)

    async def chat(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        call_kind: CallKind = CallKind.DISPATCH,
        temperature: float = 0.3,
        num_ctx: int | None = None,
    ) -> dict[str, Any]:
        """Single chat turn. Returns the raw ollama response dict."""
        opts: dict[str, Any] = {"temperature": temperature}
        if num_ctx is not None:
            opts["num_ctx"] = num_ctx
        elif SETTINGS.num_ctx:
            opts["num_ctx"] = SETTINGS.num_ctx

        kwargs: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "options": opts,
            "think": _think_for(call_kind),
        }
        if tools:
            kwargs["tools"] = tools

        response = await self._aclient.chat(**kwargs)
        # ollama.AsyncClient returns a typed object; dump to dict for uniform handling
        return response if isinstance(response, dict) else response.model_dump()

    async def embed(self, *, model: str, prompt: str) -> list[float]:
        result = await self._aclient.embeddings(model=model, prompt=prompt)
        if isinstance(result, dict):
            return list(result["embedding"])
        return list(result.embedding)
